import React from "react";
import { Text } from "@/components/ui/text";
import { VStack } from "@/components/ui/vstack";
import { Image } from "@/components/ui/image";

const AlbumCard = ({ album }: any) => {
  return (
    <VStack>
      <Image
        source={album.imageUrl}
        alt="image"
        size="none"
        className="h-[132px] w-[132px] rounded-lg"
      />
      <Text size="lg" className="text-typography-800 font-medium mt-2.5">
        {album.name}
      </Text>
      <Text className="text-typography-300 line-clamp-1 max-w-[132px] pr-1">
        {album.description}
      </Text>
    </VStack>
  );
};

export default AlbumCard;
