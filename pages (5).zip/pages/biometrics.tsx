import BiometricDashboard from '@/components/BiometricDashboard';
import HealthKitIntegration from '@/components/HealthKitIntegration';

export default function BiometricsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Native Health Platform Integration */}
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Biometric Monitoring</h1>
          <p className="text-slate-300 mb-6">Connect your device's native health platform for real-time wellness tracking</p>
          <HealthKitIntegration />
        </div>
        
        {/* Comprehensive Biometric Dashboard */}
        <BiometricDashboard />
      </div>
    </div>
  );
}