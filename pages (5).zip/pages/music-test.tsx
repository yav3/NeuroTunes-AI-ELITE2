import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function MusicTest() {
  const { data: tracks = [], isLoading, error } = useQuery({
    queryKey: ["/api/tracks"],
  });

  if (isLoading) {
    return <div className="p-8 text-white">Loading tracks...</div>;
  }

  if (error) {
    return <div className="p-8 text-red-400">Error: {String(error)}</div>;
  }

  return (
    <div className="min-h-screen bg-black p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold text-white mb-6">Music Library Test</h1>
        
        <Card className="bg-gray-900 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">
              Available Tracks ({tracks.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {tracks.map((track: any, index: number) => (
                <div key={track.id || index} className="p-3 bg-gray-800 rounded">
                  <div className="text-white font-medium">{track.title}</div>
                  <div className="text-gray-400 text-sm">{track.artist}</div>
                  <div className="text-gray-500 text-xs">
                    Mood: {track.mood || 'Unknown'} | 
                    Duration: {track.duration || 'Unknown'}s
                  </div>
                  {track.audioUrl && (
                    <div className="text-blue-400 text-xs mt-1">
                      Audio: {track.audioUrl.substring(0, 50)}...
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}