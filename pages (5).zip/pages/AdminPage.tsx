import { useState, useRef } from 'react';

interface UploadProgress {
  file: string;
  progress: number;
  status: 'uploading' | 'complete' | 'error';
  message?: string;
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [uploads, setUploads] = useState<UploadProgress[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    // Simple password check for admin access
    if (password === 'neurotunes2025admin') {
      setIsAuthenticated(true);
    } else {
      alert('Invalid admin password');
    }
  };

  const handleFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileUpload = async (files: FileList) => {
    if (!files.length) return;

    setIsUploading(true);
    const newUploads: UploadProgress[] = Array.from(files).map(file => ({
      file: file.name,
      progress: 0,
      status: 'uploading'
    }));
    
    setUploads(prev => [...prev, ...newUploads]);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const formData = new FormData();
      formData.append('audio', file);

      try {
        const response = await fetch('/api/admin/upload-music', {
          method: 'POST',
          body: formData,
        });

        const result = await response.json();

        setUploads(prev => prev.map(upload => 
          upload.file === file.name 
            ? { 
                ...upload, 
                progress: 100, 
                status: response.ok ? 'complete' : 'error',
                message: result.message || (response.ok ? 'Upload successful' : 'Upload failed')
              }
            : upload
        ));
      } catch (error) {
        setUploads(prev => prev.map(upload => 
          upload.file === file.name 
            ? { ...upload, status: 'error', message: 'Network error' }
            : upload
        ));
      }
    }

    setIsUploading(false);
    // Clear file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const clearUploads = () => {
    setUploads([]);
  };

  if (!isAuthenticated) {
    return (
      <div style={{
        height: '100vh',
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px'
      }}>
        <div style={{
          background: 'rgba(12, 25, 41, 0.9)',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          borderRadius: '16px',
          padding: '40px',
          width: '100%',
          maxWidth: '400px',
          textAlign: 'center'
        }}>
          <h1 style={{ fontSize: '24px', marginBottom: '8px', fontWeight: '600', color: 'white' }}>
            NeuroTunes Admin
          </h1>
          <p style={{ fontSize: '14px', color: '#a5b4fc', marginBottom: '32px' }}>
            Music Library Management
          </p>
          
          <form onSubmit={handleAuth}>
            <input
              type="password"
              placeholder="Admin Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{
                width: '100%',
                padding: '12px 16px',
                marginBottom: '20px',
                background: 'rgba(59, 130, 246, 0.1)',
                border: '1px solid rgba(59, 130, 246, 0.3)',
                borderRadius: '8px',
                color: 'white',
                fontSize: '16px',
                boxSizing: 'border-box'
              }}
              required
            />
            
            <button
              type="submit"
              style={{
                width: '100%',
                padding: '12px',
                background: '#3b82f6',
                border: 'none',
                borderRadius: '8px',
                color: 'white',
                fontSize: '16px',
                fontWeight: '500',
                cursor: 'pointer',
                transition: 'background 0.2s ease'
              }}
            >
              Access Admin Panel
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      height: '100vh',
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      padding: '20px',
      overflow: 'auto'
    }}>
      <div style={{
        maxWidth: '800px',
        margin: '0 auto'
      }}>
        {/* Header */}
        <div style={{
          background: 'rgba(12, 25, 41, 0.9)',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          borderRadius: '16px',
          padding: '24px',
          marginBottom: '24px'
        }}>
          <h1 style={{ fontSize: '28px', marginBottom: '8px', fontWeight: '600', color: 'white' }}>
            NeuroTunes Admin Panel
          </h1>
          <p style={{ fontSize: '14px', color: '#a5b4fc', marginBottom: '0' }}>
            Music Library Management • Upload MP3 Files
          </p>
        </div>

        {/* Upload Area */}
        <div style={{
          background: 'rgba(12, 25, 41, 0.9)',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          borderRadius: '16px',
          padding: '32px',
          marginBottom: '24px',
          textAlign: 'center'
        }}>
          <h2 style={{ fontSize: '20px', marginBottom: '16px', fontWeight: '600', color: 'white' }}>
            Upload Music Files
          </h2>
          
          <div
            onClick={handleFileSelect}
            style={{
              border: '2px dashed rgba(59, 130, 246, 0.5)',
              borderRadius: '12px',
              padding: '48px 24px',
              cursor: 'pointer',
              transition: 'all 0.2s ease',
              background: 'rgba(59, 130, 246, 0.05)',
              marginBottom: '20px'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.8)';
              e.currentTarget.style.background = 'rgba(59, 130, 246, 0.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.5)';
              e.currentTarget.style.background = 'rgba(59, 130, 246, 0.05)';
            }}
          >
            <div style={{ fontSize: '48px', marginBottom: '16px' }}>🎵</div>
            <h3 style={{ fontSize: '18px', marginBottom: '8px', fontWeight: '500', color: 'white' }}>
              Click to Select MP3 Files
            </h3>
            <p style={{ fontSize: '14px', color: '#a5b4fc', margin: '0' }}>
              Supports multiple file selection • MP3 format only
            </p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".mp3,audio/mp3"
            multiple
            style={{ display: 'none' }}
            onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
          />

          {isUploading && (
            <div style={{
              padding: '16px',
              background: 'rgba(59, 130, 246, 0.1)',
              borderRadius: '8px',
              marginBottom: '16px'
            }}>
              <p style={{ color: '#93c5fd', margin: '0', fontSize: '14px' }}>
                Processing uploads...
              </p>
            </div>
          )}
        </div>

        {/* Upload Progress */}
        {uploads.length > 0 && (
          <div style={{
            background: 'rgba(12, 25, 41, 0.9)',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            borderRadius: '16px',
            padding: '24px'
          }}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              marginBottom: '20px'
            }}>
              <h3 style={{ fontSize: '18px', fontWeight: '600', color: 'white', margin: '0' }}>
                Upload Progress
              </h3>
              <button
                onClick={clearUploads}
                style={{
                  padding: '8px 16px',
                  background: 'rgba(59, 130, 246, 0.2)',
                  border: '1px solid rgba(59, 130, 246, 0.3)',
                  borderRadius: '6px',
                  color: '#93c5fd',
                  fontSize: '12px',
                  cursor: 'pointer'
                }}
              >
                Clear List
              </button>
            </div>

            <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
              {uploads.map((upload, index) => (
                <div
                  key={index}
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    padding: '12px 16px',
                    background: 'rgba(59, 130, 246, 0.05)',
                    border: '1px solid rgba(59, 130, 246, 0.2)',
                    borderRadius: '8px',
                    marginBottom: '8px'
                  }}
                >
                  <div style={{ flex: 1 }}>
                    <p style={{ fontSize: '14px', fontWeight: '500', color: 'white', margin: '0 0 4px 0' }}>
                      {upload.file}
                    </p>
                    {upload.message && (
                      <p style={{ fontSize: '12px', color: '#a5b4fc', margin: '0' }}>
                        {upload.message}
                      </p>
                    )}
                  </div>
                  
                  <div style={{
                    padding: '4px 12px',
                    borderRadius: '4px',
                    fontSize: '12px',
                    fontWeight: '500',
                    background: upload.status === 'complete' ? 'rgba(34, 197, 94, 0.2)' : 
                               upload.status === 'error' ? 'rgba(239, 68, 68, 0.2)' : 
                               'rgba(59, 130, 246, 0.2)',
                    color: upload.status === 'complete' ? '#4ade80' : 
                           upload.status === 'error' ? '#f87171' : 
                           '#93c5fd'
                  }}>
                    {upload.status === 'complete' ? 'Complete' : 
                     upload.status === 'error' ? 'Failed' : 
                     'Uploading...'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}