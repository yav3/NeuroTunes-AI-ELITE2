import { useEffect, useState } from 'react';
import { api, Track } from '../lib/api';
import TrackCard from '../components/TrackCard';
import { ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const VIBES = [
  { id: 'focus', label: 'Deep Focus' },
  { id: 'calm', label: 'Calm & Chill' },
  { id: 'energy', label: 'Energy' },
  { id: 'sleep', label: 'Sleep' },
];

export default function AIDJPageSimple() {
  const navigate = useNavigate();
  const [vibe, setVibe] = useState<string>('focus');
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const generate = async () => {
    setLoading(true);
    setErr(null);
    try {
      // If your backend supports filtering by goal/tag, update this query accordingly:
      const list = await api.tracks({ limit: 30 }); // fallback generic list
      setTracks(list.slice(0, 20));
    } catch (e: any) {
      setErr(String(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { generate(); /* generate list on first mount */ }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate('/')}
          className="w-10 h-10 rounded-full bg-slate-800/60 hover:bg-slate-700/60 flex items-center justify-center transition-colors border border-slate-700/30"
        >
          <ChevronLeft size={18} strokeWidth={1.5} className="text-slate-300" />
        </button>
        <div>
          <h2 className="text-xl font-semibold text-slate-50 tracking-tight">AI DJ</h2>
          <p className="text-slate-400 text-sm mt-0.5">Pick a vibe and we'll spin a session.</p>
        </div>
      </div>

      {/* Vibe Selection */}
      <div className="flex gap-2 flex-wrap">
        {VIBES.map(v => (
          <button
            key={v.id}
            onClick={() => setVibe(v.id)}
            className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
              vibe === v.id 
                ? 'bg-blue-600 text-white border border-blue-500' 
                : 'bg-slate-800/60 text-slate-300 border border-slate-700/30 hover:bg-slate-700/60'
            }`}
          >
            {v.label}
          </button>
        ))}
        <button
          onClick={generate}
          className="ml-auto px-6 py-2.5 rounded-xl text-sm font-medium bg-blue-600 hover:bg-blue-700 text-white transition-colors"
        >
          Generate
        </button>
      </div>

      {/* Loading/Error States */}
      {loading && <div className="text-blue-400 text-sm">Loading suggestions…</div>}
      {err && <div className="text-red-400 text-sm bg-red-500/10 border border-red-500/20 rounded-xl p-3">Error: {err}</div>}

      {/* Track List */}
      <div className="space-y-3">
        {tracks.map(t => <TrackCard key={t.id} track={t} />)}
      </div>
    </div>
  );
}