import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Download, Search, BarChart3, Database, Upload } from "lucide-react";

interface DuplicateGroup {
  fingerprint: string;
  groupSize: number;
  duplicateCount: number;
  original: Track;
  duplicates: Track[];
}

interface Track {
  id: number;
  title: string;
  artist: string;
  duration: number;
  mood: string;
  created_at: string;
}

interface DuplicateAnalysis {
  duplicateGroups: DuplicateGroup[];
  statistics: {
    totalGroups: number;
    totalDuplicates: number;
    spaceSaved: string;
  };
}

export default function AdminPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedDuplicates, setSelectedDuplicates] = useState<number[]>([]);
  const [selectedTable, setSelectedTable] = useState<string>('');

  // Fetch duplicate analysis
  const { data: duplicateData, isLoading: isAnalyzing, refetch: analyzeAgain } = useQuery<DuplicateAnalysis>({
    queryKey: ['/api/admin/duplicates/analyze'],
  });

  // Fetch database statistics
  const { data: statsData } = useQuery({
    queryKey: ['/api/admin/stats'],
  });

  // Fetch Supabase analysis
  const { data: supabaseData, isLoading: isAnalyzingSupabase, refetch: analyzeSupabase } = useQuery({
    queryKey: ['/api/admin/supabase/analyze'],
    enabled: false, // Only run when manually triggered
  });

  // Remove duplicates mutation
  const removeDuplicatesMutation = useMutation({
    mutationFn: async ({ duplicateIds, dryRun }: { duplicateIds: number[]; dryRun: boolean }) => {
      const response = await fetch('/api/admin/duplicates/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ duplicateIds, dryRun }),
      });
      if (!response.ok) throw new Error('Failed to remove duplicates');
      return response.json();
    },
    onSuccess: (data) => {
      if (data.dryRun) {
        toast({
          title: "Dry Run Complete",
          description: `Would remove ${data.tracksToDelete} duplicate tracks`,
        });
      } else {
        toast({
          title: "Success",
          description: `Removed ${data.deletedCount} duplicate tracks`,
        });
        queryClient.invalidateQueries({ queryKey: ['/api/admin/duplicates/analyze'] });
        queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
        setSelectedDuplicates([]);
      }
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove duplicates",
        variant: "destructive",
      });
    },
  });

  // Import from Supabase mutation
  const importFromSupabaseMutation = useMutation({
    mutationFn: async ({ tableName, limit }: { tableName: string; limit?: number }) => {
      const response = await fetch('/api/admin/supabase/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tableName, limit }),
      });
      if (!response.ok) throw new Error('Failed to import from Supabase');
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Import Complete",
        description: `Imported ${data.imported} tracks, skipped ${data.skipped} duplicates`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tracks'] });
    },
    onError: () => {
      toast({
        title: "Import Failed",
        description: "Could not import music from Supabase",
        variant: "destructive",
      });
    },
  });

  const handleSelectAll = () => {
    if (!duplicateData) return;
    const allDuplicateIds = duplicateData.duplicateGroups.flatMap(group => 
      group.duplicates.map(track => track.id)
    );
    setSelectedDuplicates(allDuplicateIds);
  };

  const handleSelectGroup = (group: DuplicateGroup) => {
    const groupIds = group.duplicates.map(track => track.id);
    setSelectedDuplicates(prev => [...prev, ...groupIds]);
  };

  const handleExportDuplicates = async () => {
    try {
      const response = await fetch('/api/admin/duplicates/export');
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'neurotunes_duplicates.json';
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: "Export Complete",
        description: "Duplicate data exported successfully",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Could not export duplicate data",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">NeuroTunes+ Admin</h1>
          <p className="text-muted-foreground">Database management and optimization tools</p>
        </div>
      </div>

      <Tabs defaultValue="duplicates" className="space-y-4">
        <TabsList>
          <TabsTrigger value="duplicates">Duplicate Analysis</TabsTrigger>
          <TabsTrigger value="import">Supabase Import</TabsTrigger>
          <TabsTrigger value="statistics">Database Statistics</TabsTrigger>
        </TabsList>

        <TabsContent value="duplicates" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Track Deduplication
              </CardTitle>
              <CardDescription>
                Analyze and remove duplicate tracks from your music library
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Button 
                  onClick={() => analyzeAgain()} 
                  disabled={isAnalyzing}
                  variant="outline"
                >
                  {isAnalyzing ? "Analyzing..." : "Refresh Analysis"}
                </Button>
                <Button 
                  onClick={handleExportDuplicates}
                  variant="outline"
                  disabled={!duplicateData?.duplicateGroups.length}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export Duplicates
                </Button>
              </div>

              {duplicateData && (
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{duplicateData.statistics.totalGroups}</div>
                        <p className="text-sm text-muted-foreground">Duplicate Groups</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{duplicateData.statistics.totalDuplicates}</div>
                        <p className="text-sm text-muted-foreground">Total Duplicates</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{duplicateData.statistics.spaceSaved}</div>
                        <p className="text-sm text-muted-foreground">Space Savings</p>
                      </CardContent>
                    </Card>
                  </div>

                  {duplicateData.duplicateGroups.length > 0 && (
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <Button onClick={handleSelectAll} variant="outline" size="sm">
                          Select All Duplicates
                        </Button>
                        <Button 
                          onClick={() => removeDuplicatesMutation.mutate({ duplicateIds: selectedDuplicates, dryRun: true })}
                          disabled={selectedDuplicates.length === 0}
                          variant="outline"
                          size="sm"
                        >
                          Dry Run ({selectedDuplicates.length})
                        </Button>
                        <Button 
                          onClick={() => removeDuplicatesMutation.mutate({ duplicateIds: selectedDuplicates, dryRun: false })}
                          disabled={selectedDuplicates.length === 0}
                          variant="destructive"
                          size="sm"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Remove Selected ({selectedDuplicates.length})
                        </Button>
                      </div>

                      <div className="space-y-3">
                        {duplicateData.duplicateGroups.map((group, index) => (
                          <Card key={group.fingerprint}>
                            <CardContent className="pt-4">
                              <div className="flex items-start justify-between">
                                <div className="space-y-2">
                                  <div className="flex items-center gap-2">
                                    <h4 className="font-semibold">Group {index + 1}</h4>
                                    <Badge variant="secondary">{group.duplicateCount} duplicates</Badge>
                                  </div>
                                  
                                  <div className="text-sm">
                                    <p className="font-medium">Original: {group.original.title}</p>
                                    <p className="text-muted-foreground">by {group.original.artist}</p>
                                    <p className="text-muted-foreground">
                                      {group.original.duration}s • {group.original.mood || 'No mood'} • 
                                      Created: {new Date(group.original.created_at).toLocaleDateString()}
                                    </p>
                                  </div>

                                  <div className="space-y-1">
                                    <p className="text-xs font-medium text-muted-foreground">Duplicates to remove:</p>
                                    {group.duplicates.map((dupe) => (
                                      <div key={dupe.id} className="text-xs text-muted-foreground pl-4">
                                        ID {dupe.id} - Created: {new Date(dupe.created_at).toLocaleDateString()}
                                      </div>
                                    ))}
                                  </div>
                                </div>

                                <Button
                                  onClick={() => handleSelectGroup(group)}
                                  variant="outline"
                                  size="sm"
                                >
                                  Select This Group
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}

                  {duplicateData.duplicateGroups.length === 0 && (
                    <Card>
                      <CardContent className="pt-6 text-center">
                        <p className="text-muted-foreground">No duplicates found! Your library is clean.</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="h-5 w-5" />
                Supabase Music Import
              </CardTitle>
              <CardDescription>
                Import your music library from Supabase database
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-2">
                <Button 
                  onClick={() => analyzeSupabase()} 
                  disabled={isAnalyzingSupabase}
                  variant="outline"
                >
                  {isAnalyzingSupabase ? "Analyzing..." : "Analyze Supabase Data"}
                </Button>
              </div>

              {supabaseData && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{supabaseData.availableTables?.length || 0}</div>
                        <p className="text-sm text-muted-foreground">Available Tables</p>
                      </CardContent>
                    </Card>
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-2xl font-bold">{supabaseData.totalTracks}</div>
                        <p className="text-sm text-muted-foreground">Total Tracks Found</p>
                      </CardContent>
                    </Card>
                  </div>

                  {supabaseData.availableTables && supabaseData.availableTables.length > 0 && (
                    <div className="space-y-4">
                      <h4 className="font-semibold">Available Tables:</h4>
                      {supabaseData.availableTables.map((table: any) => (
                        <Card key={table.name}>
                          <CardContent className="pt-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <h5 className="font-medium">{table.name}</h5>
                                <p className="text-sm text-muted-foreground">
                                  {table.count} tracks
                                </p>
                                {table.sampleRecord && (
                                  <div className="text-xs text-muted-foreground mt-2">
                                    Sample: {table.sampleRecord.title || 'No title'} - {table.sampleRecord.artist || 'No artist'}
                                  </div>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => setSelectedTable(table.name)}
                                  variant="outline"
                                  size="sm"
                                >
                                  Select
                                </Button>
                                {selectedTable === table.name && (
                                  <Button
                                    onClick={() => importFromSupabaseMutation.mutate({ tableName: table.name })}
                                    disabled={importFromSupabaseMutation.isPending}
                                    size="sm"
                                  >
                                    <Upload className="h-4 w-4 mr-2" />
                                    {importFromSupabaseMutation.isPending ? "Importing..." : "Import All"}
                                  </Button>
                                )}
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}

                  {supabaseData.availableTables && supabaseData.availableTables.length === 0 && (
                    <Card>
                      <CardContent className="pt-6 text-center">
                        <p className="text-muted-foreground">
                          No music tables found in your Supabase database.
                        </p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="statistics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Database Statistics
              </CardTitle>
              <CardDescription>
                Overview of your NeuroTunes+ database
              </CardDescription>
            </CardHeader>
            <CardContent>
              {statsData && statsData.statistics ? (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{statsData.statistics.total_tracks || 0}</div>
                      <p className="text-sm text-muted-foreground">Total Tracks</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{statsData.statistics.unique_artists || 0}</div>
                      <p className="text-sm text-muted-foreground">Unique Artists</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{statsData.statistics.unique_moods || 0}</div>
                      <p className="text-sm text-muted-foreground">Unique Moods</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-2xl font-bold">{statsData.statistics.unique_genres || 0}</div>
                      <p className="text-sm text-muted-foreground">Unique Genres</p>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-muted-foreground">Loading database statistics...</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}