import React, { useState, useEffect } from 'react';
import { Play, Shuffle, Heart, Star, Zap, Music, Target, Headphones, Volume2, Brain, Sparkles } from 'lucide-react';

interface Track {
  id: number;
  title: string;
  artist: string;
  duration: number;
  audioUrl: string;
  genre?: string;
  therapeutic_use?: string;
}

interface AIPlaylist {
  tracks: Track[];
  mood: string;
  totalDuration: number;
  message: string;
}

interface AIDJPageProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
}

export default function AIDJPage({ onPlayTrack, currentTrack }: AIDJPageProps) {
  const [currentPlaylist, setCurrentPlaylist] = useState<AIPlaylist | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [favorites, setFavorites] = useState<Track[]>([]);
  const [availableGenres, setAvailableGenres] = useState<string[]>([]);
  const [genreRepresentativeTracks, setGenreRepresentativeTracks] = useState<{[genre: string]: string}>({});
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('neurotunes-favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  // Load available genres and representative tracks for album art
  useEffect(() => {
    const loadGenresAndRepresentativeTracks = async () => {
      try {
        const genresResponse = await fetch('/api/genres');
        if (genresResponse.ok) {
          const genres = await genresResponse.json();
          console.log('Loaded genres:', genres);
          const topGenres = genres.slice(0, 12); // Get top 12 genres
          setAvailableGenres(topGenres);
          
          // Get representative tracks for each genre for album art
          const tracksResponse = await fetch('/api/tracks');
          if (tracksResponse.ok) {
            const tracksData = await tracksResponse.json();
            const tracks = tracksData.catalog || tracksData;
            
            const representativeTracks: {[genre: string]: string} = {};
            topGenres.forEach((genre: string) => {
              // Find the first track of each genre to use as representative
              const genreTracks = tracks.filter((track: Track) => 
                track.genre?.toLowerCase() === genre.toLowerCase() ||
                (track as any).genres?.some((g: string) => g.toLowerCase() === genre.toLowerCase())
              );
              if (genreTracks.length > 0) {
                representativeTracks[genre] = genreTracks[0].title;
              }
            });
            
            console.log('Representative tracks for genres:', representativeTracks);
            setGenreRepresentativeTracks(representativeTracks);
          }
        } else {
          console.error('Failed to load genres - response not ok:', genresResponse.status);
          // Fallback to basic styles if endpoint fails
          setAvailableGenres(['Electronic', 'Classical', 'Jazz', 'EDM', 'Folk', 'Ambient']);
        }
      } catch (error) {
        console.error('Failed to load genres:', error);
        // Fallback to basic styles if endpoint fails
        setAvailableGenres(['Electronic', 'Classical', 'Jazz', 'EDM', 'Folk', 'Ambient']);
      }
    };
    loadGenresAndRepresentativeTracks();
  }, []);

  const therapeuticGoals = [
    { id: 'confidence_building', name: 'Confidence Building', description: 'Build self-assurance and inner strength', count: 240 },
    { id: 'positivity', name: 'Positivity Enhancement', description: 'Cultivate positive mindset', count: 231 },
    { id: 'mood_elevation', name: 'Mood Elevation', description: 'Lift spirits and emotional state', count: 224 },
    { id: 'leadership', name: 'Leadership Mindset', description: 'Develop leadership confidence', count: 220 },
    { id: 'empowerment', name: 'Personal Empowerment', description: 'Feel empowered and capable', count: 220 },
    { id: 'energy_boost', name: 'Energy Enhancement', description: 'Increase vitality and motivation', count: 124 },
    { id: 'focus', name: 'Deep Focus', description: 'Enhanced concentration and clarity', count: 124 },
    { id: 'meditation', name: 'Meditation & Pain Management', description: 'Mindful practice enhancement', count: 85 },
    { id: 'relaxation', name: 'Deep Relaxation', description: 'Calm mind and body', count: 78 },
    { id: 'celebration', name: 'Celebration', description: 'Joyful moments and achievements', count: 216 }
  ];

  const generatePlaylist = async (mood: string, duration: number = 60) => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai-dj/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          mood, 
          duration,
          genre: selectedGenre,
          therapeuticGoal: selectedGoal
        }),
      });

      if (response.ok) {
        const playlist = await response.json();
        setCurrentPlaylist(playlist);
      } else {
        console.error('Failed to generate playlist');
      }
    } catch (error) {
      console.error('Error generating playlist:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateSmartMix = async () => {
    if (!selectedGoal && !selectedGenre) return;
    
    const mood = selectedGoal === 'energy_boost' ? 'energy' : 
                 selectedGoal === 'focus' ? 'focus' : 
                 selectedGoal === 'relaxation' ? 'relaxation' : 'focus';
    
    await generatePlaylist(mood, 45);
  };

  return (
    <div style={{
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      minHeight: '100vh',
      color: 'white',
      padding: '20px'
    }}>
      <div style={{ maxWidth: '400px', margin: '0 auto' }}>
        
        {/* Header */}
        <div style={{
          background: 'rgba(15, 23, 42, 0.8)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(71, 85, 105, 0.3)',
          borderRadius: '16px',
          padding: '20px',
          marginBottom: '20px',
          textAlign: 'center'
        }}>
          <h1 style={{
            fontSize: '24px',
            fontWeight: '700',
            margin: '0 0 12px 0',
            background: 'linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%)',
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            color: 'transparent'
          }}>
            NeuroTunes AI
          </h1>

        </div>

        {/* AI DJ Section */}
        <div style={{
          background: 'rgba(30, 64, 175, 0.3)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(59, 130, 246, 0.3)',
          borderRadius: '16px',
          padding: '16px',
          marginBottom: '16px',
          marginTop: '-8px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '8px' }}>
            <div style={{
              width: '40px',
              height: '40px',
              background: 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)',
              borderRadius: '12px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}>
              <Music style={{ width: '20px', height: '20px', color: 'white' }} />
            </div>
            <h2 style={{ fontSize: '20px', fontWeight: '600', margin: '0' }}>AI DJ</h2>
          </div>
          <p style={{ 
            fontSize: '14px', 
            color: '#cbd5e1', 
            margin: '0',
            lineHeight: '1.4'
          }}>
            Pick a Goal and Genre
          </p>
        </div>

        {/* Favorites Section */}
        <div style={{
          background: 'rgba(15, 23, 42, 0.6)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(71, 85, 105, 0.3)',
          borderRadius: '16px',
          padding: '20px',
          marginBottom: '20px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Heart style={{ width: '20px', height: '20px', color: '#f87171' }} />
              <h3 style={{ fontSize: '16px', fontWeight: '600', margin: '0' }}>Favorites</h3>

            </div>
            <button
              onClick={() => favorites.length > 0 && generatePlaylist('favorites', 30)}
              disabled={favorites.length === 0}
              style={{
                background: 'rgba(239, 68, 68, 0.2)',
                border: '1px solid rgba(239, 68, 68, 0.3)',
                borderRadius: '8px',
                padding: '6px 12px',
                color: '#fca5a5',
                fontSize: '12px',
                cursor: favorites.length > 0 ? 'pointer' : 'not-allowed',
                opacity: favorites.length === 0 ? 0.5 : 1
              }}
            >
              Mix
            </button>
          </div>

          {favorites.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: '#64748b' }}>
              <Heart style={{ width: '32px', height: '32px', margin: '0 auto 12px', opacity: 0.3 }} />
              <p style={{ margin: '0', fontSize: '14px' }}>Heart tracks to save them here</p>
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
              {favorites.slice(0, 8).map((track) => (
                <div
                  key={track.id}
                  onClick={() => onPlayTrack(track)}
                  style={{
                    cursor: 'pointer',
                    textAlign: 'center',
                    transition: 'transform 0.2s'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'scale(1.05)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'scale(1)';
                  }}
                >
                  <div style={{
                    width: '60px',
                    height: '60px',
                    borderRadius: '12px',
                    margin: '0 auto 8px',
                    boxShadow: '0 4px 12px rgba(248, 113, 113, 0.3)',
                    background: `url('/api/art/${encodeURIComponent(track.title)}') center/cover`,
                    backgroundColor: 'linear-gradient(135deg, #f87171 0%, #ec4899 100%)',
                    position: 'relative',
                    overflow: 'hidden'
                  }}>
                    <div style={{
                      position: 'absolute',
                      inset: '0',
                      background: 'rgba(248, 113, 113, 0.3)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <Heart style={{ width: '20px', height: '20px', color: 'white', opacity: 0.9 }} />
                    </div>
                  </div>
                  <p style={{ 
                    fontSize: '11px', 
                    margin: '0',
                    lineHeight: '1.3',
                    fontWeight: '500',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap'
                  }}>
                    {track.title}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Musical Styles Section */}
        <div style={{
          background: 'rgba(15, 23, 42, 0.6)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(71, 85, 105, 0.3)',
          borderRadius: '16px',
          padding: '20px',
          marginBottom: '20px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Headphones style={{ width: '20px', height: '20px', color: '#60a5fa' }} />
              <h3 style={{ fontSize: '16px', fontWeight: '600', margin: '0' }}>Musical Styles</h3>
              <span style={{ fontSize: '12px', color: '#64748b' }}>Authentic collection</span>
            </div>
            <button
              onClick={() => selectedGenre && generatePlaylist('focus', 45)}
              disabled={!selectedGenre}
              style={{
                background: 'rgba(59, 130, 246, 0.2)',
                border: '1px solid rgba(59, 130, 246, 0.3)',
                borderRadius: '8px',
                padding: '6px 12px',
                color: '#93c5fd',
                fontSize: '12px',
                cursor: selectedGenre ? 'pointer' : 'not-allowed',
                opacity: selectedGenre ? 1 : 0.5
              }}
            >
              Generate Mix
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
            {availableGenres.map((genre, index) => {
              const isSelected = selectedGenre === genre;
              const representativeTrack = genreRepresentativeTracks[genre];
              
              return (
                <div
                  key={genre}
                  onClick={() => setSelectedGenre(isSelected ? null : genre)}
                  style={{
                    background: isSelected 
                      ? 'linear-gradient(135deg, rgba(59, 130, 246, 0.3) 0%, rgba(147, 51, 234, 0.3) 100%)'
                      : 'rgba(30, 41, 59, 0.5)',
                    border: isSelected 
                      ? '2px solid rgba(59, 130, 246, 0.6)' 
                      : '1px solid rgba(71, 85, 105, 0.3)',
                    borderRadius: '12px',
                    padding: '12px',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    textAlign: 'center'
                  }}
                  onMouseEnter={(e) => {
                    if (!isSelected) {
                      e.currentTarget.style.transform = 'scale(1.02)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!isSelected) {
                      e.currentTarget.style.transform = 'scale(1)';
                    }
                  }}
                >
                  <div style={{
                    width: '50px',
                    height: '50px',
                    borderRadius: '10px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 8px',
                    background: representativeTrack 
                      ? `url('/api/art/${encodeURIComponent(representativeTrack)}') center/cover`
                      : 'linear-gradient(135deg, #60a5fa, #9333ea)',
                    backgroundColor: 'linear-gradient(135deg, #60a5fa, #9333ea)',
                    boxShadow: isSelected 
                      ? '0 4px 12px rgba(59, 130, 246, 0.4)' 
                      : '0 2px 8px rgba(0, 0, 0, 0.3)',
                    position: 'relative',
                    overflow: 'hidden'
                  }}>
                    {!representativeTrack && (
                      <div style={{
                        fontSize: '18px',
                        fontWeight: 'bold',
                        color: 'white'
                      }}>
                        {genre.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div style={{
                      position: 'absolute',
                      inset: '0',
                      background: isSelected 
                        ? 'rgba(59, 130, 246, 0.2)'
                        : 'rgba(0, 0, 0, 0.1)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <Music style={{ 
                        width: '16px', 
                        height: '16px', 
                        color: 'white', 
                        opacity: representativeTrack ? 0.8 : 0
                      }} />
                    </div>
                  </div>
                  <h4 style={{ 
                    fontSize: '11px', 
                    fontWeight: '600', 
                    margin: '0',
                    color: isSelected ? '#e2e8f0' : '#cbd5e1',
                    textTransform: 'capitalize',
                    lineHeight: '1.2'
                  }}>
                    {genre}
                  </h4>
                </div>
              );
            })}
          </div>
        </div>

        {/* Therapeutic Goals Section */}
        <div style={{
          background: 'rgba(15, 23, 42, 0.6)',
          backdropFilter: 'blur(12px)',
          border: '1px solid rgba(71, 85, 105, 0.3)',
          borderRadius: '16px',
          padding: '20px',
          marginBottom: '20px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Target style={{ width: '20px', height: '20px', color: '#34d399' }} />
              <h3 style={{ fontSize: '16px', fontWeight: '600', margin: '0' }}>Therapeutic Goals</h3>
              <span style={{ fontSize: '12px', color: '#64748b' }}>Clinical applications</span>
            </div>
            <button
              onClick={generateSmartMix}
              disabled={!selectedGoal}
              style={{
                background: 'rgba(52, 211, 153, 0.2)',
                border: '1px solid rgba(52, 211, 153, 0.3)',
                borderRadius: '8px',
                padding: '6px 12px',
                color: '#6ee7b7',
                fontSize: '12px',
                cursor: selectedGoal ? 'pointer' : 'not-allowed',
                opacity: selectedGoal ? 1 : 0.5,
                display: 'flex',
                alignItems: 'center',
                gap: '4px'
              }}
            >
              <Sparkles style={{ width: '12px', height: '12px' }} />
              Smart Mix
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '8px' }}>
            {therapeuticGoals.slice(0, 6).map((goal) => {
              const isSelected = selectedGoal === goal.id;
              return (
                <div
                  key={goal.id}
                  onClick={() => setSelectedGoal(isSelected ? null : goal.id)}
                  style={{
                    background: isSelected 
                      ? 'linear-gradient(135deg, rgba(52, 211, 153, 0.2) 0%, rgba(16, 185, 129, 0.2) 100%)'
                      : 'rgba(30, 41, 59, 0.3)',
                    border: isSelected 
                      ? '2px solid rgba(52, 211, 153, 0.5)' 
                      : '1px solid rgba(71, 85, 105, 0.2)',
                    borderRadius: '12px',
                    padding: '12px 16px',
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                >
                  <div>
                    <h4 style={{ 
                      fontSize: '14px', 
                      fontWeight: '600', 
                      margin: '0 0 4px 0',
                      color: isSelected ? '#e2e8f0' : '#cbd5e1'
                    }}>
                      {goal.name}
                    </h4>
                    <p style={{ 
                      fontSize: '12px', 
                      color: '#64748b',
                      margin: '0',
                      lineHeight: '1.3'
                    }}>
                      {goal.description}
                    </p>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <span style={{
                      fontSize: '11px',
                      color: isSelected ? '#6ee7b7' : '#64748b',
                      background: isSelected ? 'rgba(52, 211, 153, 0.2)' : 'rgba(71, 85, 105, 0.2)',
                      padding: '4px 8px',
                      borderRadius: '6px',
                      fontWeight: '500'
                    }}>
                      {goal.count} tracks
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Generated Playlist */}
        {currentPlaylist && (
          <div style={{
            background: 'rgba(15, 23, 42, 0.8)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(139, 92, 246, 0.3)',
            borderRadius: '16px',
            padding: '20px',
            marginBottom: '20px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Shuffle style={{ width: '20px', height: '20px', color: '#60a5fa' }} />
                <h3 style={{ fontSize: '16px', fontWeight: '600', margin: '0' }}>Generated Playlist</h3>
                <span style={{ fontSize: '12px', color: '#64748b' }}>
                  ({currentPlaylist.tracks.length} tracks • {currentPlaylist.totalDuration}min)
                </span>
              </div>
              <button
                onClick={() => currentPlaylist.tracks[0] && onPlayTrack(currentPlaylist.tracks[0])}
                style={{
                  background: 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)',
                  border: 'none',
                  borderRadius: '8px',
                  padding: '8px 16px',
                  color: 'white',
                  fontSize: '12px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '4px',
                  fontWeight: '500'
                }}
              >
                <Play style={{ width: '12px', height: '12px' }} />
                Play All
              </button>
            </div>

            <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
              {currentPlaylist.tracks.slice(0, 8).map((track, index) => (
                <div
                  key={track.id}
                  onClick={() => onPlayTrack(track)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '8px 12px',
                    background: 'rgba(30, 41, 59, 0.3)',
                    borderRadius: '8px',
                    marginBottom: '8px',
                    cursor: 'pointer',
                    transition: 'background 0.2s'
                  }}
                >
                  <div style={{
                    width: '32px',
                    height: '32px',
                    background: 'linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%)',
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '12px',
                    fontWeight: '600',
                    color: 'white'
                  }}>
                    ♪
                  </div>
                  <div style={{ flex: 1 }}>
                    <h4 style={{ 
                      fontSize: '13px', 
                      fontWeight: '500', 
                      margin: '0 0 2px 0',
                      color: '#e2e8f0'
                    }}>
                      {track.title}
                    </h4>
                    <p style={{ 
                      fontSize: '11px', 
                      color: '#64748b',
                      margin: '0'
                    }}>
                      {track.artist}
                    </p>
                  </div>
                  <div style={{
                    fontSize: '11px',
                    color: '#64748b'
                  }}>
                    {Math.floor(track.duration / 60)}:{String(track.duration % 60).padStart(2, '0')}
                  </div>
                </div>
              ))}
            </div>

            <div style={{
              marginTop: '16px',
              padding: '12px',
              background: 'rgba(59, 130, 246, 0.1)',
              borderRadius: '8px',
              border: '1px solid rgba(59, 130, 246, 0.2)'
            }}>
              <p style={{ 
                fontSize: '12px', 
                color: '#93c5fd',
                margin: '0',
                lineHeight: '1.4'
              }}>
                {currentPlaylist.message}
              </p>
            </div>
          </div>
        )}

        {/* Loading State */}
        {isGenerating && (
          <div style={{
            background: 'rgba(15, 23, 42, 0.8)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(71, 85, 105, 0.3)',
            borderRadius: '16px',
            padding: '40px 20px',
            textAlign: 'center',
            marginBottom: '20px'
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              border: '3px solid rgba(59, 130, 246, 0.3)',
              borderTop: '3px solid #3b82f6',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto 16px'
            }}></div>
            <p style={{ 
              fontSize: '14px', 
              color: '#cbd5e1',
              margin: '0'
            }}>
              Generating therapeutic playlist...
            </p>
          </div>
        )}

      </div>
    </div>
  );
}