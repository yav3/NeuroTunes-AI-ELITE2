import { useState, useEffect } from 'react';
import { Play, Shuffle, Heart, Star, Zap, Music, Target, Headphones, Volume2, Brain, Sparkles } from 'lucide-react';

interface Track {
  id: number;
  title: string;
  artist: string;
  duration: number;
  audioUrl: string;
  genre?: string;
  therapeutic_use?: string;
}

interface MoodOption {
  id: string;
  label: string;
  description: string;
  energy: number;
  valence: number;
}

// All 11 authentic therapeutic goals from VAD analysis system
const MOOD_OPTIONS: MoodOption[] = [
  { id: 'focus', label: 'Focus', description: 'Concentration', energy: 6, valence: 7 },
  { id: 'energy_boost', label: 'Energy', description: 'Boost', energy: 9, valence: 8 },
  { id: 'deep_sleep', label: 'Sleep', description: 'Rest', energy: 1, valence: 5 },
  { id: 'mood_enhancement', label: 'Mood+', description: 'Enhance', energy: 7, valence: 8 },
  { id: 'gentle_relaxation', label: 'Relax', description: 'Calm', energy: 2, valence: 6 },
  { id: 'anxiety_reduction', label: 'Anxiety', description: 'Relief', energy: 3, valence: 5 },
  { id: 'meditation', label: 'Meditation & Pain Management', description: 'Mindful', energy: 2, valence: 7 },
  { id: 'emotional_balance', label: 'Balance', description: 'Harmony', energy: 4, valence: 6 },
  { id: 'motivation', label: 'Motivate', description: 'Drive', energy: 8, valence: 8 },
  { id: 'grounding', label: 'Ground', description: 'Center', energy: 3, valence: 6 },
  { id: 'joy_cultivation', label: 'Joy', description: 'Uplift', energy: 7, valence: 9 }
];

interface AIPlaylist {
  tracks: Track[];
  mood: string;
  totalDuration: number;
  message: string;
}

interface MergedAIDJPageProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
}

export default function MergedAIDJPage({ onPlayTrack, currentTrack }: MergedAIDJPageProps) {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [currentPlaylist, setCurrentPlaylist] = useState<AIPlaylist | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [favorites, setFavorites] = useState<Track[]>([]);
  const [availableGenres, setAvailableGenres] = useState<string[]>([]);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('neurotunes-favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  // Load available genres from actual music library
  useEffect(() => {
    const loadGenres = async () => {
      try {
        const response = await fetch('/api/genres');
        if (response.ok) {
          const genres = await response.json();
          console.log('Loaded genres:', genres);
          // Filter and shorten genre names for better UI
          const shortGenres = genres
            .filter((g: string) => ['classical', 'baroque', 'edm', 'house', 'electronic', 'flamenco', 'jazz', 'blues', 'rock'].some(main => g.toLowerCase().includes(main)))
            .map((g: string) => {
              if (g.toLowerCase().includes('classical')) return 'Classical';
              if (g.toLowerCase().includes('baroque')) return 'Baroque';
              if (g.toLowerCase().includes('edm')) return 'EDM';
              if (g.toLowerCase().includes('house')) return 'House';
              if (g.toLowerCase().includes('electronic')) return 'Electronic';
              if (g.toLowerCase().includes('flamenco')) return 'Flamenco';
              if (g.toLowerCase().includes('jazz') || g.toLowerCase().includes('big band')) return 'Jazz';
              if (g.toLowerCase().includes('blues')) return 'Blues';
              if (g.toLowerCase().includes('rock')) return 'Rock';
              return g;
            })
            .filter((g, i, arr) => arr.indexOf(g) === i) // Remove duplicates
            .slice(0, 8);
          setAvailableGenres(shortGenres);
        } else {
          console.error('Failed to load genres - response not ok:', response.status);
          // Fallback to basic styles if endpoint fails
          setAvailableGenres(['Classical', 'Baroque', 'EDM', 'House', 'Jazz']);
        }
      } catch (error) {
        console.error('Failed to load genres:', error);
        // Fallback to basic styles if endpoint fails
        setAvailableGenres(['Classical', 'Baroque', 'EDM', 'House', 'Jazz']);
      }
    };

    loadGenres();
  }, []);

  const trackCount = 10;

  const handleMoodSelect = (moodId: string) => {
    setSelectedMood(moodId);
    setCurrentPlaylist(null);
  };

  const toggleFavorite = (track: Track) => {
    const isFavorite = favorites.some(fav => fav.id === track.id);
    const newFavorites = isFavorite 
      ? favorites.filter(fav => fav.id !== track.id)
      : [...favorites, track];
    
    setFavorites(newFavorites);
    localStorage.setItem('neurotunes-favorites', JSON.stringify(newFavorites));
  };

  const generatePlaylist = async (goalId: string) => {
    if (!selectedGenre) return;
    
    setIsGenerating(true);
    try {
      const response = await fetch('/api/generate-playlist', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          goal: goalId, 
          genre: selectedGenre,
          count: trackCount 
        })
      });
      
      if (response.ok) {
        const playlist = await response.json();
        setCurrentPlaylist(playlist);
      }
    } catch (error) {
      console.error('Error generating playlist:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      color: 'white',
      overflow: 'auto',
      paddingBottom: '120px'
    }}>
      {/* Header */}
      <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '600', marginBottom: '8px' }}>AI DJ</h1>
        <p style={{ color: '#a5b4fc', fontSize: '14px', opacity: 0.9 }}>
          Select your current mood for personalized therapeutic music
        </p>
      </div>

      {/* Mood Prompt */}
      <div style={{ padding: '0 20px', maxWidth: '600px', margin: '0 auto' }}>
        <div style={{ 
          background: 'rgba(59, 130, 246, 0.1)', 
          border: '1px solid rgba(59, 130, 246, 0.3)',
          borderRadius: '12px', 
          padding: '20px', 
          marginBottom: '24px', 
          textAlign: 'center' 
        }}>
          <h3 style={{ fontSize: '18px', marginBottom: '8px', fontWeight: '600' }}>
            How are you feeling today?
          </h3>
          <p style={{ color: '#a5b4fc', fontSize: '14px' }}>
            Choose your therapeutic goal for personalized music
          </p>
        </div>

        {/* All 11 Therapeutic Goals with Visual Sprites */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', 
          gap: '12px',
          marginBottom: '32px'
        }}>
          {MOOD_OPTIONS.map((mood) => {
            const getSprite = (label: string) => {
              const spriteMap: { [key: string]: string } = {
                'Focus': 'F', 'Energy': 'E', 'Sleep': 'S', 'Mood+': 'M', 
                'Relax': 'R', 'Anxiety': 'A', 'Meditate': 'Z', 'Balance': 'B',
                'Motivate': 'V', 'Ground': 'G', 'Joy': 'J'
              };
              return spriteMap[label] || label[0];
            };

            const getColor = (label: string) => {
              const colorMap: { [key: string]: string } = {
                'Focus': '#3b82f6', 'Energy': '#f59e0b', 'Sleep': '#6366f1', 'Mood+': '#ec4899', 
                'Relax': '#10b981', 'Anxiety': '#ef4444', 'Meditate': '#8b5cf6', 'Balance': '#06b6d4',
                'Motivate': '#f97316', 'Ground': '#84cc16', 'Joy': '#eab308'
              };
              return colorMap[label] || '#6b7280';
            };

            return (
              <div
                key={mood.id}
                onClick={() => handleMoodSelect(mood.id)}
                style={{
                  padding: '16px',
                  background: selectedMood === mood.id 
                    ? `${getColor(mood.label)}20` 
                    : 'rgba(12, 25, 41, 0.7)',
                  border: selectedMood === mood.id 
                    ? `2px solid ${getColor(mood.label)}` 
                    : '1px solid rgba(59, 130, 246, 0.2)',
                  borderRadius: '12px',
                  cursor: 'pointer',
                  transition: 'all 0.2s ease',
                  textAlign: 'center'
                }}
                onMouseEnter={(e) => {
                  if (selectedMood !== mood.id) {
                    e.currentTarget.style.background = `${getColor(mood.label)}15`;
                  }
                }}
                onMouseLeave={(e) => {
                  if (selectedMood !== mood.id) {
                    e.currentTarget.style.background = 'rgba(12, 25, 41, 0.7)';
                  }
                }}
              >
                {/* Therapeutic Goal Sprite */}
                <div style={{
                  width: '48px',
                  height: '48px',
                  background: selectedMood === mood.id 
                    ? `linear-gradient(135deg, ${getColor(mood.label)} 0%, ${getColor(mood.label)}cc 100%)` 
                    : 'linear-gradient(135deg, #374151 0%, #1f2937 100%)',
                  borderRadius: '12px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 12px',
                  fontSize: '20px',
                  fontWeight: '800',
                  color: 'white',
                  transition: 'all 0.2s ease'
                }}>
                  {getSprite(mood.label)}
                </div>
                <div style={{ fontSize: '14px', fontWeight: '600', marginBottom: '4px' }}>
                  {mood.label}
                </div>
                <div style={{ fontSize: '11px', color: '#a5b4fc', opacity: 0.8 }}>
                  {mood.description}
                </div>
              </div>
            );
          })}
        </div>

        {/* Genre Selection (shown when mood is selected) */}
        {selectedMood && (
          <div style={{ marginBottom: '32px' }}>
            <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '16px', textAlign: 'center' }}>
              Choose Your Style
            </h3>
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', 
              gap: '12px',
              marginBottom: '24px'
            }}>
              {availableGenres.map((genre) => (
                <div
                  key={genre}
                  onClick={() => setSelectedGenre(genre)}
                  style={{
                    padding: '12px',
                    background: selectedGenre === genre 
                      ? 'rgba(59, 130, 246, 0.3)' 
                      : 'rgba(12, 25, 41, 0.4)',
                    border: selectedGenre === genre 
                      ? '2px solid #3b82f6' 
                      : '1px solid rgba(59, 130, 246, 0.2)',
                    borderRadius: '12px',
                    color: 'white',
                    fontSize: '13px',
                    fontWeight: '500',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease',
                    textAlign: 'center'
                  }}
                >
                  {/* Album Art for Genre */}
                  <div style={{
                    width: '60px',
                    height: '60px',
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
                    borderRadius: '8px',
                    margin: '0 auto 8px',
                    overflow: 'hidden',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '24px',
                    fontWeight: '800',
                    color: 'white'
                  }}>
                    {genre[0]}
                  </div>
                  <div>{genre}</div>
                </div>
              ))}
            </div>

            {/* Generate Playlist Button */}
            {selectedGenre && (
              <div style={{ textAlign: 'center' }}>
                <button
                  onClick={() => generatePlaylist(selectedMood)}
                  disabled={isGenerating}
                  style={{
                    padding: '16px 32px',
                    background: isGenerating 
                      ? 'rgba(59, 130, 246, 0.4)' 
                      : 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
                    border: 'none',
                    borderRadius: '16px',
                    color: 'white',
                    fontSize: '16px',
                    fontWeight: '600',
                    cursor: isGenerating ? 'not-allowed' : 'pointer',
                    transition: 'all 0.2s ease',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '8px',
                    margin: '0 auto'
                  }}
                >
                  {isGenerating ? (
                    <>
                      <div style={{
                        width: '16px',
                        height: '16px',
                        border: '2px solid rgba(255, 255, 255, 0.3)',
                        borderTop: '2px solid white',
                        borderRadius: '50%',
                        animation: 'spin 1s linear infinite'
                      }}></div>
                      Creating...
                    </>
                  ) : (
                    <>
                      <Sparkles size={16} />
                      Generate AI Playlist
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}

        {/* Generated Playlist */}
        {currentPlaylist && currentPlaylist.tracks && (
          <div style={{ marginTop: '32px' }}>
            <div style={{ 
              textAlign: 'center', 
              marginBottom: '24px',
              padding: '20px',
              background: 'rgba(12, 25, 41, 0.6)',
              borderRadius: '16px',
              border: '1px solid rgba(59, 130, 246, 0.3)'
            }}>
              <h3 style={{ fontSize: '20px', fontWeight: '600', marginBottom: '8px' }}>
                🎵 Your {currentPlaylist.mood} Playlist
              </h3>
              <p style={{ color: '#a5b4fc', fontSize: '14px', opacity: 0.8 }}>
                {currentPlaylist.message}
              </p>
              <p style={{ color: '#a5b4fc', fontSize: '12px', opacity: 0.6, marginTop: '8px' }}>
                {currentPlaylist.tracks.length} tracks • {Math.floor(currentPlaylist.totalDuration / 60)} minutes
              </p>
            </div>

            <div style={{ 
              background: 'rgba(12, 25, 41, 0.4)', 
              borderRadius: '16px', 
              padding: '16px',
              border: '1px solid rgba(59, 130, 246, 0.2)'
            }}>
              {currentPlaylist.tracks.map((track, index) => (
                <div
                  key={track.id}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: '12px',
                    padding: '12px',
                    background: currentTrack?.id === track.id 
                      ? 'rgba(59, 130, 246, 0.2)' 
                      : 'transparent',
                    borderRadius: '12px',
                    marginBottom: index < currentPlaylist.tracks.length - 1 ? '8px' : '0',
                    cursor: 'pointer',
                    transition: 'all 0.2s ease'
                  }}
                  onClick={() => onPlayTrack(track)}
                >
                  <span style={{ 
                    fontSize: '14px', 
                    color: '#a5b4fc', 
                    opacity: 0.6,
                    minWidth: '24px'
                  }}>
                    {index + 1}
                  </span>
                  
                  <div style={{ 
                    width: '40px', 
                    height: '40px', 
                    background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)', 
                    borderRadius: '8px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0
                  }}>
                    <Play size={16} fill="white" />
                  </div>
                  
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <h3 style={{ 
                      fontSize: '13px', 
                      fontWeight: '500', 
                      marginBottom: '2px',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }}>
                      {track.title}
                    </h3>
                    <p style={{ 
                      fontSize: '11px', 
                      color: '#a5b4fc', 
                      opacity: 0.7,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }}>
                      {track.artist || 'Unknown Artist'}
                    </p>
                  </div>
                  
                  <span style={{ 
                    fontSize: '11px', 
                    color: '#a5b4fc', 
                    opacity: 0.6,
                    flexShrink: 0
                  }}>
                    {Math.floor(track.duration / 60)}:{(track.duration % 60).toString().padStart(2, '0')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}