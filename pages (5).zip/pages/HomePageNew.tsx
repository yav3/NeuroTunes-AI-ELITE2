import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        {/* Card container */}
        <div className="card text-center backdrop-blur-sm">
          {/* Header */}
          <h1 className="text-xl font-medium text-slate-200 mb-8">
            How are you feeling?
          </h1>

          {/* Moon and mountain illustration */}
          <div className="relative h-24 mb-8 flex items-center justify-center">
            <svg width="120" height="80" viewBox="0 0 120 80" className="text-slate-400/60">
              {/* Mountains */}
              <path d="M0 60 L30 30 L60 50 L90 20 L120 40 L120 80 L0 80 Z" fill="currentColor" opacity="0.3"/>
              <path d="M0 70 L20 45 L40 55 L60 35 L80 45 L100 25 L120 35 L120 80 L0 80 Z" fill="currentColor" opacity="0.4"/>
              
              {/* Moon */}
              <circle cx="85" cy="25" r="12" stroke="currentColor" strokeWidth="1.5" fill="none"/>
              <path d="M85 13 A 8 8 0 0 0 85 37" fill="currentColor" opacity="0.6"/>
              
              {/* Stars */}
              <circle cx="35" cy="15" r="1" fill="currentColor" opacity="0.8"/>
              <circle cx="50" cy="10" r="0.5" fill="currentColor" opacity="0.6"/>
              <circle cx="70" cy="18" r="0.5" fill="currentColor" opacity="0.7"/>
            </svg>
          </div>

          {/* Mood buttons */}
          <div className="space-y-3 mb-8">
            <button className="w-full px-4 py-3 text-left text-slate-300 text-sm hover:bg-slate-700/30 rounded-lg transition-colors">
              Negative
            </button>
            <button className="w-full px-4 py-3 text-left text-slate-300 text-sm hover:bg-slate-700/30 rounded-lg transition-colors">
              Neutral
            </button>
            <button className="w-full px-4 py-3 text-left text-slate-300 text-sm hover:bg-slate-700/30 rounded-lg transition-colors">
              Positive
            </button>
          </div>

          {/* Action buttons */}
          <div className="space-y-3">
            <button 
              onClick={() => navigate('/tracks')}
              className="w-full text-sm text-slate-400 hover:text-slate-300 transition-colors"
            >
              Browse Music
            </button>
            <button className="w-full text-sm text-slate-400 hover:text-slate-300 transition-colors">
              View history
            </button>
          </div>

          {/* Start Therapy button */}
          <button 
            onClick={() => navigate('/emotions')}
            className="btn w-full mt-6 text-white"
          >
            Start Therapy
          </button>
        </div>
      </div>
    </div>
  );
}