import { useState, useEffect } from 'react';
import { useDeviceContext } from '../hooks/useDeviceContext';

interface Track {
  id: number;
  title: string;
  artist: string;
  audioUrl?: string;
  duration: number;
}

interface SimpleAIDJPageProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
}

// Authentic therapeutic categories from July 8th inventory plus additional categories from VAD analysis
const THERAPEUTIC_GOALS = [
  'focus',
  'mood_boost', 
  'relaxation',
  'meditation',
  'energy_boost',
  'sleep_enhancement',
  'anxiety_management',
  'stress_relief'
];

// Authentic genres found in user's music library (derived from actual filenames)
const GENRES = [
  'Classical',
  'Classical Crossover', 
  'New Age & World',
  'electronic',
  'folk',
  'indie',
  'jazz',
  'rock'
];

export default function SimpleAIDJPage({ onPlayTrack, currentTrack }: SimpleAIDJPageProps) {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [selectedGoal, setSelectedGoal] = useState<string>('');
  const [selectedGenre, setSelectedGenre] = useState<string>('');
  const [playlist, setPlaylist] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectionStep, setSelectionStep] = useState<'goal' | 'genre' | 'complete'>('goal');
  const deviceContext = useDeviceContext();

  useEffect(() => {
    // Load all tracks
    fetch('/api/tracks')
      .then(res => res.json())
      .then(data => {
        setTracks(data.catalog || []);
      })
      .catch(err => console.error('Error loading tracks:', err));
  }, []);

  const handleGoalSelect = (goal: string) => {
    setSelectedGoal(goal);
    setSelectionStep('genre'); // Move to genre selection step
  };

  const handleGenreSelect = (genre: string) => {
    setSelectedGenre(genre);
    setSelectionStep('complete');
    // Generate playlist with both goal and genre
    generateCombinedPlaylist(selectedGoal, genre);
  };

  const generateCombinedPlaylist = (goal: string, genre: string) => {
    setLoading(true);
    
    // Generate playlist based on both therapeutic goal and genre
    fetch('/api/ai-dj/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        mood: goal,
        genre: genre,
        duration: 60,
        intensity: 'medium'
      })
    })
    .then(res => res.json())
    .then(data => {
      const resultTracks = data.tracks || [];
      setPlaylist(resultTracks);
      setLoading(false);
    })
    .catch(err => {
      console.log('Using fallback combined selection:', err);
      
      // Special fallback: Classical + Focus = use classical-focus endpoint
      if (genre.toLowerCase() === 'classical' && goal === 'focus') {
        fetch('/api/tracks/classical-focus')
          .then(res => res.json())
          .then(classicalTracks => {
            setPlaylist(classicalTracks.slice(0, 15));
            setLoading(false);
          })
          .catch(() => {
            // Final fallback: filter existing tracks
            const filteredTracks = tracks.filter(track => {
              const title = track.title.toLowerCase();
              return title.startsWith('focus-') || title.startsWith('focus on') || title.startsWith('focus ');
            });
            setPlaylist(filteredTracks.slice(0, 15));
            setLoading(false);
          });
      } else {
        // Regular fallback: filter tracks by both criteria
        const filteredTracks = tracks.filter(track => {
          const matchesGenre = track.title.toLowerCase().includes(genre.toLowerCase()) ||
            (track as any).genre?.toLowerCase().includes(genre.toLowerCase());
          return matchesGenre;
        });
        
        setPlaylist(filteredTracks.slice(0, 15));
        setLoading(false);
      }
    });
  };

  const resetSelection = () => {
    setSelectedGoal('');
    setSelectedGenre('');
    setPlaylist([]);
    setSelectionStep('goal');
  };

  const getGoalLabel = (goal: string) => {
    const labels: { [key: string]: string } = {
      'focus': 'Focus',
      'mood_boost': 'Mood Boost',
      'relaxation': 'Relaxation',
      'meditation': 'Meditation & Pain Management',
      'energy_boost': 'Energy Boost',
      'sleep_enhancement': 'Sleep Enhancement',
      'anxiety_management': 'Anxiety Management',
      'stress_relief': 'Stress Relief'
    };
    return labels[goal] || goal;
  };

  const getGoalSprite = (goal: string) => {
    const sprites: { [key: string]: string } = {
      'focus': 'F',
      'mood_boost': 'M',
      'relaxation': 'R',
      'meditation': 'D',
      'energy_boost': 'E',
      'sleep_enhancement': 'S',
      'anxiety_management': 'A',
      'stress_relief': 'T'
    };
    return sprites[goal] || goal[0].toUpperCase();
  };

  const getGoalColor = (goal: string) => {
    // Use consistent brand blue for all therapeutic goals
    return '#3b82f6';
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      color: 'white',
      overflow: 'auto',
      paddingBottom: '120px'
    }}>
      {/* Content */}
      <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
        <p style={{ 
          color: '#a5b4fc', 
          fontSize: '16px', 
          opacity: 0.9, 
          marginBottom: '32px',
          fontWeight: '400',
          lineHeight: '1.5'
        }}>
          {selectionStep === 'goal' && 'Step 1: Select your therapeutic goal for personalized wellness music'}
          {selectionStep === 'genre' && `Step 2: Choose a genre to complement your ${getGoalLabel(selectedGoal)} goal`}
          {selectionStep === 'complete' && `Your personalized ${getGoalLabel(selectedGoal)} playlist with ${selectedGenre} music`}
        </p>

        {/* Progress Indicator */}
        {(selectionStep === 'genre' || selectionStep === 'complete') && (
          <div style={{ 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center',
            gap: '12px',
            marginBottom: '24px',
            padding: '12px 20px',
            background: 'rgba(59, 130, 246, 0.1)',
            borderRadius: '12px',
            border: '1px solid rgba(59, 130, 246, 0.2)'
          }}>
            <div style={{
              padding: '6px 12px',
              background: '#3b82f6',
              borderRadius: '8px',
              fontSize: '14px',
              fontWeight: '500'
            }}>
              {getGoalLabel(selectedGoal)}
            </div>
            {selectionStep === 'complete' && (
              <>
                <span style={{ color: '#a5b4fc' }}>+</span>
                <div style={{
                  padding: '6px 12px',
                  background: '#8b5cf6',
                  borderRadius: '8px',
                  fontSize: '14px',
                  fontWeight: '500'
                }}>
                  {selectedGenre}
                </div>
                <button
                  onClick={resetSelection}
                  style={{
                    marginLeft: '12px',
                    padding: '4px 8px',
                    background: 'rgba(255, 255, 255, 0.1)',
                    border: '1px solid rgba(255, 255, 255, 0.2)',
                    borderRadius: '6px',
                    color: '#a5b4fc',
                    fontSize: '12px',
                    cursor: 'pointer'
                  }}
                >
                  Reset
                </button>
              </>
            )}
          </div>
        )}
      </div>

      {/* Selection Grid - only show if not completed */}
      {selectionStep !== 'complete' && (
        <div style={{ padding: '0 20px', maxWidth: '600px', margin: '0 auto' }}>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(2, 1fr)', 
            gap: '16px',
            marginBottom: '32px'
          }}>
            {selectionStep === 'goal' ? THERAPEUTIC_GOALS.map((goal) => (
              <div
                key={goal}
                onClick={() => handleGoalSelect(goal)}
                style={{
                  background: 'rgba(12, 25, 41, 0.7)',
                  border: '1px solid rgba(59, 130, 246, 0.2)',
                  borderRadius: '12px',
                  padding: '20px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  textAlign: 'center',
                  minHeight: '80px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.background = 'rgba(59, 130, 246, 0.1)';
                  e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.4)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.background = 'rgba(12, 25, 41, 0.7)';
                  e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.2)';
                }}
              >
                <div style={{
                  fontSize: '16px',
                  fontWeight: '500',
                  color: 'white',
                  lineHeight: '1.3'
                }}>
                  {getGoalLabel(goal)}
                </div>
              </div>
            )) : GENRES.map((genre) => (
              <div
                key={genre}
                onClick={() => handleGenreSelect(genre)}
                style={{
                  background: 'rgba(12, 25, 41, 0.7)',
                  border: '1px solid rgba(59, 130, 246, 0.2)',
                  borderRadius: '12px',
                  padding: '20px',
                  cursor: 'pointer',
                  transition: 'all 0.3s ease',
                  textAlign: 'center',
                  minHeight: '80px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.background = 'rgba(59, 130, 246, 0.1)';
                  e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.4)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.background = 'rgba(12, 25, 41, 0.7)';
                  e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.2)';
                }}
              >
                <div style={{
                  fontSize: '16px',
                  fontWeight: '500',
                  color: 'white',
                  lineHeight: '1.3'
                }}>
                  {genre}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Generated Playlist - only show when complete */}
      <div style={{ padding: '0 20px', maxWidth: '600px', margin: '0 auto' }}>
        {loading && (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <div style={{ 
              width: '32px', 
              height: '32px', 
              border: '3px solid rgba(59, 130, 246, 0.3)',
              borderTop: '3px solid #3b82f6',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto 16px'
            }}></div>
            <p style={{ 
              color: '#a5b4fc', 
              fontSize: '16px', 
              fontWeight: '500' 
            }}>
              Creating your personalized playlist...
            </p>
          </div>
        )}

        {playlist.length > 0 && !loading && selectionStep === 'complete' && (
          <div style={{ marginBottom: '32px' }}>
            <h3 style={{ 
              fontSize: '20px', 
              fontWeight: '700', 
              marginBottom: '20px',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              color: 'white'
            }}>
              <div style={{
                width: '32px',
                height: '32px',
                background: `linear-gradient(135deg, ${getGoalColor(selectedGoal)} 0%, ${getGoalColor(selectedGoal)}cc 100%)`,
                borderRadius: '10px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '16px',
                fontWeight: '700',
                color: 'white',
                boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)'
              }}>
                {getGoalSprite(selectedGoal)}
              </div>
              {getGoalLabel(selectedGoal)} + {selectedGenre}
              <span style={{ 
                fontSize: '14px', 
                color: '#a5b4fc', 
                fontWeight: '400',
                background: 'rgba(165, 180, 252, 0.1)',
                padding: '4px 12px',
                borderRadius: '12px'
              }}>
                {playlist.length} tracks
              </span>
            </h3>
            
            <div style={{ display: 'grid', gap: '12px' }}>
              {playlist.map((track, index) => (
                <div
                  key={track.id || index}
                  onClick={() => onPlayTrack(track)}
                  style={{
                    background: currentTrack?.id === track.id 
                      ? 'rgba(59, 130, 246, 0.2)' 
                      : 'rgba(12, 25, 41, 0.7)',
                    border: currentTrack?.id === track.id 
                      ? '1px solid rgba(59, 130, 246, 0.5)'
                      : '1px solid rgba(59, 130, 246, 0.1)',
                    borderRadius: '12px',
                    padding: '16px',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between'
                  }}
                  onMouseEnter={(e) => {
                    if (currentTrack?.id !== track.id) {
                      e.currentTarget.style.background = 'rgba(59, 130, 246, 0.1)';
                      e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.3)';
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (currentTrack?.id !== track.id) {
                      e.currentTarget.style.background = 'rgba(12, 25, 41, 0.7)';
                      e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.1)';
                    }
                  }}
                >
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <h4 style={{ 
                      fontSize: '16px', 
                      fontWeight: '600', 
                      marginBottom: '4px',
                      color: 'white',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap'
                    }}>
                      {track.title.split(/[;:()\-–]/)[0].trim()}
                    </h4>
                    <p style={{ 
                      fontSize: '14px', 
                      color: '#a5b4fc', 
                      fontWeight: '400',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap'
                    }}>
                      {track.artist}
                    </p>
                  </div>
                  <div style={{
                    width: '40px',
                    height: '40px',
                    background: currentTrack?.id === track.id 
                      ? 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)'
                      : 'rgba(59, 130, 246, 0.2)',
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: '14px',
                    color: 'white'
                  }}>
                    {currentTrack?.id === track.id ? '▐▐' : '▶'}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}