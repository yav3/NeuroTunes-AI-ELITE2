import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Home as HomeIcon, 
  Music, 
  Heart,
  Settings, 
  Shield,
  Brain,
  Library,
  TrendingUp,
  Activity
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

export default function WellnessPage() {
  const [, setLocation] = useLocation();

  const { data: moodHistory = [] } = useQuery({
    queryKey: ["/api/mood/history"],
  });

  const sidebarItems = [
    { icon: HomeIcon, label: "Dashboard", path: "/" },
    { icon: Library, label: "My Library", path: "/library" },
    { icon: Heart, label: "Wellness", path: "/wellness", active: true },
    { icon: Shield, label: "Admin", path: "/admin" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  const handleNavigation = (path: string) => {
    setLocation(path);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-800 via-blue-900 to-indigo-900">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-slate-800/95 backdrop-blur-xl border-r border-slate-700/50">
        {/* Header */}
        <div className="p-6 border-b border-slate-700/50">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-white">AI Music Wellness</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {sidebarItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavigation(item.path)}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors",
                item.active
                  ? "bg-blue-600/50 text-white"
                  : "text-slate-300 hover:bg-slate-700/50 hover:text-white"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="absolute bottom-6 left-4 right-4">
          <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-700/50">
            <div className="w-2 h-2 rounded-full bg-green-400"></div>
            <span className="text-sm text-slate-200">Brian</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-64 p-8">
        <div className="max-w-4xl space-y-6">
          {/* Wellness Journey Overview */}
          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Heart className="w-5 h-5" />
                <span>Your Wellness Journey</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-slate-700/50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Activity className="w-4 h-4 text-blue-400" />
                      <span className="text-sm text-slate-300">Sessions This Week</span>
                    </div>
                    <p className="text-2xl font-bold text-white">12</p>
                    <p className="text-xs text-slate-400">+3 from last week</p>
                  </div>
                  <div className="p-4 bg-slate-700/50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-green-400" />
                      <span className="text-sm text-slate-300">Wellness Score</span>
                    </div>
                    <p className="text-2xl font-bold text-white">78%</p>
                    <p className="text-xs text-slate-400">Improving trend</p>
                  </div>
                  <div className="p-4 bg-slate-700/50 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Music className="w-4 h-4 text-purple-400" />
                      <span className="text-sm text-slate-300">Therapeutic Minutes</span>
                    </div>
                    <p className="text-2xl font-bold text-white">340</p>
                    <p className="text-xs text-slate-400">This month</p>
                  </div>
                </div>

                {/* Journey Milestones */}
                <div className="space-y-3">
                  <h3 className="text-white font-medium">Recent Milestones</h3>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-3 p-3 bg-green-500/10 border border-green-500/20 rounded-lg">
                      <div className="w-2 h-2 rounded-full bg-green-400"></div>
                      <span className="text-green-400 text-sm">7-day listening streak achieved</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                      <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                      <span className="text-blue-400 text-sm">Stress levels decreased by 15%</span>
                    </div>
                    <div className="flex items-center space-x-3 p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg">
                      <div className="w-2 h-2 rounded-full bg-purple-400"></div>
                      <span className="text-purple-400 text-sm">Sleep quality improved</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Mood History */}
          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white">Complete Mood History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {moodHistory.map((entry, index) => (
                  <div key={entry.id} className="flex justify-between items-center p-3 bg-slate-700/30 rounded-lg">
                    <div>
                      <span className="text-slate-200">{entry.inputText}</span>
                      <p className="text-sm text-slate-400">
                        {new Date(entry.createdAt || '').toLocaleDateString()} at{' '}
                        {new Date(entry.createdAt || '').toLocaleTimeString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "border-slate-500/50 text-slate-300 bg-slate-500/10",
                          entry.detectedMood === "Positive" && "border-blue-500/50 text-blue-400 bg-blue-500/10",
                          entry.detectedMood === "Neutral" && "border-slate-500/50 text-slate-400 bg-slate-500/10"
                        )}
                      >
                        {entry.detectedMood}
                      </Badge>
                      <span className="text-sm text-slate-400">{Math.round(entry.confidence * 100)}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Wellness Tips */}
          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white">Personalized Wellness Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-500/10 border border-blue-500/20 rounded-lg">
                  <h3 className="text-blue-400 font-medium mb-2">Based on your recent stress patterns:</h3>
                  <p className="text-slate-300">Try listening to ambient music for 15 minutes during your afternoon break to help manage stress levels.</p>
                </div>
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-lg">
                  <h3 className="text-green-400 font-medium mb-2">Sleep improvement:</h3>
                  <p className="text-slate-300">Your evening sessions show positive results. Continue with calming music 30 minutes before bedtime.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}