import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Home as HomeIcon, 
  Music, 
  Heart,
  Settings, 
  Shield,
  Brain,
  Library,
  Play,
  HeartOff
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Track {
  id: number;
  title: string;
  artist: string;
  audioUrl: string | null;
  duration?: number;
  mood?: string;
  album?: string;
}

interface FavoriteTrack {
  id: number;
  userId: string;
  trackId: number;
  addedAt: string;
  track: Track;
}

export default function FavoritesPage() {
  const [, setLocation] = useLocation();
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const { toast } = useToast();

  const { data: favorites = [], isLoading: favoritesLoading, refetch } = useQuery({
    queryKey: ["/api/favorites"],
  });

  const removeFavoriteMutation = useMutation({
    mutationFn: async (trackId: number) => {
      return await apiRequest(`/api/favorites/${trackId}`, "DELETE", {});
    },
    onSuccess: () => {
      toast({
        title: "Removed from Favorites",
        description: "Track removed from your favorites",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Could not remove track from favorites",
        variant: "destructive",
      });
    },
  });

  const sidebarItems = [
    { icon: HomeIcon, label: "Dashboard", path: "/" },
    { icon: Library, label: "My Library", path: "/library" },
    { icon: Heart, label: "Favorites", path: "/favorites", active: true },
    { icon: Heart, label: "Wellness", path: "/wellness" },
    { icon: Shield, label: "Admin", path: "/admin" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  const handleNavigation = (path: string) => {
    setLocation(path);
  };

  const handlePlayTrack = (track: Track) => {
    setCurrentTrack(track);
    setIsPlaying(true);
  };

  const handleRemoveFavorite = (trackId: number) => {
    removeFavoriteMutation.mutate(trackId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-800 via-blue-900 to-indigo-900">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-slate-800/95 backdrop-blur-xl border-r border-slate-700/50">
        {/* Header */}
        <div className="p-6 border-b border-slate-700/50">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-white">AI Music Wellness</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {sidebarItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavigation(item.path)}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors",
                item.active
                  ? "bg-blue-600/50 text-white"
                  : "text-slate-300 hover:bg-slate-700/50 hover:text-white"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="absolute bottom-6 left-4 right-4">
          <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-700/50">
            <div className="w-2 h-2 rounded-full bg-green-400"></div>
            <span className="text-sm text-slate-200">Brian</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-64 p-8">
        <div className="max-w-4xl space-y-6">
          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Heart className="w-5 h-5" />
                <span>Your Favorite Tracks</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {favoritesLoading ? (
                <div className="text-center py-8">
                  <div className="text-slate-400">Loading your favorites...</div>
                </div>
              ) : favorites.length === 0 ? (
                <div className="text-center py-8">
                  <Heart className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <div className="text-slate-400 mb-4">No favorite tracks yet</div>
                  <p className="text-slate-500 text-sm">
                    Add tracks to your favorites from the music library or when listening
                  </p>
                  <Button
                    onClick={() => handleNavigation("/library")}
                    className="mt-4 bg-blue-600 hover:bg-blue-700"
                  >
                    Browse Music Library
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-center mb-4">
                    <p className="text-slate-300">{favorites.length} favorite tracks</p>
                  </div>
                  
                  <div className="grid gap-4">
                    {(favorites as FavoriteTrack[]).map((favorite) => (
                      <div key={favorite.id} className="flex items-center justify-between p-4 bg-slate-700/50 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 rounded-lg bg-blue-600 flex items-center justify-center">
                            <Music className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <p className="text-white font-medium">{favorite.track.title}</p>
                            <p className="text-slate-300 text-sm">{favorite.track.artist}</p>
                            {favorite.track.album && (
                              <p className="text-slate-400 text-xs">{favorite.track.album}</p>
                            )}
                            <p className="text-slate-500 text-xs">
                              Added {new Date(favorite.addedAt).toLocaleDateString()}
                            </p>
                            {favorite.track.mood && (
                              <Badge variant="outline" className="mt-1 border-blue-500/50 text-blue-400 bg-blue-500/10">
                                {favorite.track.mood}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={() => handlePlayTrack(favorite.track)}
                            variant="ghost"
                            size="sm"
                            className="text-slate-300 hover:bg-slate-600/50"
                          >
                            <Play className="w-5 h-5" />
                          </Button>
                          <Button
                            onClick={() => handleRemoveFavorite(favorite.track.id)}
                            disabled={removeFavoriteMutation.isPending}
                            variant="ghost"
                            size="sm"
                            className="text-red-400 hover:bg-red-500/20"
                          >
                            <HeartOff className="w-5 h-5" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Music Player */}
      {currentTrack && (
        <div className="fixed bottom-0 left-64 right-0 bg-slate-800/95 backdrop-blur-xl border-t border-slate-700/50 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-lg bg-blue-600 flex items-center justify-center">
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white font-medium">{currentTrack.title}</p>
                <p className="text-slate-300 text-sm">{currentTrack.artist}</p>
              </div>
              <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-slate-300 hover:bg-slate-700/50"
              >
                {isPlaying ? <Heart className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}