import React, { useState, useEffect } from 'react';
import { Heart, Play } from 'lucide-react';

interface Track {
  id: number;
  title: string;
  artist: string;
  duration: number;
  audioUrl: string;
  genre?: string;
  therapeutic_use?: string;
}

interface FavoritesPageProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
}

export default function FavoritesPage({ onPlayTrack, currentTrack }: FavoritesPageProps) {
  const [favorites, setFavorites] = useState<Track[]>([]);

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('neurotunes-favorites');
    if (savedFavorites) {
      try {
        setFavorites(JSON.parse(savedFavorites));
      } catch (error) {
        console.error('Error loading favorites:', error);
        setFavorites([]);
      }
    }
  }, []);

  const removeFavorite = (track: Track) => {
    const newFavorites = favorites.filter(fav => fav.id !== track.id);
    setFavorites(newFavorites);
    localStorage.setItem('neurotunes-favorites', JSON.stringify(newFavorites));
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      color: 'white',
      overflow: 'auto',
      paddingBottom: '120px'
    }}>
      {/* Header */}
      <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
        <h1 style={{ fontSize: '28px', fontWeight: '600', marginBottom: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
          <Heart size={28} fill="currentColor" />
          Favorites
        </h1>
        <p style={{ color: '#a5b4fc', fontSize: '14px', opacity: 0.9 }}>
          Your personalized therapeutic music collection
        </p>
      </div>

      <div style={{ padding: '0 20px', maxWidth: '600px', margin: '0 auto' }}>
        {favorites.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: '60px 20px',
            background: 'rgba(12, 25, 41, 0.6)',
            borderRadius: '16px',
            border: '1px solid rgba(59, 130, 246, 0.3)'
          }}>
            <Heart size={48} style={{ opacity: 0.5, marginBottom: '16px' }} />
            <h3 style={{ fontSize: '18px', fontWeight: '600', marginBottom: '8px' }}>
              No favorites yet
            </h3>
            <p style={{ color: '#a5b4fc', fontSize: '14px', opacity: 0.8 }}>
              Start adding tracks to your favorites from the trending page or AI DJ
            </p>
          </div>
        ) : (
          <div style={{
            display: 'grid',
            gap: '12px'
          }}>
            {favorites.map((track) => (
              <div
                key={track.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px',
                  padding: '12px',
                  background: currentTrack?.id === track.id 
                    ? 'rgba(59, 130, 246, 0.2)' 
                    : 'rgba(12, 25, 41, 0.6)',
                  border: currentTrack?.id === track.id 
                    ? '2px solid #3b82f6' 
                    : '1px solid rgba(59, 130, 246, 0.3)',
                  borderRadius: '12px',
                  transition: 'all 0.2s ease'
                }}
              >
                {/* Album Art */}
                <div style={{
                  width: '60px',
                  height: '60px',
                  background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
                  borderRadius: '8px',
                  overflow: 'hidden',
                  flexShrink: 0
                }}>
                  <img 
                    src={`/api/art/${encodeURIComponent(track.title)}`}
                    alt={`${track.title} album art`}
                    style={{
                      width: '100%',
                      height: '100%',
                      objectFit: 'cover'
                    }}
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                </div>

                {/* Track Info */}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <h4 style={{
                    fontSize: '14px',
                    fontWeight: '600',
                    marginBottom: '4px',
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                  }}>
                    {track.title}
                  </h4>
                  <p style={{
                    fontSize: '12px',
                    color: '#a5b4fc',
                    opacity: 0.8,
                    whiteSpace: 'nowrap',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                  }}>
                    {track.artist || 'Original Composition'}
                  </p>
                </div>

                {/* Controls */}
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                  <button
                    onClick={() => onPlayTrack(track)}
                    style={{
                      width: '36px',
                      height: '36px',
                      background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
                      border: 'none',
                      borderRadius: '8px',
                      color: 'white',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      transition: 'all 0.2s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'scale(1.05)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'scale(1)';
                    }}
                  >
                    <Play size={16} fill="white" />
                  </button>
                  
                  <button
                    onClick={() => removeFavorite(track)}
                    style={{
                      width: '36px',
                      height: '36px',
                      background: 'rgba(239, 68, 68, 0.2)',
                      border: '1px solid rgba(239, 68, 68, 0.4)',
                      borderRadius: '8px',
                      color: '#ef4444',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      transition: 'all 0.2s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(239, 68, 68, 0.3)';
                      e.currentTarget.style.transform = 'scale(1.05)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'rgba(239, 68, 68, 0.2)';
                      e.currentTarget.style.transform = 'scale(1)';
                    }}
                  >
                    <Heart size={16} fill="currentColor" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}