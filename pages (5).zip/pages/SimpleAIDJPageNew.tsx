import React, { useState, useEffect } from 'react';
import { Music, ArrowRight, RotateCcw } from 'lucide-react';

interface Track {
  id: number;
  title: string;
  artist: string;
  filename: string;
  audioUrl: string;
  duration: number;
  mood?: string;
  genre?: string;
  therapeuticTags?: string[];
  bpm?: number;
}

interface SimpleAIDJPageNewProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
}

const SimpleAIDJPageNew: React.FC<SimpleAIDJPageNewProps> = ({ onPlayTrack, currentTrack }) => {
  const [step, setStep] = useState<'mood' | 'goal' | 'playlist'>('mood');
  const [userMood, setUserMood] = useState<string>('');
  const [selectedGoal, setSelectedGoal] = useState<string>('');
  const [playlist, setPlaylist] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);

  // Authentic therapeutic goals from user's VAD analysis data
  const therapeuticGoals = [
    'Relaxation & Stress Relief',
    'Sleep Enhancement', 
    'Focus',
    'Mood Enhancement',
    'Anxiety Management',
    'Energy'
  ];



  const handleMoodSubmit = (mood: string) => {
    setUserMood(mood);
    setStep('goal');
  };

  const handleGoalSelect = async (goal: string) => {
    setSelectedGoal(goal);
    setLoading(true);
    setStep('playlist');
    
    try {
      // Generate playlist directly from therapeutic goal - NO genre selection
      const response = await fetch('/api/tracks/mood/' + goal.toLowerCase().replace(/\s+/g, '_').replace('&', ''));
      if (response.ok) {
        const tracks = await response.json();
        setPlaylist(tracks.slice(0, 20)); // Show first 20 tracks
      } else {
        console.error('Failed to load tracks for goal:', goal);
      }
    } catch (error) {
      console.error('Error generating playlist:', error);
    } finally {
      setLoading(false);
    }
  };



  const resetFlow = () => {
    setStep('mood');
    setUserMood('');
    setSelectedGoal('');
    setPlaylist([]);
  };

  return (
    <div className="mx-auto max-w-screen-sm">
      <div className="pt-2 pb-6">
        
        {/* Header */}
        <div className="text-center mb-10">
          <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 border-2 border-blue-400/30 flex items-center justify-center">
            <Music className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-extrabold tracking-tight text-center text-white">
            AI DJ Studio
          </h1>
          <p className="mt-2 text-center text-blue-200">
            Sequential therapeutic music selection
          </p>
        </div>

        {/* Progress Indicator */}
        <div className="flex justify-center mb-10 gap-3">
          {['mood', 'goal', 'playlist'].map((s, index) => {
            const stepIndex = ['mood', 'goal', 'playlist'].indexOf(step);
            const isCompleted = index < stepIndex;
            const isCurrent = step === s;
            
            return (
              <div 
                key={s} 
                className={`w-3 h-3 rounded-full transition-all duration-300 ${
                  isCurrent || isCompleted
                    ? 'bg-gradient-to-br from-blue-500 to-purple-600' 
                    : 'bg-blue-500/20'
                } ${
                  isCurrent ? 'scale-110 ring-2 ring-blue-400/50' : 'scale-100'
                }`}
              />
            );
          })}
        </div>

        {/* Step 1: Mood Check */}
        {step === 'mood' && (
          <div className="bg-slate-900/40 backdrop-blur-xl border border-blue-500/30 rounded-3xl p-8 text-center">
            <h2 className="text-2xl font-semibold mb-4 text-white">
              How are you feeling today?
            </h2>
            <p className="text-blue-200 mb-6">
              Share your current mood to get personalized therapeutic music recommendations
            </p>
            <div className="flex flex-col gap-3 max-w-md mx-auto">
              <textarea
                value={userMood}
                onChange={(e) => setUserMood(e.target.value)}
                placeholder="Tell me how you're feeling... (e.g., 'I feel stressed and need to relax', 'I need energy for my workout', 'I want to focus on work')"
                className="bg-slate-800/60 border border-blue-500/30 rounded-xl p-4 text-white resize-none min-h-[100px] placeholder-blue-300/60"
              />
              <button
                onClick={() => userMood.trim() && handleMoodSubmit(userMood)}
                disabled={!userMood.trim()}
                className={`flex items-center justify-center gap-2 rounded-xl p-4 font-semibold transition-all ${
                  userMood.trim() 
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 cursor-pointer'
                    : 'bg-blue-500/30 cursor-not-allowed'
                } text-white`}
              >
                Continue <ArrowRight size={20} />
              </button>
            </div>
          </div>
        )}

        {/* Step 2: Therapeutic Goal Selection */}
        {step === 'goal' && (
          <div className="bg-slate-900/40 backdrop-blur-xl border border-blue-500/30 rounded-3xl p-8 text-center">
            <h2 className="text-2xl font-semibold mb-4 text-white">
              Select Your Therapeutic Goal
            </h2>
            <p className="text-blue-200 mb-6">
              Choose what you want to achieve with music therapy
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg mx-auto">
              {therapeuticGoals.map((goal) => (
                <button
                  key={goal}
                  onClick={() => handleGoalSelect(goal)}
                  style={{
                    background: 'rgba(15, 23, 42, 0.6)',
                    border: '1px solid rgba(59, 130, 246, 0.3)',
                    borderRadius: '12px',
                    padding: '16px',
                    color: 'white',
                    fontSize: '16px',
                    fontWeight: '500',
                    cursor: 'pointer',
                    transition: 'all 0.3s ease',
                    textAlign: 'center'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)';
                    e.currentTarget.style.transform = 'translateY(-2px)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = 'rgba(15, 23, 42, 0.6)';
                    e.currentTarget.style.transform = 'translateY(0)';
                  }}
                >
                  {goal}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 3: Generated Playlist */}
        {step === 'playlist' && (
          <div style={{
            background: 'rgba(15, 23, 42, 0.4)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            borderRadius: '20px',
            padding: '32px'
          }}>
            {loading ? (
              <div style={{ textAlign: 'center' }}>
                <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '16px' }}>
                  Generating Your Playlist...
                </h2>
                <p style={{ color: '#a5b4fc', marginBottom: '24px' }}>
                  Creating a personalized playlist for {selectedGoal.toLowerCase()}
                </p>
                <div style={{
                  width: '40px',
                  height: '40px',
                  border: '4px solid rgba(59, 130, 246, 0.3)',
                  borderTop: '4px solid #3b82f6',
                  borderRadius: '50%',
                  animation: 'spin 1s linear infinite',
                  margin: '0 auto'
                }} />
              </div>
            ) : (
              <>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                  <div>
                    <h2 style={{ fontSize: '24px', fontWeight: '600', marginBottom: '8px' }}>
                      Your Therapeutic Playlist
                    </h2>
                    <p style={{ color: '#a5b4fc', margin: '0' }}>
                      {selectedGoal} • {playlist.length} tracks
                    </p>
                  </div>
                  <button
                    onClick={resetFlow}
                    style={{
                      background: 'rgba(59, 130, 246, 0.2)',
                      border: '1px solid rgba(59, 130, 246, 0.3)',
                      borderRadius: '8px',
                      padding: '8px 16px',
                      color: '#a5b4fc',
                      fontSize: '14px',
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px'
                    }}
                  >
                    <RotateCcw size={16} /> Start Over
                  </button>
                </div>

                <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
                  {playlist.map((track, index) => (
                    <div
                      key={track.id}
                      onClick={() => onPlayTrack(track)}
                      style={{
                        background: currentTrack?.id === track.id 
                          ? 'linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%)'
                          : 'rgba(15, 23, 42, 0.6)',
                        border: '1px solid rgba(59, 130, 246, 0.3)',
                        borderRadius: '12px',
                        padding: '16px',
                        marginBottom: '12px',
                        cursor: 'pointer',
                        transition: 'all 0.3s ease'
                      }}
                      onMouseEnter={(e) => {
                        if (currentTrack?.id !== track.id) {
                          e.currentTarget.style.background = 'rgba(59, 130, 246, 0.2)';
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (currentTrack?.id !== track.id) {
                          e.currentTarget.style.background = 'rgba(15, 23, 42, 0.6)';
                        }
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                          <h3 style={{ fontSize: '16px', fontWeight: '600', margin: '0 0 4px' }}>
                            {track.title}
                          </h3>
                          <p style={{ color: '#a5b4fc', fontSize: '14px', margin: '0' }}>
                            {track.artist || 'Neural Positive Music'}
                          </p>
                        </div>
                        <div style={{ color: '#a5b4fc', fontSize: '14px' }}>
                          {Math.floor(track.duration / 60)}:{(track.duration % 60).toString().padStart(2, '0')}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>
      
      {/* Add CSS for spinner animation */}
      <style>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default SimpleAIDJPageNew;