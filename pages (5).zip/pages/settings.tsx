import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { 
  Home as HomeIcon, 
  Music, 
  Heart,
  Settings, 
  Shield,
  Brain,
  Library,
  Bell,
  Volume2,
  Moon,
  Palette
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";

export default function SettingsPage() {
  const [, setLocation] = useLocation();
  const [notifications, setNotifications] = useState(true);
  const [autoPlay, setAutoPlay] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [sessionLength, setSessionLength] = useState("15 minutes");
  const [wellnessGoal, setWellnessGoal] = useState("Stress Relief");

  const sidebarItems = [
    { icon: HomeIcon, label: "Dashboard", path: "/" },
    { icon: Library, label: "My Library", path: "/library" },
    { icon: Heart, label: "Wellness", path: "/wellness" },
    { icon: Shield, label: "Admin", path: "/admin" },
    { icon: Settings, label: "Settings", path: "/settings", active: true },
  ];

  const handleNavigation = (path: string) => {
    setLocation(path);
  };

  const handleToggleNotifications = () => {
    setNotifications(!notifications);
    console.log('Notifications toggled:', !notifications);
  };

  const handleToggleAutoPlay = () => {
    setAutoPlay(!autoPlay);
    console.log('Auto-play toggled:', !autoPlay);
  };

  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
    console.log('Dark mode toggled:', !darkMode);
  };

  const handleSessionLengthChange = (length: string) => {
    setSessionLength(length);
    console.log('Session length changed to:', length);
  };

  const handleWellnessGoalChange = (goal: string) => {
    setWellnessGoal(goal);
    console.log('Wellness goal changed to:', goal);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-slate-800/95 backdrop-blur-xl border-r border-slate-700/50">
        {/* Header */}
        <div className="p-6 border-b border-slate-700/50">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-white">AI Music Wellness</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {sidebarItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavigation(item.path)}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors",
                item.active
                  ? "bg-blue-600/50 text-white"
                  : "text-slate-300 hover:bg-slate-700/50 hover:text-white"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="absolute bottom-6 left-4 right-4">
          <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-700/50">
            <div className="w-2 h-2 rounded-full bg-green-400"></div>
            <span className="text-sm text-slate-200">Brian</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-64 p-8">
        <div className="max-w-4xl space-y-6">
          {/* General Settings */}
          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Settings className="w-5 h-5" />
                <span>General Settings</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Bell className="w-5 h-5 text-slate-400" />
                  <div>
                    <p className="text-white font-medium">Notifications</p>
                    <p className="text-sm text-slate-400">Receive wellness reminders and mood check-ins</p>
                  </div>
                </div>
                <Switch
                  checked={notifications}
                  onCheckedChange={handleToggleNotifications}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Volume2 className="w-5 h-5 text-slate-400" />
                  <div>
                    <p className="text-white font-medium">Auto-play</p>
                    <p className="text-sm text-slate-400">Automatically play recommended tracks</p>
                  </div>
                </div>
                <Switch
                  checked={autoPlay}
                  onCheckedChange={handleToggleAutoPlay}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Moon className="w-5 h-5 text-slate-400" />
                  <div>
                    <p className="text-white font-medium">Dark Mode</p>
                    <p className="text-sm text-slate-400">Use dark theme for better evening sessions</p>
                  </div>
                </div>
                <Switch
                  checked={darkMode}
                  onCheckedChange={handleToggleDarkMode}
                />
              </div>
            </CardContent>
          </Card>

          {/* Therapeutic Preferences */}
          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <Heart className="w-5 h-5" />
                <span>Therapeutic Preferences</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-slate-700/50 rounded-lg">
                  <h3 className="text-white font-medium mb-2">Preferred Session Length</h3>
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      onClick={() => handleSessionLengthChange("15 minutes")}
                      className={`w-full ${sessionLength === "15 minutes" ? "bg-blue-600/50 border-blue-500 text-white" : "bg-slate-700/60 border-slate-600/50 text-slate-300"}`}
                    >
                      15 minutes
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => handleSessionLengthChange("30 minutes")}
                      className={`w-full ${sessionLength === "30 minutes" ? "bg-blue-600/50 border-blue-500 text-white" : "bg-slate-700/60 border-slate-600/50 text-slate-300"}`}
                    >
                      30 minutes
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => handleSessionLengthChange("60 minutes")}
                      className={`w-full ${sessionLength === "60 minutes" ? "bg-blue-600/50 border-blue-500 text-white" : "bg-slate-700/60 border-slate-600/50 text-slate-300"}`}
                    >
                      60 minutes
                    </Button>
                  </div>
                </div>

                <div className="p-4 bg-slate-700/50 rounded-lg">
                  <h3 className="text-white font-medium mb-2">Primary Wellness Goal</h3>
                  <div className="space-y-2">
                    <Button 
                      variant="outline" 
                      onClick={() => handleWellnessGoalChange("Stress Relief")}
                      className={`w-full ${wellnessGoal === "Stress Relief" ? "bg-blue-600/50 border-blue-500 text-white" : "bg-slate-700/60 border-slate-600/50 text-slate-300"}`}
                    >
                      Stress Relief
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => handleWellnessGoalChange("Better Sleep")}
                      className={`w-full ${wellnessGoal === "Better Sleep" ? "bg-blue-600/50 border-blue-500 text-white" : "bg-slate-700/60 border-slate-600/50 text-slate-300"}`}
                    >
                      Better Sleep
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => handleWellnessGoalChange("Focus & Concentration")}
                      className={`w-full ${wellnessGoal === "Focus & Concentration" ? "bg-blue-600/50 border-blue-500 text-white" : "bg-slate-700/60 border-slate-600/50 text-slate-300"}`}
                    >
                      Focus & Concentration
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Account Settings */}
          <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
            <CardHeader>
              <CardTitle className="text-white">Account & Privacy</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Export Mood Data</span>
                <Button variant="outline" className="bg-slate-700/60 border-slate-600/50 text-slate-300">
                  Download
                </Button>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Clear Listening History</span>
                <Button variant="outline" className="bg-red-500/20 border-red-500/50 text-red-400">
                  Clear
                </Button>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Sign Out</span>
                <Button 
                  onClick={() => window.location.href = '/api/logout'}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Sign Out
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}