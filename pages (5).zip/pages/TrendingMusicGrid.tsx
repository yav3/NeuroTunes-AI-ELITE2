import React from 'react';

interface Track {
  id: number;
  title: string;
  artist: string;
}

interface Genre {
  name: string;
  tracks: Track[];
}

interface TrendingMusicGridProps {
  genres: Genre[];
}

export default function TrendingMusicGrid({ genres }: TrendingMusicGridProps) {
  return (
    <div className="trending-music-grid">
      {genres.map((genre) => (
        <div key={genre.name} className="genre-section mb-6">
          <h2 className="genre-title text-xl font-bold mb-4">{genre.name}</h2>
          <div className="tracks-grid grid grid-flow-col auto-cols-min gap-4 overflow-x-auto">
            {genre.tracks.map((track) => (
              <div key={track.id} className="track-card p-2 bg-gray-800 rounded-md">
                <div className="track-info">
                  <h3 className="track-title text-sm font-medium">{track.title}</h3>
                  <p className="track-artist text-xs text-gray-400">{track.artist}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
      <style jsx>{`
        .trending-music-grid {
          padding: 20px;
          background: linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%);
          min-height: 100vh;
          color: white;
        }
        .tracks-grid {
          display: grid;
          grid-auto-flow: column;
          grid-auto-columns: calc(50% - 8px); /* Making the track card half the current width */
        }
        .track-card {
          background-color: rgba(255, 255, 255, 0.1);
          transition: box-shadow 0.2s;
          width: 90%; /* Adjusted width */
          padding: 1.5rem; /* Adjusted padding */
        }
        .track-card:hover {
          box-shadow: 0 0 8px rgba(255, 255, 255, 0.2);
        }
      `}</style>
    </div>
  );
}