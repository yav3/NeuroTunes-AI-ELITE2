#!/bin/bash
set -e

# NeuroTunes AI Cloud Storage Deployment Script
# Complete deployment with volume-mounted music library

PROJECT_ID=${PROJECT_ID:-$(gcloud config get-value project)}
REGION=${REGION:-"us-central1"}
SERVICE_NAME="neurotunes-ai"
BUCKET_NAME="neurotunes-music-library"
IMAGE_NAME="gcr.io/$PROJECT_ID/neurotunes-ai:latest"

echo "🚀 Deploying NeuroTunes AI with Cloud Storage volume mount..."
echo "Project: $PROJECT_ID"
echo "Region: $REGION"
echo "Service: $SERVICE_NAME"
echo "Bucket: $BUCKET_NAME"

# Build and push the container
echo "📦 Building container image..."
docker build -f deployment/Dockerfile.cloud-storage -t $IMAGE_NAME .
docker push $IMAGE_NAME

# Deploy to Cloud Run with volume mount
echo "🎵 Deploying to Cloud Run with music library volume..."
gcloud run deploy $SERVICE_NAME \
  --image $IMAGE_NAME \
  --region $REGION \
  --platform managed \
  --allow-unauthenticated \
  --memory 2Gi \
  --cpu 1 \
  --max-instances 100 \
  --concurrency 80 \
  --timeout 300 \
  --service-account "neurotunes-service-account@${PROJECT_ID}.iam.gserviceaccount.com" \
  --add-volume name=music-storage,type=cloud-storage,bucket=$BUCKET_NAME,readonly=true \
  --add-volume-mount volume=music-storage,mount-path=/mnt/music \
  --set-env-vars "MUSIC_LIBRARY_PATH=/mnt/music,NODE_ENV=production" \
  --port 5000

echo "✅ Deployment complete!"

# Get the service URL
SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region=$REGION --format='value(status.url)')
echo ""
echo "🌐 Your NeuroTunes AI app is live at: $SERVICE_URL"
echo "💊 Health check: $SERVICE_URL/api/health"
echo "🎵 API endpoints: $SERVICE_URL/api/tracks"
echo ""
echo "📊 Next steps:"
echo "1. Test the deployment: curl $SERVICE_URL/api/health"
echo "2. Set up Cloud CDN for better performance"
echo "3. Configure custom domain if needed"