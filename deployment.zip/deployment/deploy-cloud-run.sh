#!/bin/bash
set -euo pipefail

# Cloud Run deployment script with music library volume mount
PROJECT_ID=${PROJECT_ID:-"your-project-id"}
REGION=${REGION:-"us-central1"}
SERVICE_NAME="neurotunes-app"
MUSIC_BUCKET_NAME=${MUSIC_BUCKET_NAME:-"neurotunes-music-library"}

echo "🚀 Deploying NeuroTunes to Cloud Run with music library volume..."

# 1. Build and push container
echo "📦 Building container..."
docker build -f Dockerfile.production -t gcr.io/${PROJECT_ID}/neurotunes:latest .
docker push gcr.io/${PROJECT_ID}/neurotunes:latest

# 2. Create Cloud Storage bucket for music library (if not exists)
if ! gsutil ls gs://${MUSIC_BUCKET_NAME} &>/dev/null; then
    echo "🎵 Creating music library bucket..."
    gsutil mb -p ${PROJECT_ID} -l ${REGION} gs://${MUSIC_BUCKET_NAME}
    
    # Upload music library
    echo "📤 Uploading music library..."
    gsutil -m cp -r music_library/* gs://${MUSIC_BUCKET_NAME}/
    
    # Set bucket to publicly readable for faster access
    gsutil iam ch allUsers:objectViewer gs://${MUSIC_BUCKET_NAME}
fi

# 3. Deploy to Cloud Run with volume mount
echo "🌍 Deploying to Cloud Run..."
gcloud run deploy ${SERVICE_NAME} \
    --image gcr.io/${PROJECT_ID}/neurotunes:latest \
    --platform managed \
    --region ${REGION} \
    --port 8080 \
    --cpu 2 \
    --memory 4Gi \
    --min-instances 1 \
    --max-instances 10 \
    --concurrency 100 \
    --timeout 300s \
    --execution-environment gen2 \
    --add-volume name=music-volume,type=cloud-storage,bucket=${MUSIC_BUCKET_NAME},readonly=true \
    --add-volume-mount volume=music-volume,mount-path=/mnt/music \
    --set-env-vars "NODE_ENV=production,ENABLE_FULLSTACK=true,STORAGE_MODE=volume,AUDIO_ROOT=/mnt/music,LOG_LEVEL=info" \
    --allow-unauthenticated

echo "✅ Deployment complete!"
echo "🌐 Service URL: $(gcloud run services describe ${SERVICE_NAME} --platform managed --region ${REGION} --format 'value(status.url)')"

# 4. Enable Cloud CDN for better audio performance
echo "🚀 Setting up Cloud CDN for optimal audio streaming..."
gcloud compute backend-services create neurotunes-backend \
    --global \
    --enable-cdn \
    --cache-mode=CACHE_ALL_STATIC \
    --default-ttl=86400 \
    --max-ttl=2592000 || echo "Backend service already exists"

echo "🎯 Deployment optimized for therapeutic music streaming!"