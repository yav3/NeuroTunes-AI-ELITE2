#!/bin/bash
set -e

# NeuroTunes AI Cloud Storage Setup for Cloud Run
# This script sets up the Cloud Storage bucket and service account for volume mounting

PROJECT_ID=${PROJECT_ID:-$(gcloud config get-value project)}
BUCKET_NAME="neurotunes-music-library"
SERVICE_ACCOUNT_NAME="neurotunes-service-account"
REGION=${REGION:-"us-central1"}

echo "🚀 Setting up NeuroTunes AI Cloud Storage deployment..."
echo "Project: $PROJECT_ID"
echo "Bucket: $BUCKET_NAME"
echo "Region: $REGION"

# Create the Cloud Storage bucket
echo "📦 Creating Cloud Storage bucket..."
gsutil mb -p $PROJECT_ID -c STANDARD -l $REGION gs://$BUCKET_NAME/ || echo "Bucket already exists"

# Set bucket permissions for Cloud Run
echo "🔐 Setting up service account..."
gcloud iam service-accounts create $SERVICE_ACCOUNT_NAME \
    --display-name="NeuroTunes AI Service Account" \
    --description="Service account for NeuroTunes AI Cloud Run service" || echo "Service account already exists"

# Grant necessary permissions
echo "🔑 Granting permissions..."
gcloud projects add-iam-policy-binding $PROJECT_ID \
    --member="serviceAccount:${SERVICE_ACCOUNT_NAME}@${PROJECT_ID}.iam.gserviceaccount.com" \
    --role="roles/storage.objectViewer"

# Upload music library to bucket (if it exists locally)
if [ -d "music_library" ]; then
    echo "🎵 Uploading music library to Cloud Storage..."
    gsutil -m rsync -r -d music_library/ gs://$BUCKET_NAME/
    echo "✅ Music library uploaded to gs://$BUCKET_NAME/"
else
    echo "⚠️ No local music_library directory found. Upload your music files manually:"
    echo "   gsutil -m rsync -r -d your_music_directory/ gs://$BUCKET_NAME/"
fi

# Enable required APIs
echo "🔧 Enabling required APIs..."
gcloud services enable run.googleapis.com
gcloud services enable cloudbuild.googleapis.com
gcloud services enable storage.googleapis.com

echo "✅ Cloud Storage setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Build and push your container image:"
echo "   docker build -t gcr.io/$PROJECT_ID/neurotunes-ai:latest ."
echo "   docker push gcr.io/$PROJECT_ID/neurotunes-ai:latest"
echo ""
echo "2. Deploy with the volume mount:"
echo "   gcloud run services replace deployment/cloud-run-with-storage.yaml --region=$REGION"
echo ""
echo "3. Or use the direct gcloud command:"
echo "   gcloud run services update neurotunes-ai \\"
echo "     --add-volume name=music-storage,type=cloud-storage,bucket=$BUCKET_NAME,readonly=true \\"
echo "     --add-volume-mount volume=music-storage,mount-path=/mnt/music \\"
echo "     --region=$REGION"