// Client-side error handling utilities

export interface APIError {
  message: string;
  code: string;
  timestamp: string;
  requestId: string;
  context?: any;
}

export interface ErrorResponse {
  error: APIError;
  context?: any;
}

export class ClientError extends Error {
  constructor(
    message: string,
    public code: string = 'CLIENT_ERROR',
    public statusCode: number = 400
  ) {
    super(message);
    this.name = 'ClientError';
  }
}

export class NetworkError extends Error {
  constructor(message: string = 'Network connection failed') {
    super(message);
    this.name = 'NetworkError';
  }
}

export class ValidationError extends Error {
  constructor(
    message: string,
    public field?: string
  ) {
    super(message);
    this.name = 'ValidationError';
  }
}

// Error type definitions for better UX
export type ErrorType = 
  | 'network'
  | 'validation' 
  | 'authentication'
  | 'authorization'
  | 'not_found'
  | 'server'
  | 'audio'
  | 'unknown';

export interface UserFriendlyError {
  type: ErrorType;
  title: string;
  message: string;
  action?: string;
  retryable: boolean;
}

// Convert API errors to user-friendly messages
export function parseAPIError(error: any): UserFriendlyError {
  // Network errors
  if (!navigator.onLine) {
    return {
      type: 'network',
      title: 'No Internet Connection',
      message: 'Please check your internet connection and try again.',
      action: 'Retry',
      retryable: true
    };
  }

  // Fetch errors
  if (error instanceof TypeError && error.message.includes('fetch')) {
    return {
      type: 'network',
      title: 'Connection Failed',
      message: 'Unable to connect to the server. Please try again.',
      action: 'Retry',
      retryable: true
    };
  }

  // API response errors
  if (error.error && error.error.code) {
    const apiError = error.error as APIError;
    
    switch (apiError.code) {
      case 'VALIDATION_ERROR':
        return {
          type: 'validation',
          title: 'Invalid Input',
          message: apiError.message || 'Please check your input and try again.',
          retryable: false
        };
        
      case 'NOT_FOUND':
        return {
          type: 'not_found',
          title: 'Content Not Found',
          message: 'The requested content could not be found.',
          retryable: false
        };
        
      case 'AUDIO_PROCESSING_ERROR':
        return {
          type: 'audio',
          title: 'Audio Playback Issue',
          message: 'There was a problem playing this track. Try another song.',
          action: 'Try Another Track',
          retryable: true
        };
        
      case 'RATE_LIMIT_EXCEEDED':
        return {
          type: 'server',
          title: 'Too Many Requests',
          message: 'Please wait a moment before trying again.',
          action: 'Wait and Retry',
          retryable: true
        };
        
      case 'UNAUTHORIZED':
        return {
          type: 'authentication',
          title: 'Authentication Required',
          message: 'Please log in to continue.',
          action: 'Log In',
          retryable: false
        };
        
      case 'FORBIDDEN':
        return {
          type: 'authorization',
          title: 'Access Denied',
          message: 'You do not have permission to access this content.',
          retryable: false
        };
        
      default:
        return {
          type: 'server',
          title: 'Server Error',
          message: 'Something went wrong. Please try again.',
          action: 'Retry',
          retryable: true
        };
    }
  }

  // HTTP status code errors
  if (error.status || error.statusCode) {
    const status = error.status || error.statusCode;
    
    if (status >= 500) {
      return {
        type: 'server',
        title: 'Server Error',
        message: 'Our servers are experiencing issues. Please try again.',
        action: 'Retry',
        retryable: true
      };
    } else if (status === 404) {
      return {
        type: 'not_found',
        title: 'Not Found',
        message: 'The requested content could not be found.',
        retryable: false
      };
    } else if (status === 401) {
      return {
        type: 'authentication',
        title: 'Authentication Required',
        message: 'Please log in to continue.',
        action: 'Log In',
        retryable: false
      };
    } else if (status === 403) {
      return {
        type: 'authorization',
        title: 'Access Denied',
        message: 'You do not have permission to access this content.',
        retryable: false
      };
    }
  }

  // Generic error fallback
  return {
    type: 'unknown',
    title: 'Something Went Wrong',
    message: error.message || 'An unexpected error occurred. Please try again.',
    action: 'Retry',
    retryable: true
  };
}

// Error logging for analytics
export function logClientError(error: Error, context?: any) {
  const errorData = {
    message: error.message,
    name: error.name,
    stack: error.stack,
    timestamp: new Date().toISOString(),
    url: window.location.href,
    userAgent: navigator.userAgent,
    context
  };

  // Log to console in development
  if (process.env.NODE_ENV === 'development') {
    console.error('Client Error:', errorData);
  }

  // Send to server for production logging
  if (process.env.NODE_ENV === 'production') {
    fetch('/api/client-errors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(errorData)
    }).catch(() => {
      // Silently fail if error reporting fails
    });
  }
}

// Retry mechanism for failed requests
export async function retryOperation<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<T> {
  let lastError: Error;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await operation();
    } catch (error) {
      lastError = error as Error;
      
      // Don't retry on client errors (4xx)
      if (error && typeof error === 'object' && 'status' in error) {
        const status = (error as any).status;
        if (status >= 400 && status < 500) {
          throw error;
        }
      }

      // Don't retry on the last attempt
      if (attempt === maxRetries) {
        break;
      }

      // Wait before retrying with exponential backoff
      await new Promise(resolve => setTimeout(resolve, delay * attempt));
    }
  }

  throw lastError!;
}

// Check if error is retryable
export function isRetryableError(error: any): boolean {
  // Network errors are retryable
  if (error instanceof NetworkError) return true;
  
  // Server errors (5xx) are retryable
  if (error.status >= 500) return true;
  
  // Rate limiting is retryable
  if (error.error?.code === 'RATE_LIMIT_EXCEEDED') return true;
  
  // Timeout errors are retryable
  if (error.name === 'TimeoutError') return true;
  
  return false;
}

// Format error for display in UI
export function formatErrorForDisplay(error: any): string {
  const userError = parseAPIError(error);
  return userError.message;
}