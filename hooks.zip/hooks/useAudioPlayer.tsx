import { useState, useRef } from 'react';
import { Track, trackStreamUrl } from '../lib/apiNew';

export function useAudioPlayer() {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const play = (track: Track) => {
    // Stop current audio if playing
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }

    // Create new audio element
    const audio = new Audio();
    audioRef.current = audio;
    
    audio.src = trackStreamUrl(track);
    
    audio.onloadedmetadata = () => {
      console.log(`[AUDIO] Ready to play: ${track.title}`);
      setCurrentTrack(track);
      setIsVisible(true);
    };
    
    audio.onerror = () => {
      console.warn(`[AUDIO] Failed to load: ${track.title} (${track.id})`);
      alert(`Audio not available: ${track.title}`);
      setCurrentTrack(null);
      setIsVisible(false);
    };
    
    audio.play().then(() => {
      console.log(`[AUDIO] Playing: ${track.title}`);
    }).catch(err => {
      console.warn(`[AUDIO] Play failed: ${track.title}`, err);
      alert(`Cannot play: ${track.title}`);
      setCurrentTrack(null);
      setIsVisible(false);
    });
  };

  const stop = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    setCurrentTrack(null);
    setIsVisible(false);
  };

  return {
    currentTrack,
    audio: audioRef.current,
    isVisible,
    play,
    stop
  };
}