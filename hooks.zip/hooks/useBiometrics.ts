import { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

export interface BiometricData {
  heartRate: number;
  heartRateVariability: number;
  stressLevel: number;
  oxygenSaturation?: number;
  skinTemperature?: number;
  activityLevel: number;
  timestamp: Date;
}

export interface BiometricDevice {
  id: string;
  name: string;
  type: 'fitbit' | 'apple_watch' | 'garmin' | 'polar' | 'whoop' | 'generic';
  isConnected: boolean;
  batteryLevel?: number;
  lastSync?: Date;
}

export interface MoodPrediction {
  predictedMood: string;
  confidence: number;
  factors: {
    heartRate: number;
    hrv: number;
    stress: number;
    activity: number;
  };
  recommendations: string[];
}

export function useBiometrics() {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [currentReading, setCurrentReading] = useState<BiometricData | null>(null);
  const [devicePermissions, setDevicePermissions] = useState<Record<string, boolean>>({});
  const queryClient = useQueryClient();

  // Fetch connected devices
  const { data: devices = [], isLoading: devicesLoading } = useQuery({
    queryKey: ['/api/biometrics/devices'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch recent biometric history
  const { data: biometricHistory = [], isLoading: historyLoading } = useQuery({
    queryKey: ['/api/biometrics/history'],
    refetchInterval: 60000, // Refresh every minute
  });

  // Get real-time mood prediction based on biometrics
  const { data: moodPrediction, isLoading: predictionLoading } = useQuery({
    queryKey: ['/api/biometrics/mood-prediction'],
    enabled: !!currentReading,
    refetchInterval: 10000, // Update every 10 seconds during monitoring
  });

  // Connect to a new device
  const connectDeviceMutation = useMutation({
    mutationFn: async (deviceType: string) => {
      return await apiRequest(`/api/biometrics/connect/${deviceType}`, 'POST');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/biometrics/devices'] });
    },
  });

  // Disconnect device
  const disconnectDeviceMutation = useMutation({
    mutationFn: async (deviceId: string) => {
      return await apiRequest(`/api/biometrics/disconnect/${deviceId}`, 'DELETE');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/biometrics/devices'] });
    },
  });

  // Save biometric data
  const saveBiometricDataMutation = useMutation({
    mutationFn: async (data: BiometricData) => {
      return await apiRequest('/api/biometrics/data', 'POST', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/biometrics/history'] });
      queryClient.invalidateQueries({ queryKey: ['/api/biometrics/mood-prediction'] });
    },
  });

  // Check if Web Bluetooth is supported
  const checkBluetoothSupport = useCallback(() => {
    return 'bluetooth' in navigator && 'requestDevice' in navigator.bluetooth;
  }, []);

  // Request device permissions
  const requestDevicePermission = useCallback(async (deviceType: string) => {
    try {
      if (deviceType === 'web_bluetooth' && checkBluetoothSupport()) {
        const device = await navigator.bluetooth.requestDevice({
          filters: [
            { services: ['heart_rate'] },
            { services: ['battery_service'] },
            { namePrefix: 'Polar' },
            { namePrefix: 'Fitbit' },
            { namePrefix: 'Garmin' },
          ],
          optionalServices: [
            'heart_rate',
            'battery_service',
            'device_information',
            'user_data',
          ],
        });
        
        setDevicePermissions(prev => ({ ...prev, [deviceType]: true }));
        return device;
      }
      
      // For other device types, use OAuth or API connections
      return await connectDeviceMutation.mutateAsync(deviceType);
    } catch (error) {
      console.error('Device permission error:', error);
      setDevicePermissions(prev => ({ ...prev, [deviceType]: false }));
      throw error;
    }
  }, [checkBluetoothSupport, connectDeviceMutation]);

  // Start continuous monitoring
  const startMonitoring = useCallback(async () => {
    if (!devices.length) {
      throw new Error('No connected devices available');
    }

    setIsMonitoring(true);
    
    // Set up real-time data collection
    const monitoringInterval = setInterval(async () => {
      try {
        // Simulate reading from connected devices
        // In a real implementation, this would connect to actual device APIs
        const simulatedReading: BiometricData = {
          heartRate: 70 + Math.random() * 30, // 70-100 BPM
          heartRateVariability: 30 + Math.random() * 40, // 30-70 ms
          stressLevel: Math.random() * 100, // 0-100%
          oxygenSaturation: 95 + Math.random() * 5, // 95-100%
          skinTemperature: 36.1 + Math.random() * 1.4, // 36.1-37.5°C
          activityLevel: Math.random() * 100, // 0-100%
          timestamp: new Date(),
        };

        setCurrentReading(simulatedReading);
        await saveBiometricDataMutation.mutateAsync(simulatedReading);
      } catch (error) {
        console.error('Monitoring error:', error);
      }
    }, 5000); // Update every 5 seconds

    return () => {
      clearInterval(monitoringInterval);
      setIsMonitoring(false);
    };
  }, [devices, saveBiometricDataMutation]);

  // Stop monitoring
  const stopMonitoring = useCallback(() => {
    setIsMonitoring(false);
    setCurrentReading(null);
  }, []);

  // Calculate stress level from HRV and heart rate
  const calculateStressLevel = useCallback((heartRate: number, hrv: number) => {
    // Higher heart rate and lower HRV typically indicate higher stress
    const normalizedHR = Math.min((heartRate - 60) / 40, 1); // Normalize 60-100 BPM to 0-1
    const normalizedHRV = Math.max(1 - (hrv / 100), 0); // Higher HRV = lower stress
    
    return Math.round((normalizedHR * 0.6 + normalizedHRV * 0.4) * 100);
  }, []);

  // Get mood recommendations based on current biometrics
  const getMoodRecommendations = useCallback((biometrics: BiometricData): string[] => {
    const recommendations: string[] = [];
    
    if (biometrics.stressLevel > 70) {
      recommendations.push('Consider relaxing music to reduce stress');
      recommendations.push('Try deep breathing exercises');
    }
    
    if (biometrics.heartRate > 90) {
      recommendations.push('Choose calming, slow-tempo music');
      recommendations.push('Consider meditation or mindfulness');
    }
    
    if (biometrics.heartRateVariability < 30) {
      recommendations.push('Focus on stress-reduction techniques');
      recommendations.push('Select ambient or nature sounds');
    }
    
    if (biometrics.activityLevel < 20) {
      recommendations.push('Try energizing music to boost activity');
      recommendations.push('Consider upbeat, motivating tracks');
    }
    
    return recommendations;
  }, []);

  return {
    // State
    isMonitoring,
    currentReading,
    devices,
    biometricHistory,
    moodPrediction,
    devicePermissions,
    
    // Loading states
    devicesLoading,
    historyLoading,
    predictionLoading,
    
    // Mutations
    connectDevice: connectDeviceMutation.mutate,
    disconnectDevice: disconnectDeviceMutation.mutate,
    isConnecting: connectDeviceMutation.isPending,
    isDisconnecting: disconnectDeviceMutation.isPending,
    
    // Actions
    startMonitoring,
    stopMonitoring,
    requestDevicePermission,
    checkBluetoothSupport,
    calculateStressLevel,
    getMoodRecommendations,
    
    // Utilities
    isSupported: checkBluetoothSupport(),
  };
}