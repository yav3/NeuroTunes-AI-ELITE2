// AI DJ playlist generation - safe, single-use implementation
let genInFlight: AbortController | null = null;

export async function generatePlaylistOnce(params: {
  mood?: string;
  energy?: number;
  genres?: string[];
  duration?: number;
}): Promise<any> {
  if (genInFlight) {
    console.log('Playlist generation already in progress');
    return null;
  }

  genInFlight = new AbortController();
  
  try {
    const res = await fetch('/api/ai-dj/generate', {
      method: 'POST',
      body: JSON.stringify(params),
      signal: genInFlight.signal,
      headers: { 'Content-Type': 'application/json' },
    });
    
    if (!res.ok) {
      throw new Error(`AI DJ generation failed: ${res.status}`);
    }
    
    return await res.json();
  } catch (error: any) {
    if (error.name === 'AbortError') {
      console.log('Playlist generation was cancelled');
    } else {
      console.error('Playlist generation error:', error);
    }
    return null;
  } finally {
    genInFlight?.abort();
    genInFlight = null;
  }
}

export function isGenerating(): boolean {
  return genInFlight !== null;
}

export function cancelGeneration(): void {
  if (genInFlight) {
    genInFlight.abort();
    genInFlight = null;
  }
}