// Minimal, same-origin by default. Set VITE_API_BASE if you deploy frontend elsewhere.
const BASE = (import.meta as any).env?.VITE_API_BASE ?? '';

export type RawTrack = Record<string, any>;

export interface Track {
  id: string;
  title: string;
  artist?: string;
  coverUrl?: string;
  streamKey: string; // what we pass to /api/stream/:streamKey
  duration?: number;
  genres?: string[];
  mood?: string;
  genre?: string;
  therapeuticTags?: string[];
  audioUrl?: string;
}

export function normalizeTrack(raw: RawTrack): Track | null {
  if (!raw) return null;

  const id =
    String(raw.id ?? raw._id ?? raw.track_id ?? raw.slug ?? raw.audio_id ?? raw.filename ?? raw.file ?? '');

  const title =
    raw.title ?? raw.name ?? raw.track_title ?? raw.display_name ?? 'Untitled';

  const artist =
    raw.artist ?? raw.author ?? raw.creator ?? raw.band ?? undefined;

  const coverUrl =
    raw.coverUrl ?? raw.artwork_url ?? raw.cover_url ?? raw.image ?? raw.thumbnail ?? undefined;

  const streamKey =
    raw.streamKey ?? raw.stream_id ?? raw.file ?? raw.filename ?? raw.audio_filename ?? raw.audioUrl ?? id;

  const duration =
    typeof raw.duration === 'number' ? raw.duration : undefined;

  let genres: string[] | undefined;
  if (Array.isArray(raw.genres)) genres = raw.genres.map(String);
  else if (typeof raw.genre === 'string') genres = [raw.genre];

  if (!streamKey) return null;

  return { 
    id, 
    title, 
    artist, 
    coverUrl, 
    streamKey, 
    duration, 
    genres,
    mood: raw.mood,
    genre: raw.genre,
    therapeuticTags: raw.therapeuticTags,
    audioUrl: raw.audioUrl
  };
}

async function json<T>(path: string) {
  const r = await fetch(`${BASE}${path}`);
  if (!r.ok) throw new Error(`${r.status} ${r.statusText}`);
  return (await r.json()) as T;
}

export const api = {
  health: () => json<{ message: string }>('/api/health'),

  async tracks(opts?: { sort?: 'popular' | 'recent' | 'all'; page?: number; limit?: number }) {
    const params = new URLSearchParams();
    if (opts?.sort && opts.sort !== 'all') params.set('sort', opts.sort);
    if (opts?.page) params.set('page', String(opts.page));
    if (opts?.limit) params.set('limit', String(opts.limit));
    const query = params.toString() ? `?${params.toString()}` : '';
    try {
      const response = await json<{status: string, catalog: RawTrack[]} | RawTrack[]>(`/api/tracks${query}`);
      // Handle both new catalog format and legacy array format
      const data = Array.isArray(response) ? response : response.catalog;
      return data.map(normalizeTrack).filter(Boolean) as Track[];
    } catch {
      // Fallback: some servers might not support sort param; try plain list
      const response = await json<{status: string, catalog: RawTrack[]} | RawTrack[]>(`/api/tracks${opts?.limit ? `?limit=${opts.limit}` : ''}`);
      const data = Array.isArray(response) ? response : response.catalog;
      return data.map(normalizeTrack).filter(Boolean) as Track[];
    }
  },

  streamUrl: (streamKey: string) =>
    `${BASE}/api/stream/${encodeURIComponent(streamKey)}`,

  // POST exact goals to your backend
  postGoals: async (goalIds: string[]) => {
    const r = await fetch(`${BASE}/api/session/goals`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ goals: goalIds }),
    });
    if (!r.ok) throw new Error(await r.text());
    return r.json();
  },
};