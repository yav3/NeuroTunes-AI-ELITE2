// One audio element, serialized play() (prevents AbortError + double-plays)
const audio = new Audio();
let playLock = Promise.resolve();

export function playUrl(url: string): Promise<void> {
  playLock = playLock.then(async () => {
    audio.pause();
    audio.src = url;
    try { 
      await audio.play(); 
    } catch (e: any) {
      if (e?.name !== 'AbortError') {
        console.error('play() failed', e);
      }
    }
  });
  return playLock;
}

export function pause(): void { 
  audio.pause(); 
}

export function getCurrentTime(): number {
  return audio.currentTime;
}

export function getDuration(): number {
  return audio.duration || 0;
}

export function setCurrentTime(time: number): void {
  audio.currentTime = time;
}

export function getVolume(): number {
  return audio.volume;
}

export function setVolume(volume: number): void {
  audio.volume = Math.max(0, Math.min(1, volume));
}

// Event listeners for playback state
export function onTimeUpdate(callback: (time: number) => void): void {
  audio.addEventListener('timeupdate', () => callback(audio.currentTime));
}

export function onLoadedMetadata(callback: (duration: number) => void): void {
  audio.addEventListener('loadedmetadata', () => callback(audio.duration));
}

export function onEnded(callback: () => void): void {
  audio.addEventListener('ended', callback);
}

export function onPlay(callback: () => void): void {
  audio.addEventListener('play', callback);
}

export function onPause(callback: () => void): void {
  audio.addEventListener('pause', callback);
}