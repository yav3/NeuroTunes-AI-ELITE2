import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { trackStreamUrl } from '../lib/apiNew';
import type { Track } from '../lib/apiNew';

type AudioState = {
  isPlaying: boolean;
  current: Track | null;
  volume: number;
  currentTime: number;
  duration: number;
  queue: Track[];
  currentIndex: number;
};

type AudioControls = {
  play: (track?: Track) => void;
  pause: () => void;
  toggle: () => void;
  setVolume: (v: number) => void;
  seek: (sec: number) => void;
  next: () => void;
  prev: () => void;
  setQueue: (tracks: Track[], startIndex?: number) => void;
};

type AudioContextValue = AudioState & AudioControls;

// Singleton audio manager
class AudioManager {
  private audio: HTMLAudioElement;
  private listeners: Set<() => void> = new Set();
  private state: AudioState = {
    isPlaying: false,
    current: null,
    volume: 1,
    currentTime: 0,
    duration: 0,
    queue: [],
    currentIndex: -1
  };

  constructor() {
    this.audio = new Audio();
    this.audio.preload = "metadata";
    this.audio.volume = 1;
    this.audio.crossOrigin = 'anonymous';

    // Event listeners
    this.audio.addEventListener('play', () => {
      this.state.isPlaying = true;
      this.notifyListeners();
    });

    this.audio.addEventListener('pause', () => {
      this.state.isPlaying = false;
      this.notifyListeners();
    });

    this.audio.addEventListener('timeupdate', () => {
      this.state.currentTime = this.audio.currentTime;
      this.notifyListeners();
    });

    this.audio.addEventListener('loadedmetadata', () => {
      this.state.duration = this.audio.duration;
      this.notifyListeners();
    });

    this.audio.addEventListener('ended', () => {
      console.log('[STABLE AUDIO] Track ended, playing next...');
      this.next();
    });

    this.audio.addEventListener('error', (e) => {
      console.error('[STABLE AUDIO] Audio error:', e);
      this.next(); // Skip to next track on error
    });

    console.log("[STABLE AUDIO] Audio manager created (singleton)");
  }

  play = (track?: Track) => {
    if (track) {
      const audioUrl = trackStreamUrl(track);
      if (!audioUrl) return;
      
      console.log('[STABLE AUDIO] Loading and playing:', track.title, audioUrl);
      this.state.current = track;
      this.audio.src = audioUrl;
      this.audio.currentTime = 0;
      this.audio.load();
      
      // Update queue position if track is in queue
      const trackIndex = this.state.queue.findIndex(t => t.id === track.id);
      if (trackIndex !== -1) {
        this.state.currentIndex = trackIndex;
      } else {
        // If not in queue, add it as a single-track queue
        this.state.queue = [track];
        this.state.currentIndex = 0;
      }
    }
    
    this.audio.play().catch(e => {
      console.error('[STABLE AUDIO] Play failed:', e);
    });
  };

  pause = () => {
    this.audio.pause();
  };

  toggle = () => {
    if (this.state.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  };

  setVolume = (volume: number) => {
    this.audio.volume = Math.max(0, Math.min(1, volume));
    this.state.volume = this.audio.volume;
    this.notifyListeners();
  };

  seek = (time: number) => {
    this.audio.currentTime = time;
  };

  next = () => {
    if (this.state.queue.length === 0) return;
    
    const nextIndex = this.state.currentIndex + 1;
    if (nextIndex < this.state.queue.length) {
      console.log('[STABLE AUDIO] Playing next track:', this.state.queue[nextIndex].title);
      this.play(this.state.queue[nextIndex]);
    } else {
      console.log('[STABLE AUDIO] End of queue reached');
      this.state.isPlaying = false;
      this.notifyListeners();
    }
  };

  prev = () => {
    if (this.state.queue.length === 0) return;
    
    const prevIndex = this.state.currentIndex - 1;
    if (prevIndex >= 0) {
      console.log('[STABLE AUDIO] Playing previous track:', this.state.queue[prevIndex].title);
      this.play(this.state.queue[prevIndex]);
    }
  };

  setQueue = (tracks: Track[], startIndex: number = 0) => {
    console.log('[STABLE AUDIO] Setting queue with', tracks.length, 'tracks, starting at index', startIndex);
    this.state.queue = tracks;
    this.state.currentIndex = startIndex;
    if (tracks.length > 0 && startIndex < tracks.length) {
      this.play(tracks[startIndex]);
    }
  };

  getState = (): AudioState => ({ ...this.state });

  subscribe = (listener: () => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  private notifyListeners = () => {
    this.listeners.forEach(listener => listener());
  };
}

// Global singleton instance
const audioManager = new AudioManager();

const StableAudioContext = createContext<AudioContextValue | undefined>(undefined);

export function useStableAudio(): AudioContextValue {
  const context = useContext(StableAudioContext);
  if (!context) {
    throw new Error("useStableAudio must be used within StableAudioProvider");
  }
  return context;
}

export function StableAudioProvider({ children }: { children: ReactNode }) {
  const [, forceUpdate] = useState({});
  
  useEffect(() => {
    const unsubscribe = audioManager.subscribe(() => {
      forceUpdate({});
    });
    
    console.log("[STABLE AUDIO] Provider mounted");
    return () => {
      unsubscribe();
      console.log("[STABLE AUDIO] Provider unmounted");
    };
  }, []);

  const state = audioManager.getState();
  
  const contextValue: AudioContextValue = {
    ...state,
    play: audioManager.play,
    pause: audioManager.pause,
    toggle: audioManager.toggle,
    setVolume: audioManager.setVolume,
    seek: audioManager.seek,
    next: audioManager.next,
    prev: audioManager.prev,
    setQueue: audioManager.setQueue,
  };

  return (
    <StableAudioContext.Provider value={contextValue}>
      {children}
    </StableAudioContext.Provider>
  );
}