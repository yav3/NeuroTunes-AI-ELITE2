import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  ReactNode,
} from "react";
import { trackStreamUrl } from '../lib/apiNew';
import { useHapticFeedback } from '../hooks/useHapticFeedback';

// Singleton detection in development
if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development') {
  // @ts-ignore
  const __ctxSingleton = (window as any).__AudioCtxModIds__ ??= new Set<string>();
  const marker = "@context/AudioContext";
  if (__ctxSingleton.has(marker)) {
    console.warn(
      "[AUDIO] Multiple AudioContext module instances detected. " +
      "Unify imports to @context/AudioContext and remove any 'contexts/AudioContext' paths."
    );
  } else {
    __ctxSingleton.add(marker);
  }
}

import type { Track } from '../lib/apiNew';

type AudioState = {
  isReady: boolean;
  isPlaying: boolean;
  current: Track | null;
  queue: Track[];
  volume: number; // 0..1
  positionSec: number;
  hapticEnabled: boolean;
  hapticIntensity: 'light' | 'medium' | 'heavy';
};

type AudioControls = {
  load: (track: Track, opts?: { autoplay?: boolean; replaceQueue?: boolean }) => void;
  play: (track?: Track) => void;
  pause: () => void;
  toggle: () => void;
  next: () => void;
  prev: () => void;
  setVolume: (v: number) => void;
  seek: (sec: number) => void;
  enqueue: (tracks: Track[]) => void;
  clearQueue: () => void;
  setHapticEnabled: (enabled: boolean) => void;
  setHapticIntensity: (intensity: 'light' | 'medium' | 'heavy') => void;
  // Missing functionality
  addToFavorites: (track: Track) => void;
  removeFromFavorites: (track: Track) => void;
  thumbsDown: (track: Track) => Promise<void>;
  getSpatialAudioEnabled: () => boolean;
  setSpatialAudioEnabled: (enabled: boolean) => void;
  // Legacy compatibility
  currentTime: number;
  duration: number;
  error?: string;
  playNext: () => void;
  playPrevious: () => void;
};

type AudioContextValue = AudioState & AudioControls;

const AudioContext = createContext<AudioContextValue | undefined>(undefined);

export function useAudio(): AudioContextValue {
  const ctx = useContext(AudioContext);
  if (!ctx) {
    // Make the failure loud and self-identifying
    throw new Error(
      "useAudio called outside of AudioProvider. Ensure your component tree is wrapped by <AudioProvider> from @context/AudioContext and that imports DO NOT use 'contexts/AudioContext'."
    );
  }
  return ctx;
}

type Props = { children: ReactNode };

export const AudioProvider: React.FC<Props> = ({ children }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isReady, setReady] = useState(false);
  const [isPlaying, setPlaying] = useState(false);
  const [current, setCurrent] = useState<Track | null>(null);
  const [queue, setQueue] = useState<Track[]>([]);
  const [volume, setVolumeState] = useState(1);
  const [positionSec, setPos] = useState(0);
  const [error, setError] = useState<string | undefined>(undefined);
  const [hapticEnabled, setHapticEnabledState] = useState(true);
  const [hapticIntensity, setHapticIntensityState] = useState<'light' | 'medium' | 'heavy'>('medium');
  const [spatialAudioEnabled, setSpatialAudioEnabledState] = useState(false);
  const [favorites, setFavorites] = useState<Track[]>([]);
  
  const { haptic, audioSyncHaptic, stopHaptic } = useHapticFeedback();

  // one <audio> element owned here
  useEffect(() => {
    const el = new Audio();
    el.preload = "metadata";
    el.volume = volume;
    el.crossOrigin = 'anonymous';
    
    const onCanPlay = () => setReady(true);
    const onPlay = () => {
      setPlaying(true);
      if (hapticEnabled) {
        haptic('playPause', { intensity: hapticIntensity });
      }
    };
    const onPause = () => {
      setPlaying(false);
      if (hapticEnabled) {
        haptic('playPause', { intensity: hapticIntensity });
      }
    };
    const onTime = () => setPos(el.currentTime || 0);
    const onError = (e: any) => {
      console.error('[AUDIO] Audio error:', e);
      setError('Failed to load audio');
      setPlaying(false);
    };
    const onEnded = () => {
      // auto-advance
      if (queue.length > 0) {
        const [nextTrack, ...rest] = queue;
        setQueue(rest);
        doLoad(nextTrack, { autoplay: true, replaceQueue: false });
        if (hapticEnabled) {
          haptic('trackChange', { intensity: hapticIntensity });
        }
      } else {
        setPlaying(false);
      }
    };

    el.addEventListener("canplay", onCanPlay);
    el.addEventListener("play", onPlay);
    el.addEventListener("pause", onPause);
    el.addEventListener("timeupdate", onTime);
    el.addEventListener("ended", onEnded);
    el.addEventListener("error", onError);
    audioRef.current = el;

    console.log("[AUDIO PROVIDER] mounted, single Audio() created");
    return () => {
      el.pause();
      el.src = "";
      el.removeEventListener("canplay", onCanPlay);
      el.removeEventListener("play", onPlay);
      el.removeEventListener("pause", onPause);
      el.removeEventListener("timeupdate", onTime);
      el.removeEventListener("ended", onEnded);
      el.removeEventListener("error", onError);
      audioRef.current = null;
      console.log("[AUDIO PROVIDER] unmounted");
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const play = useCallback((track?: Track) => {
    const el = audioRef.current;
    if (!el) return;
    
    if (track) {
      // Load and play new track
      const audioUrl = trackStreamUrl(track);
      if (!audioUrl) {
        setError('No audio URL available');
        return;
      }
      
      console.log('[AUDIO] Loading and playing:', track.title, audioUrl);
      
      setCurrent(track);
      setError(undefined);
      setReady(false);
      
      // Add user interaction handling for mobile browsers
      const loadAndPlay = async () => {
        try {
          el.src = audioUrl;
          el.currentTime = 0;
          el.load();
          
          // Wait for canplay event before attempting to play
          await new Promise((resolve, reject) => {
            const onCanPlay = () => {
              el.removeEventListener('canplay', onCanPlay);
              el.removeEventListener('error', onError);
              resolve(true);
            };
            const onError = (e: any) => {
              el.removeEventListener('canplay', onCanPlay);
              el.removeEventListener('error', onError);
              reject(e);
            };
            el.addEventListener('canplay', onCanPlay);
            el.addEventListener('error', onError);
          });
          
          await el.play();
        } catch (err: any) {
          console.warn("[AUDIO] play failed", err);
          if (err.name === 'NotAllowedError') {
            setError('Click to enable audio - browser requires user interaction');
          } else {
            setError(err.message || 'Failed to play audio');
          }
        }
      };
      
      loadAndPlay();
    } else {
      // Resume current track
      el.play().catch(err => {
        console.warn("[AUDIO] play failed", err);
        if (err.name === 'NotAllowedError') {
          setError('Click to enable audio - browser requires user interaction');
        } else {
          setError(err.message || 'Failed to play audio');
        }
      });
    }
  }, []);

  const pause = useCallback(() => {
    audioRef.current?.pause();
  }, []);

  const toggle = useCallback(() => {
    if (isPlaying) pause(); else play();
  }, [isPlaying, pause, play]);

  const setVolume = useCallback((v: number) => {
    const vv = Math.max(0, Math.min(1, v));
    setVolumeState(vv);
    if (audioRef.current) audioRef.current.volume = vv;
    if (hapticEnabled && Math.abs(volume - vv) > 0.1) {
      haptic('volumeChange', { intensity: hapticIntensity });
    }
  }, [volume, hapticEnabled, haptic, hapticIntensity]);

  const seek = useCallback((sec: number) => {
    if (!audioRef.current) return;
    audioRef.current.currentTime = Math.max(0, sec);
    setPos(audioRef.current.currentTime);
  }, []);

  const doLoad = useCallback((track: Track, opts?: { autoplay?: boolean; replaceQueue?: boolean }) => {
    const el = audioRef.current;
    if (!el) return;

    const audioUrl = trackStreamUrl(track);
    if (!audioUrl) {
      setError('No audio URL available');
      return;
    }



    setReady(false);
    setCurrent(track);
    setError(undefined);
    if (opts?.replaceQueue) setQueue([]);
    el.src = audioUrl;
    el.currentTime = 0;
    el.load();
    if (opts?.autoplay) {
      el.play().catch(err => {
        console.warn("[AUDIO] autoplay failed", err);
        setError(err.message);
      });
    }
  }, []);

  const load = doLoad;

  const next = useCallback(() => {
    if (queue.length === 0) {
      pause();
      return;
    }
    const [n, ...rest] = queue;
    setQueue(rest);
    doLoad(n, { autoplay: true, replaceQueue: false });
    if (hapticEnabled) {
      haptic('trackChange', { intensity: hapticIntensity });
    }
  }, [queue, doLoad, pause, hapticEnabled, haptic, hapticIntensity]);

  const prev = useCallback(() => {
    // optional: implement history
    seek(0);
  }, [seek]);

  const enqueue = useCallback((tracks: Track[]) => {
    setQueue(q => [...q, ...tracks]);
  }, []);

  const clearQueue = useCallback(() => setQueue([]), []);

  // Haptic control functions
  const setHapticEnabled = useCallback((enabled: boolean) => {
    setHapticEnabledState(enabled);
    if (!enabled) {
      stopHaptic();
    }
  }, [stopHaptic]);

  const setHapticIntensity = useCallback((intensity: 'light' | 'medium' | 'heavy') => {
    setHapticIntensityState(intensity);
  }, []);

  // Load favorites from localStorage on mount
  useEffect(() => {
    const savedFavorites = localStorage.getItem('neurotunes-favorites');
    if (savedFavorites) {
      try {
        setFavorites(JSON.parse(savedFavorites));
      } catch (error) {
        console.error('Error loading favorites:', error);
      }
    }

    const savedSpatialAudio = localStorage.getItem('neurotunes-spatial-audio');
    if (savedSpatialAudio) {
      setSpatialAudioEnabledState(savedSpatialAudio === 'true');
    }
  }, []);

  // Favorites functionality with server sync
  const addToFavorites = useCallback(async (track: Track) => {
    try {
      // Add to server
      const response = await fetch('/api/user/favorites', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ track })
      });
      
      if (response.ok) {
        const data = await response.json();
        setFavorites(data.favorites);
        localStorage.setItem('neurotunes-favorites', JSON.stringify(data.favorites));
        
        // Log interaction
        fetch('/api/user/interactions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            type: 'favorite_added', 
            trackId: track.id, 
            trackTitle: track.title 
          })
        });
      } else {
        // Fallback to localStorage
        setFavorites(prev => {
          const exists = prev.find(fav => fav.id === track.id);
          if (exists) return prev;
          const newFavorites = [...prev, track];
          localStorage.setItem('neurotunes-favorites', JSON.stringify(newFavorites));
          return newFavorites;
        });
      }
      
      if (hapticEnabled) {
        haptic('success', { intensity: hapticIntensity });
      }
    } catch (error) {
      console.error('Error adding favorite:', error);
      // Fallback to localStorage on error
      setFavorites(prev => {
        const exists = prev.find(fav => fav.id === track.id);
        if (exists) return prev;
        const newFavorites = [...prev, track];
        localStorage.setItem('neurotunes-favorites', JSON.stringify(newFavorites));
        return newFavorites;
      });
    }
  }, [hapticEnabled, haptic, hapticIntensity]);

  const removeFromFavorites = useCallback(async (track: Track) => {
    try {
      // Remove from server
      const response = await fetch(`/api/user/favorites/${track.id}`, {
        method: 'DELETE'
      });
      
      if (response.ok) {
        const data = await response.json();
        setFavorites(data.favorites);
        localStorage.setItem('neurotunes-favorites', JSON.stringify(data.favorites));
        
        // Log interaction
        fetch('/api/user/interactions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            type: 'favorite_removed', 
            trackId: track.id, 
            trackTitle: track.title 
          })
        });
      } else {
        // Fallback to localStorage
        setFavorites(prev => {
          const newFavorites = prev.filter(fav => fav.id !== track.id);
          localStorage.setItem('neurotunes-favorites', JSON.stringify(newFavorites));
          return newFavorites;
        });
      }
      
      if (hapticEnabled) {
        haptic('error', { intensity: hapticIntensity });
      }
    } catch (error) {
      console.error('Error removing favorite:', error);
      // Fallback to localStorage on error
      setFavorites(prev => {
        const newFavorites = prev.filter(fav => fav.id !== track.id);
        localStorage.setItem('neurotunes-favorites', JSON.stringify(newFavorites));
        return newFavorites;
      });
    }
  }, [hapticEnabled, haptic, hapticIntensity]);

  // Thumbs down functionality - skip and dislike
  const thumbsDown = useCallback(async (track: Track) => {
    // Remove from favorites if it's there
    removeFromFavorites(track);
    
    // Skip to next track
    if (queue.length > 0) {
      next();
    } else {
      pause();
    }
    
    if (hapticEnabled) {
      haptic('trackChange', { intensity: hapticIntensity });
    }
    
    // Could add to a disliked tracks list here
    console.log(`Thumbs down on: ${track.title}`);
  }, [removeFromFavorites, queue.length, next, pause, hapticEnabled, haptic, hapticIntensity]);

  // Spatial Audio functionality
  const getSpatialAudioEnabled = useCallback(() => spatialAudioEnabled, [spatialAudioEnabled]);
  
  const setSpatialAudioEnabled = useCallback(async (enabled: boolean) => {
    setSpatialAudioEnabledState(enabled);
    localStorage.setItem('neurotunes-spatial-audio', enabled.toString());
    
    // Sync with server
    try {
      await fetch('/api/user/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ spatialAudioEnabled: enabled })
      });
      
      // Log interaction
      fetch('/api/user/interactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          type: 'spatial_audio_toggle', 
          enabled,
          device: navigator.userAgent.includes('Mobile') ? 'mobile' : 'desktop'
        })
      });
    } catch (error) {
      console.error('Error syncing spatial audio setting:', error);
    }
    
    // Apply spatial audio effect to the audio element
    if (audioRef.current) {
      try {
        if (enabled) {
          audioRef.current.setAttribute('data-spatial-audio', 'true');
        } else {
          audioRef.current.removeAttribute('data-spatial-audio');
        }
      } catch (error) {
        console.warn('Spatial audio effect not available:', error);
      }
    }
    
    if (hapticEnabled) {
      haptic(enabled ? 'success' : 'error', { intensity: hapticIntensity });
    }
  }, [hapticEnabled, haptic, hapticIntensity]);

  // Audio synchronization effect for haptic feedback
  useEffect(() => {
    if (!hapticEnabled || !current || !isPlaying) return;

    const cleanup = audioSyncHaptic(audioRef.current, true);
    return cleanup;
  }, [hapticEnabled, current, isPlaying, audioSyncHaptic]);

  const value: AudioContextValue = useMemo(() => ({
    isReady,
    isPlaying,
    current,
    queue,
    volume,
    positionSec,
    hapticEnabled,
    hapticIntensity,
    load,
    play,
    pause,
    toggle,
    next,
    prev,
    setVolume,
    seek,
    enqueue,
    clearQueue,
    setHapticEnabled,
    setHapticIntensity,
    // Missing functionality
    addToFavorites,
    removeFromFavorites,
    thumbsDown,
    getSpatialAudioEnabled,
    setSpatialAudioEnabled,
    // Legacy compatibility
    currentTime: positionSec,
    duration: audioRef.current?.duration || 0,
    error,
    playNext: next,
    playPrevious: prev,
  }), [
    isReady, isPlaying, current, queue, volume, positionSec, hapticEnabled, hapticIntensity,
    load, play, pause, toggle, next, prev, setVolume, seek, enqueue, clearQueue, 
    setHapticEnabled, setHapticIntensity, addToFavorites, removeFromFavorites, thumbsDown,
    getSpatialAudioEnabled, setSpatialAudioEnabled, error
  ]);

  useEffect(() => {
    console.log("[AUDIO PROVIDER] value ready", {
      current: current?.title ?? null,
      isPlaying,
      queueLen: queue.length
    });
  }, [current, isPlaying, queue.length]);

  return (
    <AudioContext.Provider value={value}>
      {children}
    </AudioContext.Provider>
  );
};