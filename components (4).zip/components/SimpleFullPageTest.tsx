import React from 'react';

// Ultra-simple full page player test - bypasses all complex components
export default function SimpleFullPageTest() {
  const [showModal, setShowModal] = React.useState(false);

  console.log('[SIMPLE TEST] Component rendering, showModal:', showModal);

  if (showModal) {
    return (
      <div 
        className="fixed inset-0 bg-black/95 z-[9999] flex items-center justify-center"
        onClick={() => setShowModal(false)}
      >
        <div className="bg-white text-black p-8 rounded-lg max-w-md text-center">
          <h1 className="text-2xl font-bold mb-4">✅ Full Page Player Works!</h1>
          <p className="mb-4">This proves the modal functionality is working correctly.</p>
          <button 
            className="px-6 py-3 bg-blue-600 text-white rounded hover:bg-blue-700"
            onClick={() => setShowModal(false)}
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed top-4 left-4 z-[9999]">
      <button
        onClick={() => {
          console.log('[SIMPLE TEST] Opening modal');
          setShowModal(true);
        }}
        className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg font-bold shadow-xl border-2 border-yellow-400"
        style={{ 
          position: 'fixed', 
          top: '20px', 
          left: '20px', 
          zIndex: 9999,
          fontSize: '16px'
        }}
      >
        🔴 SIMPLE TEST
      </button>
    </div>
  );
}