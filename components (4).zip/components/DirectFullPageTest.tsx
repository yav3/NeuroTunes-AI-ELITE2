import React from 'react';
import FullPagePlayer from './FullPagePlayer';
import { useAudio } from '../context/AudioContext';

// Direct test that bypasses PersistentMusicPlayer completely
export default function DirectFullPageTest() {
  const { current: currentTrack, isPlaying, toggle } = useAudio();
  const [showDirectTest, setShowDirectTest] = React.useState(false);

  console.log('[DIRECT TEST] Component rendering, showDirectTest:', showDirectTest);

  if (!currentTrack) {
    return (
      <div className="fixed bottom-4 left-4 z-[9999] bg-yellow-600 text-black px-3 py-1 rounded text-xs">
        Play a song first for direct test
      </div>
    );
  }

  if (showDirectTest) {
    console.log('[DIRECT TEST] Rendering FullPagePlayer directly');
    return (
      <FullPagePlayer
        track={currentTrack as any}
        isPlaying={isPlaying}
        onPlay={() => toggle()}
        onPause={() => toggle()}
        onClose={() => {
          console.log('[DIRECT TEST] FullPagePlayer closed');
          setShowDirectTest(false);
        }}
        onSkip={() => console.log('[DIRECT TEST] Skip requested')}
      />
    );
  }

  return (
    <div className="fixed bottom-4 left-4 z-[9999]">
      <button
        onClick={() => {
          console.log('[DIRECT TEST] Opening FullPagePlayer directly');
          setShowDirectTest(true);
        }}
        className="bg-orange-600 hover:bg-orange-700 text-white px-4 py-2 rounded-lg font-bold shadow-lg"
      >
        🟠 DIRECT FULL PAGE
      </button>
    </div>
  );
}