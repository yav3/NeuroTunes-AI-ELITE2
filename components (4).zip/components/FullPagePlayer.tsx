import React, { useState } from 'react';
import { useStableAudio } from '../context/StableAudioContext';
import { useNavigate } from 'react-router-dom';
import { X, Play, Pause, Volume2, SkipBack, SkipForward, Heart, ThumbsDown } from 'lucide-react';
import { apiRequest } from '../lib/queryClient';

export default function FullPagePlayer() {
  const navigate = useNavigate();
  const [isFavorite, setIsFavorite] = useState(false);
  const [isDisliked, setIsDisliked] = useState(false);
  const {
    current: currentTrack,
    isPlaying,
    toggle,
    volume,
    setVolume,
    currentTime,
    duration,
    seek
  } = useStableAudio();

  const handleFavoriteToggle = async () => {
    try {
      if (isFavorite) {
        await apiRequest('DELETE', `/api/tracks/${currentTrack.id}/favorite`);
        setIsFavorite(false);
        console.log('Removed from favorites');
      } else {
        await apiRequest('POST', `/api/tracks/${currentTrack.id}/favorite`);
        setIsFavorite(true);
        setIsDisliked(false); // Clear dislike when favoriting
        console.log('Added to favorites');
      }
    } catch (error) {
      console.error('Error toggling favorite:', error);
    }
  };

  const handleDislikeToggle = async () => {
    try {
      if (isDisliked) {
        await apiRequest('DELETE', `/api/tracks/${currentTrack.id}/dislike`);
        setIsDisliked(false);
        console.log('Removed dislike');
      } else {
        await apiRequest('POST', `/api/tracks/${currentTrack.id}/dislike`);
        setIsDisliked(true);
        setIsFavorite(false); // Clear favorite when disliking
        console.log('Added dislike');
      }
    } catch (error) {
      console.error('Error toggling dislike:', error);
    }
  };

  // Don't render if no track is loaded
  if (!currentTrack) {
    navigate('/');
    return null;
  }

  const formatTime = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = clickX / rect.width;
    const newTime = percentage * duration;
    seek(newTime);
  };

  const progressPercentage = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-blue-900/20 to-slate-900 z-[3000]">
      {/* Background Art */}
      <div className="absolute inset-0 opacity-20">
        <img 
          src={`/api/art/${encodeURIComponent(currentTrack.title)}`}
          alt=""
          className="w-full h-full object-cover blur-3xl scale-110"
          onError={(e) => {
            e.currentTarget.style.display = 'none';
          }}
        />
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 md:p-6">
          <button
            onClick={() => navigate(-1)}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors text-white"
          >
            <X size={24} />
          </button>
          
          <div className="text-center">
            <h1 className="text-white/80 text-sm font-medium">Now Playing</h1>
          </div>
          
          <div className="w-12"></div> {/* Spacer for balance */}
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 md:px-12 space-y-8">
          {/* Album Art */}
          <div className="w-80 h-80 md:w-96 md:h-96 rounded-2xl overflow-hidden shadow-2xl bg-gradient-to-br from-blue-500/30 to-purple-500/30 backdrop-blur">
            <img 
              src={`/api/art/${encodeURIComponent(currentTrack.title)}`}
              alt={currentTrack.title}
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                const parent = e.currentTarget.parentElement!;
                parent.innerHTML = `
                  <div class="w-full h-full flex items-center justify-center">
                    <div class="text-white/60 text-6xl">♪</div>
                  </div>
                `;
              }}
            />
          </div>

          {/* Track Info */}
          <div className="text-center space-y-2 max-w-lg">
            <h2 className="text-2xl md:text-3xl font-bold text-white truncate">
              {currentTrack.title.replace(/^organized\/[^\/]+\//, '')}
            </h2>
            <p className="text-blue-300 text-lg">
              {currentTrack.artist || 'NeuroTunes'}
            </p>
            <p className="text-white/60 text-sm">
              {(() => {
                const tags = currentTrack.therapeuticTags || ['mood_boost'];
                const friendlyTags: Record<string, string> = {
                  'mood_boost': 'Mood Enhancement',
                  'focus': 'Focus & Concentration', 
                  'relaxation': 'Relaxation & Calm',
                  'energy_boost': 'Energy & Motivation',
                  'anxiety_management': 'Anxiety Relief',
                  'sleep_enhancement': 'Sleep Support',
                  'general': 'Therapeutic Music'
                };
                return tags.map(tag => friendlyTags[tag] || tag).join(' • ');
              })()}
            </p>
          </div>

          {/* Progress Bar */}
          <div className="w-full max-w-md space-y-2">
            <div 
              className="h-2 bg-white/20 rounded-full cursor-pointer group"
              onClick={handleSeek}
            >
              <div 
                className="h-full bg-blue-400 rounded-full transition-all group-hover:bg-blue-300"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <div className="flex justify-between text-sm text-white/60">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-6">
            <button className="p-3 rounded-full text-white/60 hover:text-white transition-colors">
              <SkipBack size={28} />
            </button>
            
            <button
              onClick={toggle}
              className="p-4 rounded-full bg-blue-500 hover:bg-blue-600 transition-colors text-white shadow-lg"
            >
              {isPlaying ? <Pause size={32} /> : <Play size={32} />}
            </button>
            
            <button className="p-3 rounded-full text-white/60 hover:text-white transition-colors">
              <SkipForward size={28} />
            </button>
            
            {/* Favorite and Dislike Buttons - moved here for better visibility */}
            <button 
              onClick={handleFavoriteToggle}
              className={`p-3 rounded-full transition-colors ${
                isFavorite 
                  ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' 
                  : 'text-white/60 hover:text-white hover:bg-white/10'
              }`}
            >
              <Heart size={24} fill={isFavorite ? 'currentColor' : 'none'} />
            </button>
            
            <button 
              onClick={handleDislikeToggle}
              className={`p-3 rounded-full transition-colors ${
                isDisliked 
                  ? 'bg-gray-500/20 text-gray-400 hover:bg-gray-500/30' 
                  : 'text-white/60 hover:text-white hover:bg-white/10'
              }`}
            >
              <ThumbsDown size={24} fill={isDisliked ? 'currentColor' : 'none'} />
            </button>
          </div>

          {/* Volume Control */}
          <div className="flex items-center space-x-3 max-w-xs w-full">
            <Volume2 size={20} className="text-white/60" />
            <div className="flex-1">
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-full h-2 bg-white/20 rounded-full appearance-none cursor-pointer
                  [&::-webkit-slider-thumb]:appearance-none 
                  [&::-webkit-slider-thumb]:w-4 
                  [&::-webkit-slider-thumb]:h-4 
                  [&::-webkit-slider-thumb]:rounded-full 
                  [&::-webkit-slider-thumb]:bg-blue-400 
                  [&::-webkit-slider-thumb]:cursor-pointer
                  [&::-moz-range-thumb]:w-4 
                  [&::-moz-range-thumb]:h-4 
                  [&::-moz-range-thumb]:rounded-full 
                  [&::-moz-range-thumb]:bg-blue-400 
                  [&::-moz-range-thumb]:border-none 
                  [&::-moz-range-thumb]:cursor-pointer"
              />
            </div>
            <span className="text-white/60 text-sm w-8 text-right">
              {Math.round(volume * 100)}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}