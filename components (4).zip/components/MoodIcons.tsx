// Professional SVG icons based on user's reference designs
export const MoodIcons = {
  focus: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      <defs>
        <radialGradient id="focusGradient" cx="50%" cy="50%" r="40%">
          <stop offset="0%" stopColor="rgba(96, 165, 250, 0.8)" />
          <stop offset="100%" stopColor="rgba(59, 130, 246, 0.4)" />
        </radialGradient>
      </defs>
      {/* Starburst pattern for focus */}
      {Array.from({ length: 16 }, (_, i) => {
        const angle = (i * 22.5) * Math.PI / 180;
        const x1 = 50 + Math.cos(angle) * 15;
        const y1 = 50 + Math.sin(angle) * 15;
        const x2 = 50 + Math.cos(angle) * 35;
        const y2 = 50 + Math.sin(angle) * 35;
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="rgba(96, 165, 250, 0.7)"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        );
      })}
      <circle cx="50" cy="50" r="4" fill="rgba(96, 165, 250, 0.9)" />
    </svg>
  ),

  relaxation: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Flowing hills/waves for relaxation */}
      <path
        d="M10 60 Q30 50 50 60 T90 60 L90 90 L10 90 Z"
        fill="rgba(96, 165, 250, 0.3)"
      />
      <path
        d="M10 70 Q30 65 50 70 T90 70 L90 90 L10 90 Z"
        fill="rgba(96, 165, 250, 0.2)"
      />
      {/* Gentle circles for calm */}
      <circle cx="25" cy="25" r="8" fill="rgba(147, 197, 253, 0.4)" />
      <circle cx="65" cy="20" r="12" fill="rgba(147, 197, 253, 0.3)" />
      <circle cx="75" cy="45" r="6" fill="rgba(147, 197, 253, 0.5)" />
    </svg>
  ),

  energy_boost: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      <defs>
        <radialGradient id="energyGradient" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="rgba(251, 191, 36, 0.9)" />
          <stop offset="100%" stopColor="rgba(245, 158, 11, 0.6)" />
        </radialGradient>
      </defs>
      {/* Sun with rays for energy */}
      <circle cx="50" cy="50" r="15" fill="url(#energyGradient)" />
      {Array.from({ length: 12 }, (_, i) => {
        const angle = (i * 30) * Math.PI / 180;
        const x1 = 50 + Math.cos(angle) * 22;
        const y1 = 50 + Math.sin(angle) * 22;
        const x2 = 50 + Math.cos(angle) * 35;
        const y2 = 50 + Math.sin(angle) * 35;
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="rgba(251, 191, 36, 0.8)"
            strokeWidth="2"
            strokeLinecap="round"
          />
        );
      })}
    </svg>
  ),

  nsdr: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Crescent moon with stars for NSDR/deep rest */}
      <path
        d="M35 20 Q25 30 25 50 Q25 70 35 80 Q55 70 55 50 Q55 30 35 20"
        fill="rgba(96, 165, 250, 0.7)"
      />
      <circle cx="65" cy="25" r="2" fill="rgba(196, 181, 253, 0.8)" />
      <circle cx="75" cy="35" r="1.5" fill="rgba(196, 181, 253, 0.6)" />
      <circle cx="70" cy="15" r="1" fill="rgba(196, 181, 253, 0.9)" />
      <circle cx="80" cy="25" r="1" fill="rgba(196, 181, 253, 0.7)" />
    </svg>
  ),

  pain_management: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Sunrise over waves for relief */}
      <path
        d="M20 70 Q40 60 60 70 T100 70 L100 90 L20 90 Z"
        fill="rgba(96, 165, 250, 0.3)"
      />
      <path
        d="M20 80 Q40 75 60 80 T100 80 L100 90 L20 90 Z"
        fill="rgba(96, 165, 250, 0.2)"
      />
      {/* Half sun */}
      <path
        d="M50 50 A15 15 0 0 1 80 50 L50 50"
        fill="rgba(251, 191, 36, 0.6)"
      />
      {/* Sun rays */}
      {Array.from({ length: 7 }, (_, i) => {
        const angle = (i * 25 - 75) * Math.PI / 180;
        const x1 = 65 + Math.cos(angle) * 18;
        const y1 = 50 + Math.sin(angle) * 18;
        const x2 = 65 + Math.cos(angle) * 28;
        const y2 = 50 + Math.sin(angle) * 28;
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="rgba(251, 191, 36, 0.7)"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        );
      })}
    </svg>
  ),

  cardio_hiit: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Dynamic energy burst for cardio */}
      <circle cx="50" cy="50" r="12" fill="rgba(96, 165, 250, 0.6)" />
      {Array.from({ length: 20 }, (_, i) => {
        const angle = (i * 18) * Math.PI / 180;
        const length = 15 + (i % 3) * 8;
        const x1 = 50 + Math.cos(angle) * 15;
        const y1 = 50 + Math.sin(angle) * 15;
        const x2 = 50 + Math.cos(angle) * length;
        const y2 = 50 + Math.sin(angle) * length;
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="rgba(96, 165, 250, 0.7)"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        );
      })}
    </svg>
  ),

  light_exercise: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Gentle radiating lines */}
      {Array.from({ length: 12 }, (_, i) => {
        const angle = (i * 30) * Math.PI / 180;
        const x1 = 50 + Math.cos(angle) * 20;
        const y1 = 50 + Math.sin(angle) * 20;
        const x2 = 50 + Math.cos(angle) * 30;
        const y2 = 50 + Math.sin(angle) * 30;
        return (
          <line
            key={i}
            x1={x1}
            y1={y1}
            x2={x2}
            y2={y2}
            stroke="rgba(96, 165, 250, 0.6)"
            strokeWidth="1"
            strokeLinecap="round"
          />
        );
      })}
      <circle cx="50" cy="50" r="3" fill="rgba(96, 165, 250, 0.8)" />
    </svg>
  ),

  walk_warm_up: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Gentle expanding circles */}
      <circle cx="50" cy="50" r="8" fill="none" stroke="rgba(96, 165, 250, 0.6)" strokeWidth="1" />
      <circle cx="50" cy="50" r="18" fill="none" stroke="rgba(96, 165, 250, 0.4)" strokeWidth="1" />
      <circle cx="50" cy="50" r="28" fill="none" stroke="rgba(96, 165, 250, 0.2)" strokeWidth="1" />
      <circle cx="50" cy="50" r="3" fill="rgba(96, 165, 250, 0.8)" />
    </svg>
  ),

  anxiety_reduction: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Calm landscape with moon and stars */}
      <path
        d="M10 65 Q30 55 50 65 T90 65 L90 90 L10 90 Z"
        fill="rgba(96, 165, 250, 0.2)"
      />
      <path
        d="M25 25 Q20 35 20 50 Q20 65 25 75 Q40 65 40 50 Q40 35 25 25"
        fill="rgba(96, 165, 250, 0.6)"
      />
      <circle cx="65" cy="20" r="1.5" fill="rgba(196, 181, 253, 0.8)" />
      <circle cx="75" cy="30" r="1" fill="rgba(196, 181, 253, 0.7)" />
      <circle cx="80" cy="15" r="1" fill="rgba(196, 181, 253, 0.9)" />
    </svg>
  ),

  chill: (
    <svg viewBox="0 0 100 100" className="w-full h-full">
      {/* Soft cloud shape */}
      <ellipse cx="40" cy="45" rx="18" ry="12" fill="rgba(96, 165, 250, 0.4)" />
      <ellipse cx="60" cy="45" rx="15" ry="10" fill="rgba(96, 165, 250, 0.5)" />
      <ellipse cx="50" cy="55" rx="25" ry="15" fill="rgba(96, 165, 250, 0.3)" />
    </svg>
  )
};