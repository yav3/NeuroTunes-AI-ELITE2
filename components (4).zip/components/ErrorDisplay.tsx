import { AlertTriangle, RefreshCw, Wifi, WifiOff, AlertCircle, Info } from 'lucide-react';
import { parseAPIError, UserFriendlyError, retryOperation } from '../utils/errorHandler';
import { useState } from 'react';

interface ErrorDisplayProps {
  error: any;
  onRetry?: () => void;
  onDismiss?: () => void;
  compact?: boolean;
  showDetails?: boolean;
}

export default function ErrorDisplay({ 
  error, 
  onRetry, 
  onDismiss, 
  compact = false,
  showDetails = false 
}: ErrorDisplayProps) {
  const [isRetrying, setIsRetrying] = useState(false);
  const userError = parseAPIError(error);

  const handleRetry = async () => {
    if (!onRetry) return;
    
    setIsRetrying(true);
    try {
      await retryOperation(onRetry, 1);
    } catch (retryError) {
      // Retry failed, keep showing error
    } finally {
      setIsRetrying(false);
    }
  };

  const getIcon = (type: UserFriendlyError['type']) => {
    switch (type) {
      case 'network':
        return navigator.onLine ? <Wifi /> : <WifiOff />;
      case 'audio':
        return <AlertCircle />;
      case 'validation':
        return <Info />;
      default:
        return <AlertTriangle />;
    }
  };

  const getThemeColors = (type: UserFriendlyError['type']) => {
    switch (type) {
      case 'network':
        return {
          bg: 'rgba(234, 179, 8, 0.1)',
          border: 'rgba(234, 179, 8, 0.3)',
          text: '#fbbf24',
          icon: '#eab308'
        };
      case 'validation':
        return {
          bg: 'rgba(59, 130, 246, 0.1)',
          border: 'rgba(59, 130, 246, 0.3)',
          text: '#60a5fa',
          icon: '#3b82f6'
        };
      case 'audio':
        return {
          bg: 'rgba(168, 85, 247, 0.1)',
          border: 'rgba(168, 85, 247, 0.3)',
          text: '#c084fc',
          icon: '#a855f7'
        };
      default:
        return {
          bg: 'rgba(239, 68, 68, 0.1)',
          border: 'rgba(239, 68, 68, 0.3)',
          text: '#f87171',
          icon: '#ef4444'
        };
    }
  };

  const theme = getThemeColors(userError.type);

  if (compact) {
    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        padding: '8px 12px',
        background: theme.bg,
        border: `1px solid ${theme.border}`,
        borderRadius: '8px',
        fontSize: '14px',
        color: theme.text
      }}>
        <div style={{ color: theme.icon, flexShrink: 0 }}>
          {getIcon(userError.type)}
        </div>
        <span style={{ flex: 1 }}>{userError.message}</span>
        
        {userError.retryable && onRetry && (
          <button
            onClick={handleRetry}
            disabled={isRetrying}
            style={{
              background: 'none',
              border: `1px solid ${theme.border}`,
              borderRadius: '4px',
              color: theme.text,
              padding: '4px 8px',
              fontSize: '12px',
              cursor: isRetrying ? 'not-allowed' : 'pointer',
              opacity: isRetrying ? 0.6 : 1
            }}
          >
            {isRetrying ? 'Retrying...' : 'Retry'}
          </button>
        )}
        
        {onDismiss && (
          <button
            onClick={onDismiss}
            style={{
              background: 'none',
              border: 'none',
              color: theme.text,
              cursor: 'pointer',
              padding: '4px',
              fontSize: '16px'
            }}
          >
            ×
          </button>
        )}
      </div>
    );
  }

  return (
    <div style={{
      background: theme.bg,
      border: `1px solid ${theme.border}`,
      borderRadius: '12px',
      padding: '24px',
      textAlign: 'center' as const,
      maxWidth: '400px',
      margin: '20px auto'
    }}>
      <div style={{
        width: '48px',
        height: '48px',
        background: theme.icon,
        borderRadius: '12px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto 16px',
        color: 'white'
      }}>
        {getIcon(userError.type)}
      </div>

      <h3 style={{
        fontSize: '18px',
        fontWeight: '600',
        marginBottom: '8px',
        color: theme.text
      }}>
        {userError.title}
      </h3>

      <p style={{
        fontSize: '14px',
        color: '#cbd5e1',
        marginBottom: '20px',
        lineHeight: '1.5'
      }}>
        {userError.message}
      </p>

      <div style={{
        display: 'flex',
        gap: '12px',
        justifyContent: 'center',
        flexWrap: 'wrap' as const
      }}>
        {userError.retryable && onRetry && (
          <button
            onClick={handleRetry}
            disabled={isRetrying}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              padding: '10px 20px',
              background: theme.icon,
              border: 'none',
              borderRadius: '8px',
              color: 'white',
              fontSize: '14px',
              fontWeight: '600',
              cursor: isRetrying ? 'not-allowed' : 'pointer',
              opacity: isRetrying ? 0.6 : 1,
              transition: 'transform 0.2s'
            }}
            onMouseEnter={(e) => {
              if (!isRetrying) e.currentTarget.style.transform = 'scale(1.05)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'scale(1)';
            }}
          >
            <RefreshCw style={{ width: '16px', height: '16px' }} />
            {isRetrying ? 'Retrying...' : userError.action || 'Retry'}
          </button>
        )}

        {onDismiss && (
          <button
            onClick={onDismiss}
            style={{
              padding: '10px 20px',
              background: 'rgba(71, 85, 105, 0.5)',
              border: '1px solid rgba(71, 85, 105, 0.3)',
              borderRadius: '8px',
              color: '#cbd5e1',
              fontSize: '14px',
              fontWeight: '600',
              cursor: 'pointer',
              transition: 'all 0.2s'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = 'rgba(71, 85, 105, 0.7)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = 'rgba(71, 85, 105, 0.5)';
            }}
          >
            Dismiss
          </button>
        )}
      </div>

      {showDetails && process.env.NODE_ENV === 'development' && (
        <details style={{
          marginTop: '20px',
          textAlign: 'left' as const
        }}>
          <summary style={{
            cursor: 'pointer',
            fontSize: '12px',
            color: '#64748b',
            marginBottom: '8px'
          }}>
            Technical Details
          </summary>
          <pre style={{
            fontSize: '11px',
            color: '#64748b',
            background: 'rgba(30, 41, 59, 0.5)',
            padding: '12px',
            borderRadius: '6px',
            overflow: 'auto',
            maxHeight: '150px'
          }}>
            {JSON.stringify(error, null, 2)}
          </pre>
        </details>
      )}
    </div>
  );
}

// Toast-style error notification
export function ErrorToast({ error, onDismiss }: { error: any; onDismiss: () => void }) {
  const userError = parseAPIError(error);
  const theme = getThemeColors(userError.type);

  return (
    <div style={{
      position: 'fixed' as const,
      top: '20px',
      right: '20px',
      zIndex: 1000,
      background: 'rgba(15, 23, 42, 0.95)',
      backdropFilter: 'blur(12px)',
      border: `1px solid ${theme.border}`,
      borderRadius: '12px',
      padding: '16px',
      maxWidth: '400px',
      boxShadow: '0 10px 25px rgba(0, 0, 0, 0.5)'
    }}>
      <div style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: '12px'
      }}>
        <div style={{ color: theme.icon, marginTop: '2px' }}>
          {getIcon(userError.type)}
        </div>
        <div style={{ flex: 1 }}>
          <h4 style={{
            fontSize: '14px',
            fontWeight: '600',
            marginBottom: '4px',
            color: theme.text
          }}>
            {userError.title}
          </h4>
          <p style={{
            fontSize: '13px',
            color: '#cbd5e1',
            lineHeight: '1.4'
          }}>
            {userError.message}
          </p>
        </div>
        <button
          onClick={onDismiss}
          style={{
            background: 'none',
            border: 'none',
            color: '#64748b',
            cursor: 'pointer',
            fontSize: '18px',
            padding: '0',
            lineHeight: '1'
          }}
        >
          ×
        </button>
      </div>
    </div>
  );
}

function getThemeColors(type: UserFriendlyError['type']) {
  switch (type) {
    case 'network':
      return {
        bg: 'rgba(234, 179, 8, 0.1)',
        border: 'rgba(234, 179, 8, 0.3)',
        text: '#fbbf24',
        icon: '#eab308'
      };
    case 'validation':
      return {
        bg: 'rgba(59, 130, 246, 0.1)',
        border: 'rgba(59, 130, 246, 0.3)',
        text: '#60a5fa',
        icon: '#3b82f6'
      };
    case 'audio':
      return {
        bg: 'rgba(168, 85, 247, 0.1)',
        border: 'rgba(168, 85, 247, 0.3)',
        text: '#c084fc',
        icon: '#a855f7'
      };
    default:
      return {
        bg: 'rgba(239, 68, 68, 0.1)',
        border: 'rgba(239, 68, 68, 0.3)',
        text: '#f87171',
        icon: '#ef4444'
      };
  }
}