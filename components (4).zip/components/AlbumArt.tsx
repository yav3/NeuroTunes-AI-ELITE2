import React, { useState } from 'react';

interface Track {
  id: string | number;
  title?: string;
  artworkUrl?: string | null;
}

interface AlbumArtProps {
  track: Track;
  size?: number;
  rounded?: string;
  className?: string;
}

export default function AlbumArt({ 
  track, 
  size = 96, 
  rounded = 'rounded-2xl', 
  className = '' 
}: AlbumArtProps) {
  const [errored, setErrored] = useState(false);
  
  const src = !errored 
    ? (track.artworkUrl || `/api/art/${encodeURIComponent(track.title || String(track.id))}`)
    : undefined;

  return (
    <div
      className={`relative ${rounded} ring-1 ${className}`}
      style={{
        width: size,
        height: size,
        background: 'linear-gradient(180deg, rgba(28,56,92,0.18) 0%, rgba(7,13,24,0.6) 100%)',
        borderColor: 'rgba(86,126,255,0.18)',
        overflow: 'hidden'
      }}
    >
      {src ? (
        <img
          src={src}
          alt=""
          className="w-full h-full object-cover"
          onError={() => setErrored(true)}
          loading="lazy"
          decoding="async"
        />
      ) : (
        <div 
          className="w-full h-full" 
          aria-hidden
          style={{
            background: 'radial-gradient(60% 60% at 50% 40%, #1c2a4a 0%, #0b1221 60%, #070d18 100%)'
          }}
        />
      )}

      {/* Soft top highlight for Apple-style depth */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background: 'linear-gradient(180deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0.00) 40%)'
        }}
      />
    </div>
  );
}