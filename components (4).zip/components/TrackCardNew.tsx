import { Play, Pause } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { trackStreamUrl } from '../lib/apiNew';
import type { Track } from '../lib/apiNew';

interface TrackCardProps {
  track: Track;
}

export default function TrackCard({ track }: TrackCardProps) {
  const { current, isPlaying, play, pause } = useAudio();
  
  const isCurrentTrack = current?.id === track.id;
  const streamUrl = trackStreamUrl(track);
  
  const handlePlay = () => {
    if (isCurrentTrack && isPlaying) {
      pause();
    } else {
      play({ ...track, streamUrl });
    }
  };
  
  return (
    <div className="card flex items-center gap-4 hover:brightness-110 transition-all">
      <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
        <button
          onClick={handlePlay}
          className="w-8 h-8 flex items-center justify-center text-white hover:text-blue-400 transition-colors"
        >
          {isCurrentTrack && isPlaying ? (
            <Pause size={16} />
          ) : (
            <Play size={16} />
          )}
        </button>
      </div>
      
      <div className="min-w-0 flex-1">
        <h3 className="text-sm font-medium text-white truncate">{track.title}</h3>
        <p className="text-xs text-white/60 truncate">{track.artist || 'Unknown Artist'}</p>
        {track.tags && track.tags.length > 0 && (
          <div className="flex gap-1 mt-1">
            {track.tags.slice(0, 2).map((tag, i) => (
              <span key={i} className="text-xs px-2 py-0.5 bg-white/10 rounded text-white/70">
                {tag}
              </span>
            ))}
          </div>
        )}
      </div>
      
      {track.duration && (
        <div className="text-xs text-white/50 flex-shrink-0">
          {Math.floor(track.duration / 60)}:{(track.duration % 60).toString().padStart(2, '0')}
        </div>
      )}
    </div>
  );
}