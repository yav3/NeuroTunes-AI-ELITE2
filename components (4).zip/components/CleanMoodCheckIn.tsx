import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';

const GOALS = [
  "Focus", // 100 tracks - cognitive enhancement and concentration
  "Relaxation", // 57 tracks - comprehensive relaxation library
  "Energy Boost" // 46 tracks - motivation and activation
];

// Removed MOOD_LABELS as we're using dropdown with detailed descriptions

interface CleanMoodCheckInProps {
  onStartTherapy: (data: { mood: string; goal: string; genre: string }) => void;
  isStartingSession?: boolean;
}

export default function CleanMoodCheckIn({ onStartTherapy, isStartingSession = false }: CleanMoodCheckInProps) {
  const [selectedGoal, setSelectedGoal] = useState<string>("");
  const [selectedGenre, setSelectedGenre] = useState<string>("Any Genre");

  // Removed mood selection - using default neutral mood

  // Fetch available genres from your actual music library
  const { data: genreData = [] } = useQuery({
    queryKey: ['/api/tracks/genres'],
  });

  // Genre list - only keeping genres with 10+ tracks
  const availableGenres = [
    "Any Genre",
    "Electronic", // 62 tracks - electronic, EDM, house
    "Classical", // 63 tracks - baroque, classical, renaissance, opera  
    "Indie Pop" // 39 tracks - indie pop category
  ];

  const handleStartTherapy = () => {
    if (!selectedGoal) return;
    
    onStartTherapy({
      mood: "3", // Default neutral mood since we removed mood selection
      goal: selectedGoal,
      genre: selectedGenre
    });
  };

  return (
    <div className="w-full max-w-sm mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-light text-white mb-3">Welcome Back!</h2>
        <p className="text-white/70 text-sm">Let's start your therapeutic music session</p>
      </div>

      {/* Goal Selection */}
      <Card className="glass-card rounded-xl">
        <CardContent className="p-8">
          <div className="space-y-4">
            <label className="text-sm font-medium text-white">Choose your goal</label>
            <Select value={selectedGoal} onValueChange={setSelectedGoal}>
              <SelectTrigger className="w-full glass-input text-white h-12">
                <SelectValue placeholder="Select your goal..." />
              </SelectTrigger>
              <SelectContent className="glass-card">
                {GOALS.map((goal) => (
                  <SelectItem key={goal} value={goal} className="text-white hover:bg-blue-500/20">
                    {goal}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Music Preference */}
      <Card className="glass-card rounded-xl">
        <CardContent className="p-8">
          <div className="space-y-4">
            <label className="text-sm font-medium text-white">Choose your music preference</label>
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="w-full glass-input text-white h-12">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-card">
                {availableGenres.map((genre) => (
                  <SelectItem key={genre} value={genre} className="text-white hover:bg-blue-500/20">
                    {genre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="space-y-4 pt-4">
        <div className="flex gap-4">
          <Button variant="outline" className="flex-1 glass-button text-white hover:bg-blue-500/30 h-12">
            View history
          </Button>
          <Button variant="outline" className="flex-1 glass-button text-white hover:bg-blue-500/30 h-12">
            Add entry
          </Button>
        </div>
        
        <Button 
          onClick={handleStartTherapy}
          disabled={!selectedGoal || isStartingSession}
          className="w-full glass-button hover:bg-blue-500/30 text-white font-medium py-4 rounded-xl disabled:opacity-50 h-14 text-base"
        >
          {isStartingSession ? "Starting..." : "Start Therapy"}
        </Button>
      </div>
    </div>
  );
}