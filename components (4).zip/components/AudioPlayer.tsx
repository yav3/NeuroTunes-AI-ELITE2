import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Play, Pause, SkipForward, SkipBack, Volume2 } from 'lucide-react';
import type { Track } from '@shared/schema';

interface AudioPlayerProps {
  currentTrack?: Track | null;
  isPlaying: boolean;
  onPlayPause: () => void;
  onTrackChange: (track: Track | null) => void;
}

export default function AudioPlayer({ 
  currentTrack, 
  isPlaying, 
  onPlayPause, 
  onTrackChange 
}: AudioPlayerProps) {
  const [progress, setProgress] = useState(0);
  const [volume, setVolume] = useState(70);
  const [currentTime, setCurrentTime] = useState(0);

  // Mock track for demonstration
  const mockTrack: Track = {
    id: 1,
    title: "Forest Ambience",
    artist: "Nature Sounds Collection",
    album: "Therapeutic Sounds",
    duration: 522, // 8:42
    audioUrl: "",
    coverUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=60&h=60&fit=crop",
    mood: "calm",
    valence: 0.7,
    energy: 0.3,
    therapeuticTags: ["calming", "nature"],
    binaural: false,
    frequency: null,
    createdAt: new Date(),
  };

  const track = currentTrack || mockTrack;

  useEffect(() => {
    if (isPlaying) {
      const interval = setInterval(() => {
        setCurrentTime(prev => {
          const newTime = prev + 1;
          const newProgress = (newTime / track.duration) * 100;
          setProgress(newProgress);
          return newTime;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [isPlaying, track.duration]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleNext = () => {
    // Mock next track functionality
    setCurrentTime(0);
    setProgress(0);
  };

  const handlePrevious = () => {
    // Mock previous track functionality
    setCurrentTime(0);
    setProgress(0);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 glass-effect border-t border-white/20 p-4 z-40">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center space-x-6">
          {/* Currently Playing */}
          <div className="flex items-center space-x-4">
            <img 
              src={track.coverUrl || "/placeholder-track.jpg"} 
              alt={`Now playing: ${track.title}`} 
              className="w-15 h-15 rounded-2xl object-cover"
            />
            <div>
              <h4 className="font-medium text-gray-900">{track.title}</h4>
              <p className="text-sm text-gray-600">{track.artist}</p>
            </div>
          </div>
          
          {/* Controls */}
          <div className="flex-1 flex items-center justify-center space-x-4">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handlePrevious}
              className="w-10 h-10 text-gray-600 hover:text-calm-primary transition-colors"
            >
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button 
              onClick={onPlayPause}
              className="w-12 h-12 bg-calm-primary hover:bg-calm-primary/90 rounded-full text-white transition-colors"
            >
              {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleNext}
              className="w-10 h-10 text-gray-600 hover:text-calm-primary transition-colors"
            >
              <SkipForward className="w-4 h-4" />
            </Button>
          </div>
          
          {/* Progress & Volume */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500 font-mono">{formatTime(currentTime)}</span>
              <div className="w-32 bg-gray-200 rounded-full h-1">
                <div 
                  className="bg-calm-primary h-1 rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <span className="text-sm text-gray-500 font-mono">{formatTime(track.duration)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Volume2 className="w-4 h-4 text-gray-600" />
              <div className="w-20 bg-gray-200 rounded-full h-1">
                <div 
                  className="bg-calm-primary h-1 rounded-full"
                  style={{ width: `${volume}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
