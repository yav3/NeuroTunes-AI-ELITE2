import React, { useState } from 'react';
import { useEdgeStreaming, useStreamingPreferences } from '@/hooks/useEdgeStreaming';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Trash2, Download, Wifi, WifiOff } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface EdgeCacheManagerProps {
  userId?: string;
}

export function EdgeCacheManager({ userId }: EdgeCacheManagerProps) {
  const { toast } = useToast();
  const {
    cachedFavorites,
    cacheSize,
    isOfflineMode,
    getOfflineTracks,
    cleanupCache,
    getCacheInfo
  } = useEdgeStreaming(userId);

  const {
    preferences,
    updatePreferences,
    isUpdating
  } = useStreamingPreferences(userId);

  const [maxCacheSize, setMaxCacheSize] = useState(preferences.maxCacheSize);
  const cacheInfo = getCacheInfo();
  const offlineTracks = getOfflineTracks();

  const handlePreferenceUpdate = async (key: string, value: any) => {
    try {
      await updatePreferences({ [key]: value });
      toast({
        title: "Settings Updated",
        description: "Your streaming preferences have been saved",
      });
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "Failed to update streaming preferences",
        variant: "destructive",
      });
    }
  };

  const handleCleanupCache = () => {
    cleanupCache();
    toast({
      title: "Cache Cleaned",
      description: "Old cached tracks have been removed",
    });
  };

  return (
    <div className="space-y-6">
      {/* Connection Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {isOfflineMode ? (
              <WifiOff className="h-5 w-5 text-red-500" />
            ) : (
              <Wifi className="h-5 w-5 text-green-500" />
            )}
            Connection Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <span>
              {isOfflineMode ? "Offline Mode" : "Connected"}
            </span>
            <Badge variant={isOfflineMode ? "destructive" : "default"}>
              {isOfflineMode ? "Offline" : "Online"}
            </Badge>
          </div>
          {isOfflineMode && (
            <p className="text-sm text-muted-foreground mt-2">
              {offlineTracks.length} tracks available offline
            </p>
          )}
        </CardContent>
      </Card>

      {/* Cache Statistics */}
      <Card>
        <CardHeader>
          <CardTitle>Cache Statistics</CardTitle>
          <CardDescription>
            Your edge cache enables faster music streaming and offline listening
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-blue-600">
                {cacheInfo.totalTracks}
              </div>
              <div className="text-sm text-muted-foreground">
                Cached Tracks
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-600">
                {cacheInfo.cacheSize}
              </div>
              <div className="text-sm text-muted-foreground">
                Storage Used
              </div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">
                {cacheInfo.offlineAvailable}
              </div>
              <div className="text-sm text-muted-foreground">
                Offline Ready
              </div>
            </div>
          </div>
          
          <div className="flex justify-center">
            <Button
              onClick={handleCleanupCache}
              variant="outline"
              size="sm"
              className="gap-2"
            >
              <Trash2 className="h-4 w-4" />
              Clean Cache
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Streaming Preferences */}
      <Card>
        <CardHeader>
          <CardTitle>Streaming Preferences</CardTitle>
          <CardDescription>
            Configure how music is cached and streamed for optimal performance
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Max Cache Size */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium">Max Cache Size</label>
              <span className="text-sm text-muted-foreground">
                {maxCacheSize} MB
              </span>
            </div>
            <Slider
              value={[maxCacheSize]}
              onValueChange={(value) => setMaxCacheSize(value[0])}
              onValueCommit={(value) => handlePreferenceUpdate('maxCacheSize', value[0])}
              max={500}
              min={50}
              step={25}
              className="w-full"
            />
          </div>

          {/* Audio Quality */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Audio Quality</label>
            <div className="flex gap-2">
              {(['standard', 'high', 'lossless'] as const).map((quality) => (
                <Button
                  key={quality}
                  variant={preferences.preferredQuality === quality ? "default" : "outline"}
                  size="sm"
                  onClick={() => handlePreferenceUpdate('preferredQuality', quality)}
                  disabled={isUpdating}
                >
                  {quality === 'standard' && 'Standard'}
                  {quality === 'high' && 'High'}
                  {quality === 'lossless' && 'Lossless'}
                </Button>
              ))}
            </div>
          </div>

          {/* Auto Cache Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Auto Cache Favorites</div>
              <div className="text-xs text-muted-foreground">
                Automatically cache songs when you favorite them
              </div>
            </div>
            <Switch
              checked={preferences.autoCache}
              onCheckedChange={(checked) => handlePreferenceUpdate('autoCache', checked)}
              disabled={isUpdating}
            />
          </div>

          {/* Prefetch Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm font-medium">Prefetch Popular Tracks</div>
              <div className="text-xs text-muted-foreground">
                Pre-cache popular tracks for faster streaming
              </div>
            </div>
            <Switch
              checked={preferences.prefetchEnabled}
              onCheckedChange={(checked) => handlePreferenceUpdate('prefetchEnabled', checked)}
              disabled={isUpdating}
            />
          </div>
        </CardContent>
      </Card>

      {/* Cached Favorites List */}
      {cachedFavorites.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Cached Favorites</CardTitle>
            <CardDescription>
              These tracks are available for instant streaming
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {cachedFavorites.slice(0, 10).map((track: any) => (
                <div
                  key={track.id}
                  className="flex items-center justify-between p-2 rounded border"
                >
                  <div className="flex-1">
                    <div className="font-medium text-sm">{track.title}</div>
                    <div className="text-xs text-muted-foreground">
                      {track.artist}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {track.therapeuticGoal && (
                      <Badge variant="secondary" className="text-xs">
                        {track.therapeuticGoal.replace('_', ' ')}
                      </Badge>
                    )}
                    <Download className="h-4 w-4 text-green-500" />
                  </div>
                </div>
              ))}
              {cachedFavorites.length > 10 && (
                <div className="text-center text-sm text-muted-foreground">
                  And {cachedFavorites.length - 10} more cached tracks...
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}