import React from 'react';

// Component that bypasses everything and works with raw HTML
export default function AlwaysVisibleButton() {
  const [showModal, setShowModal] = React.useState(false);
  
  React.useEffect(() => {
    console.log('[ALWAYS VISIBLE] Component mounted successfully!');
  }, []);

  const openFullPageModal = () => {
    console.log('[ALWAYS VISIBLE] Opening full page modal');
    setShowModal(true);
  };

  const closeModal = () => {
    console.log('[ALWAYS VISIBLE] Closing modal');
    setShowModal(false);
  };

  if (showModal) {
    return React.createElement('div', {
      style: {
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0,0,0,0.95)',
        zIndex: 99999,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, React.createElement('div', {
      style: {
        backgroundColor: 'white',
        color: 'black',
        padding: '40px',
        borderRadius: '10px',
        textAlign: 'center'
      }
    }, [
      React.createElement('h1', { key: 'title', style: { fontSize: '24px', marginBottom: '20px' } }, 
        '✅ FULL PAGE PLAYER IS WORKING!'
      ),
      React.createElement('p', { key: 'desc', style: { marginBottom: '20px' } }, 
        'This proves the full-page modal functionality works perfectly.'
      ),
      React.createElement('button', { 
        key: 'btn',
        onClick: closeModal,
        style: {
          padding: '10px 20px',
          backgroundColor: '#007bff',
          color: 'white',
          border: 'none',
          borderRadius: '5px',
          fontSize: '16px',
          cursor: 'pointer'
        }
      }, 'Close')
    ]));
  }

  return React.createElement('button', {
    onClick: openFullPageModal,
    style: {
      position: 'fixed',
      top: '10px',
      right: '10px',
      zIndex: 99999,
      backgroundColor: '#28a745',
      color: 'white',
      border: '2px solid white',
      borderRadius: '5px',
      padding: '12px 20px',
      fontSize: '16px',
      fontWeight: 'bold',
      cursor: 'pointer',
      boxShadow: '0 4px 8px rgba(0,0,0,0.3)'
    }
  }, '🟢 FULL PAGE TEST');
}