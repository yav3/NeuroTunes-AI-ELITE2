import { Play, Pause, Heart } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { Track } from '../lib/api';

interface TrackCardProps {
  track: Track;
}

export default function TrackCard({ track }: TrackCardProps) {
  const { current, isPlaying, play, pause } = useAudio();
  
  const isCurrentTrack = current?.id === Number(track.id);
  const isCurrentlyPlaying = isCurrentTrack && isPlaying;

  const handlePlayPause = async () => {
    if (isCurrentTrack) {
      if (isPlaying) {
        pause();
      } else {
        await play({ ...track, id: Number(track.id) });
      }
    } else {
      await play({ ...track, id: Number(track.id) });
    }
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return '--:--';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className={`p-4 rounded-xl border transition-all hover:bg-gray-800/50 ${
      isCurrentTrack ? 'bg-blue-900/20 border-blue-600' : 'bg-gray-900/50 border-gray-700'
    }`}>
      <div className="flex items-center gap-4">
        {/* Play/Pause Button */}
        <button
          onClick={handlePlayPause}
          className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
            isCurrentlyPlaying 
              ? 'bg-blue-600 hover:bg-blue-700' 
              : 'bg-gray-700 hover:bg-gray-600'
          }`}
        >
          {isCurrentlyPlaying ? (
            <Pause size={20} className="text-white" />
          ) : (
            <Play size={20} className="text-white ml-0.5" />
          )}
        </button>

        {/* Track Info */}
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-white truncate">{track.title}</h3>
          <p className="text-sm text-gray-400 truncate">
            {track.artist || 'Unknown Artist'}
          </p>
          {track.genres && track.genres.length > 0 && (
            <div className="flex gap-1 mt-1">
              {track.genres.slice(0, 2).map((genre, index) => (
                <span
                  key={index}
                  className="px-2 py-0.5 text-xs bg-gray-800 text-gray-300 rounded"
                >
                  {genre}
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Duration & Actions */}
        <div className="flex items-center gap-3">
          <span className="text-sm text-gray-400">
            {formatDuration(track.duration)}
          </span>
          <button className="p-2 rounded-lg hover:bg-gray-700 transition-colors">
            <Heart size={16} className="text-gray-400 hover:text-red-400" />
          </button>
        </div>
      </div>

      {/* Progress Bar for Current Track */}
      {isCurrentTrack && (
        <div className="mt-3 h-1 bg-gray-700 rounded-full overflow-hidden">
          <div 
            className="h-full bg-blue-500 transition-all duration-300"
            style={{ 
              width: current?.duration ? `${(current.duration / (track.duration || 1)) * 100}%` : '0%' 
            }}
          />
        </div>
      )}
    </div>
  );
}