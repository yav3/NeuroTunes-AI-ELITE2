import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Play, Heart, Clock, Music } from 'lucide-react';
import { Track } from '@shared/schema';

interface TracksListProps {
  tracks: Track[];
  onTrackSelect: (index: number) => void;
  currentTrackIndex: number;
  isPlaying: boolean;
  className?: string;
}

export function TracksList({ 
  tracks, 
  onTrackSelect, 
  currentTrackIndex, 
  isPlaying, 
  className = '' 
}: TracksListProps) {
  const getMoodColor = (mood: string | null) => {
    if (!mood) return 'text-calm-primary';
    switch (mood.toLowerCase()) {
      case 'calm': return 'text-calm-primary';
      case 'focused': return 'text-therapeutic-lavender';
      case 'energetic': return 'text-therapeutic-coral';
      case 'peaceful': return 'text-calm-secondary';
      case 'sleepy': return 'text-therapeutic-sage';
      default: return 'text-calm-primary';
    }
  };

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <Card className={`${className} glass-effect border-none shadow-lg`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
            Therapeutic Music Library
          </h2>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {tracks.length} tracks
          </span>
        </div>

        <div className="space-y-2">
          {tracks.map((track, index) => (
            <div
              key={track.id}
              className={`
                flex items-center space-x-4 p-4 rounded-xl transition-all duration-200 cursor-pointer
                ${currentTrackIndex === index 
                  ? 'bg-gradient-to-r from-calm-primary/20 to-calm-secondary/20 border border-calm-primary/30' 
                  : 'hover:bg-gray-50 dark:hover:bg-gray-800/50'
                }
              `}
              onClick={() => onTrackSelect(index)}
            >
              {/* Play Button */}
              <Button
                variant="ghost"
                size="icon"
                className={`
                  w-12 h-12 rounded-full flex-shrink-0
                  ${currentTrackIndex === index && isPlaying
                    ? 'bg-gradient-to-r from-calm-primary to-calm-secondary text-white'
                    : 'text-gray-600 dark:text-gray-400 hover:text-calm-primary'
                  }
                `}
              >
                {currentTrackIndex === index && isPlaying ? (
                  <div className="w-4 h-4 flex items-center justify-center">
                    <div className="flex space-x-1">
                      <div className="w-1 h-4 bg-white rounded-full animate-pulse" />
                      <div className="w-1 h-4 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.2s' }} />
                      <div className="w-1 h-4 bg-white rounded-full animate-pulse" style={{ animationDelay: '0.4s' }} />
                    </div>
                  </div>
                ) : (
                  <Play className="w-5 h-5" />
                )}
              </Button>

              {/* Track Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2 mb-1">
                  <h3 className="font-medium text-gray-900 dark:text-gray-100 truncate">
                    {track.title}
                  </h3>
                  <span className={`text-xs px-2 py-1 rounded-full bg-gray-100 dark:bg-gray-800 ${getMoodColor(track.mood)}`}>
                    {track.mood || 'Unknown'}
                  </span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                  {track.artist}
                </p>
                
                {/* Therapeutic Tags */}
                {track.therapeuticTags && track.therapeuticTags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {track.therapeuticTags.slice(0, 3).map((tag, tagIndex) => (
                      <span 
                        key={tagIndex}
                        className="text-xs px-2 py-0.5 bg-therapeutic-lavender/20 text-therapeutic-lavender rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                    {track.therapeuticTags.length > 3 && (
                      <span className="text-xs text-gray-500 dark:text-gray-400">
                        +{track.therapeuticTags.length - 3} more
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Duration and Actions */}
              <div className="flex items-center space-x-3 flex-shrink-0">
                <div className="flex items-center space-x-1 text-sm text-gray-500 dark:text-gray-400">
                  <Clock className="w-4 h-4" />
                  <span>{formatDuration(track.duration)}</span>
                </div>
                
                <Button variant="ghost" size="icon" className="text-gray-400 hover:text-therapeutic-coral">
                  <Heart className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {tracks.length === 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            <Music className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No tracks available in your library.</p>
            <p className="text-sm mt-2">Upload some therapeutic music to get started.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}