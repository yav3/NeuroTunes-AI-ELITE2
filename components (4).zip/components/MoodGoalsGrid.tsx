import { MoodIcons } from './MoodIcons';

interface MoodGoalsGridProps {
  selectedKey: string;
  onSelect: (key: string) => void;
}

const MOOD_GOALS = [
  { key: 'focus', label: 'Focus' },
  { key: 'relaxation', label: 'Relaxation' },
  { key: 'energy_boost', label: 'Energy Boost' },
  { key: 'nsdr', label: 'NSDR' },
  { key: 'pain_management', label: 'Pain Management' },
  { key: 'cardio_hiit', label: 'Cardio HIIT' },
  { key: 'light_exercise', label: 'Light Exercise' },
  { key: 'walk_warm_up', label: 'Walk Warm-up' },
  { key: 'anxiety_reduction', label: 'Anxiety Relief' },
  { key: 'chill', label: 'Chill' }
];

export default function MoodGoalsGrid({ selectedKey, onSelect }: MoodGoalsGridProps) {
  return (
    <div className="grid grid-cols-2 gap-3 mb-6">
      {MOOD_GOALS.map((goal) => (
        <button
          key={goal.key}
          onClick={() => onSelect(goal.key)}
          className={`
            p-4 rounded-xl border transition-all duration-200 text-left
            ${selectedKey === goal.key
              ? 'border-blue-400/50 shadow-lg shadow-blue-500/20'
              : 'border-white/10 hover:border-white/20'
            }
          `}
          style={{ 
            background: "rgba(28,56,92,0.12)",
            backgroundImage: selectedKey === goal.key 
              ? "radial-gradient(circle at top right, rgba(56,97,251,0.1), transparent 50%)"
              : "radial-gradient(circle at top right, rgba(255,255,255,0.02), transparent 50%)"
          }}
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center p-2">
              {MoodIcons[goal.key as keyof typeof MoodIcons]}
            </div>
            <span className="text-white font-medium">{goal.label}</span>
          </div>
        </button>
      ))}
    </div>
  );
}