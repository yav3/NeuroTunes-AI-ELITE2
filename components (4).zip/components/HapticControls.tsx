import React from 'react';
import { Vibrate, VolumeX } from 'lucide-react';
import { useHapticFeedback } from '../hooks/useHapticFeedback';

interface HapticControlsProps {
  enabled: boolean;
  onToggle: (enabled: boolean) => void;
  intensity?: 'light' | 'medium' | 'heavy';
  onIntensityChange?: (intensity: 'light' | 'medium' | 'heavy') => void;
}

export default function HapticControls({ 
  enabled, 
  onToggle, 
  intensity = 'medium',
  onIntensityChange 
}: HapticControlsProps) {
  const { isSupported, haptic } = useHapticFeedback();

  const handleToggle = () => {
    const newEnabled = !enabled;
    onToggle(newEnabled);
    
    // Provide haptic feedback when toggling
    if (newEnabled && isSupported) {
      haptic('success');
    }
  };

  const handleIntensityChange = (newIntensity: 'light' | 'medium' | 'heavy') => {
    onIntensityChange?.(newIntensity);
    
    // Provide haptic feedback at the selected intensity
    if (enabled && isSupported) {
      haptic('tap', { intensity: newIntensity });
    }
  };

  const testHaptic = () => {
    if (enabled && isSupported) {
      haptic('playPause', { intensity });
    }
  };

  if (!isSupported) {
    return null; // Don't show controls if haptic feedback isn't supported
  }

  return (
    <div className="bg-slate-800/50 rounded-lg p-4 border border-slate-700/50">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {enabled ? (
            <Vibrate size={16} className="text-blue-400" />
          ) : (
            <VolumeX size={16} className="text-gray-500" />
          )}
          <span className="text-sm font-medium text-white">
            Haptic Feedback
          </span>
        </div>
        
        <button
          onClick={handleToggle}
          className={`relative w-11 h-6 rounded-full transition-colors ${
            enabled ? 'bg-blue-600' : 'bg-gray-600'
          }`}
          aria-label={enabled ? 'Disable haptic feedback' : 'Enable haptic feedback'}
        >
          <div
            className={`absolute w-4 h-4 bg-white rounded-full transition-transform top-1 ${
              enabled ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
        </button>
      </div>

      {enabled && (
        <div className="space-y-3">
          <div>
            <label className="text-xs text-gray-400 mb-2 block">
              Intensity Level
            </label>
            <div className="flex gap-1">
              {(['light', 'medium', 'heavy'] as const).map((level) => (
                <button
                  key={level}
                  onClick={() => handleIntensityChange(level)}
                  className={`flex-1 py-2 px-3 rounded text-xs font-medium transition-colors ${
                    intensity === level
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-700 text-gray-300 hover:bg-slate-600'
                  }`}
                >
                  {level.charAt(0).toUpperCase() + level.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={testHaptic}
            className="w-full py-2 px-4 bg-slate-700 hover:bg-slate-600 text-white text-sm rounded transition-colors"
          >
            Test Haptic Feedback
          </button>

          <div className="text-xs text-gray-400">
            Enhances music experience with tactile feedback on beats and interactions
          </div>
        </div>
      )}
    </div>
  );
}