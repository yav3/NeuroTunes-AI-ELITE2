import { useLocation, useNavigate } from 'react-router-dom';
import { Home, Heart, Radio, User, Upload } from 'lucide-react';

const tabs = [
  { to: '/', label: 'Home', icon: Home },
  { to: '/mood', label: 'Emotions', icon: Heart },
  { to: '/ai', label: 'AI DJ', icon: Radio },
  { to: '/upload', label: 'Upload', icon: Upload },
  { to: '/profile', label: 'Profile', icon: User },
];

export default function BottomTabs() {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-xl border-t border-slate-700/50 z-50">
      <div className="max-w-2xl mx-auto grid grid-cols-5 h-20">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = location.pathname === tab.to;
          
          return (
            <button
              key={tab.to}
              onClick={() => navigate(tab.to)}
              className={`flex flex-col items-center justify-center py-3 transition-all duration-200 ${
                isActive 
                  ? 'text-blue-400' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Icon size={22} className="mb-1.5" strokeWidth={isActive ? 2 : 1.5} />
              <span className="text-xs font-medium tracking-wide">{tab.label}</span>
            </button>
          );
        })}
      </div>
      <div className="h-safe-area-inset-bottom bg-slate-900"></div>
    </nav>
  );
}