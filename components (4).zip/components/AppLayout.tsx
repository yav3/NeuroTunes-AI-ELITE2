import { ReactNode } from "react";

export default function AppLayout({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-[100svh] flex flex-col bg-gradient-to-br from-[#0c1929] to-[#0a2a7a] text-white">
      {/* Scrollable content area */}
      <main
        className="
          flex-1 overflow-y-auto
          px-4 pb-28   
        "
      >
        {children}
      </main>

      {/* Fixed bottom nav */}
      <nav
        className="
          fixed inset-x-0 bottom-0 z-30
          h-16 px-6
          bg-[#0B223A]/95 backdrop-blur
          border-t border-white/10
          flex items-center justify-between
          [padding-bottom:env(safe-area-inset-bottom)]
        "
      >
        {/* Navigation buttons will be passed as children when needed */}
      </nav>
    </div>
  );
}