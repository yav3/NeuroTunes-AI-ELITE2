import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Smartphone, 
  Watch, 
  Heart, 
  Activity,
  Zap,
  CheckCircle,
  AlertCircle,
  Loader2
} from "lucide-react";

interface HealthKitData {
  heartRate?: number;
  heartRateVariability?: number;
  stressLevel?: number;
  oxygenSaturation?: number;
  skinTemperature?: number;
  steps?: number;
  calories?: number;
  sleepHours?: number;
  restingHeartRate?: number;
  bloodPressureSystemic?: number;
  bloodPressureDiastolic?: number;
  respiratoryRate?: number;
  bodyTemperature?: number;
}

interface HealthKitPermissions {
  heartRate: boolean;
  heartRateVariability: boolean;
  oxygenSaturation: boolean;
  bodyTemperature: boolean;
  steps: boolean;
  sleepAnalysis: boolean;
  workouts: boolean;
  mindfulSessions: boolean;
  bloodPressure: boolean;
  respiratoryRate: boolean;
}

export default function HealthKitIntegration() {
  const [platform, setPlatform] = useState<'ios' | 'android' | null>(null);
  const [simulatedData, setSimulatedData] = useState<HealthKitData>({
    heartRate: 72,
    heartRateVariability: 45,
    stressLevel: 35,
    oxygenSaturation: 98,
    steps: 8234,
    sleepHours: 7.5,
    restingHeartRate: 65
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Detect platform
  useEffect(() => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (userAgent.includes('iphone') || userAgent.includes('ipad') || userAgent.includes('mac')) {
      setPlatform('ios');
    } else if (userAgent.includes('android')) {
      setPlatform('android');
    }
  }, []);

  // Get health kit status
  const { data: healthKitStatus, isLoading: statusLoading } = useQuery({
    queryKey: [`/api/health-kit/status/${platform}`],
    enabled: !!platform,
  });

  // Register health kit mutation
  const registerMutation = useMutation({
    mutationFn: async (permissions: HealthKitPermissions) => {
      const endpoint = platform === 'ios' ? '/api/health-kit/ios/register' : '/api/health-kit/android/register';
      return await apiRequest("POST", endpoint, { permissions });
    },
    onSuccess: () => {
      toast({
        title: "Health Kit Connected",
        description: `${platform === 'ios' ? 'iOS Health Kit' : 'Android Health Connect'} connected successfully`,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/health-kit/status/${platform}`] });
    },
    onError: () => {
      toast({
        title: "Connection Failed",
        description: "Could not connect to health platform",
        variant: "destructive",
      });
    },
  });

  // Sync health data mutation
  const syncMutation = useMutation({
    mutationFn: async (healthData: HealthKitData) => {
      const endpoint = platform === 'ios' ? '/api/health-kit/ios/sync' : '/api/health-kit/android/sync';
      return await apiRequest("POST", endpoint, { healthData });
    },
    onSuccess: (data) => {
      toast({
        title: "Health Data Synced",
        description: `Mood prediction: ${data.moodPrediction?.predictedMood || 'neutral'}`,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/health-kit/status/${platform}`] });
    },
    onError: () => {
      toast({
        title: "Sync Failed",
        description: "Could not sync health data",
        variant: "destructive",
      });
    },
  });

  const handleConnect = () => {
    const defaultPermissions: HealthKitPermissions = {
      heartRate: true,
      heartRateVariability: true,
      oxygenSaturation: true,
      bodyTemperature: true,
      steps: true,
      sleepAnalysis: true,
      workouts: true,
      mindfulSessions: true,
      bloodPressure: true,
      respiratoryRate: true
    };

    registerMutation.mutate(defaultPermissions);
  };

  const handleSyncData = () => {
    // Simulate real health data or use actual HealthKit/HealthConnect API
    const randomizedData: HealthKitData = {
      heartRate: simulatedData.heartRate + Math.floor(Math.random() * 10 - 5),
      heartRateVariability: simulatedData.heartRateVariability + Math.floor(Math.random() * 10 - 5),
      stressLevel: Math.max(0, Math.min(100, simulatedData.stressLevel + Math.floor(Math.random() * 20 - 10))),
      oxygenSaturation: Math.max(95, Math.min(100, simulatedData.oxygenSaturation)),
      steps: simulatedData.steps + Math.floor(Math.random() * 1000),
      sleepHours: Math.max(4, Math.min(12, simulatedData.sleepHours + (Math.random() * 2 - 1))),
      restingHeartRate: simulatedData.restingHeartRate + Math.floor(Math.random() * 6 - 3)
    };

    setSimulatedData(randomizedData);
    syncMutation.mutate(randomizedData);
  };

  if (!platform) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
            <p className="text-muted-foreground">Platform detection in progress...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Platform Integration Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            {platform === 'ios' ? <Smartphone className="w-5 h-5" /> : <Watch className="w-5 h-5" />}
            <span>{platform === 'ios' ? 'iOS Health Kit' : 'Android Health Connect'}</span>
            {healthKitStatus?.connected ? (
              <Badge variant="default" className="bg-green-500">
                <CheckCircle className="w-3 h-3 mr-1" />
                Connected
              </Badge>
            ) : (
              <Badge variant="secondary">
                <AlertCircle className="w-3 h-3 mr-1" />
                Not Connected
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {platform === 'ios' 
                ? 'Connect to iOS Health Kit for real-time biometric monitoring and mood prediction.'
                : 'Connect to Android Health Connect for comprehensive health data integration.'
              }
            </p>

            {!healthKitStatus?.connected ? (
              <Button 
                onClick={handleConnect}
                disabled={registerMutation.isPending}
                className="w-full"
              >
                {registerMutation.isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Connect {platform === 'ios' ? 'Health Kit' : 'Health Connect'}
                  </>
                )}
              </Button>
            ) : (
              <div className="space-y-3">
                <Button 
                  onClick={handleSyncData}
                  disabled={syncMutation.isPending}
                  className="w-full"
                >
                  {syncMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Syncing...
                    </>
                  ) : (
                    <>
                      <Activity className="w-4 h-4 mr-2" />
                      Sync Health Data
                    </>
                  )}
                </Button>

                {/* Current Health Metrics */}
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-muted/50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Heart className="w-4 h-4 text-red-500" />
                      <span className="text-sm font-medium">Heart Rate</span>
                    </div>
                    <p className="text-lg font-bold">{simulatedData.heartRate} BPM</p>
                  </div>

                  <div className="bg-muted/50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Activity className="w-4 h-4 text-blue-500" />
                      <span className="text-sm font-medium">HRV</span>
                    </div>
                    <p className="text-lg font-bold">{simulatedData.heartRateVariability} ms</p>
                  </div>

                  <div className="bg-muted/50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-amber-500" />
                      <span className="text-sm font-medium">Stress Level</span>
                    </div>
                    <p className="text-lg font-bold">{simulatedData.stressLevel}%</p>
                  </div>

                  <div className="bg-muted/50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Activity className="w-4 h-4 text-green-500" />
                      <span className="text-sm font-medium">Steps</span>
                    </div>
                    <p className="text-lg font-bold">{simulatedData.steps?.toLocaleString()}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Health Data Permissions */}
      {healthKitStatus?.connected && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span>Health Data Permissions</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              {healthKitStatus.healthKitPermissions?.map((permission: string) => (
                <Badge key={permission} variant="outline" className="justify-start">
                  <CheckCircle className="w-3 h-3 mr-1 text-green-500" />
                  {permission.replace(/([A-Z])/g, ' $1').replace(/^./, (str: string) => str.toUpperCase())}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}