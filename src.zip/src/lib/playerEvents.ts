// Cache bust: 2025-08-22-17:40 - FORCE RELOAD
export const openPlayer = () => {
  console.log('[EVENT BUS] openPlayer called - dispatching event');
  window.dispatchEvent(new CustomEvent("neurotunes:open-player"));
};
export const closePlayer = () => {
  console.log('[EVENT BUS] closePlayer called - dispatching event');
  window.dispatchEvent(new CustomEvent("neurotunes:close-player"));
};