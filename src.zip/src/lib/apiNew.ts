export type Track = {
  id: number;
  title: string;
  artist?: string;
  duration?: number;
  streamKey?: string;
  file?: string;
  coverUrl?: string;
  tags?: string[];
  therapeuticTags?: string[];
  mood?: string;
  valence?: number;
  energy?: number;
};

const BASE = '';

export async function fetchTracks(params: Record<string,string|number> = {}) {
  const q = new URLSearchParams(params as Record<string,string>).toString();
  const res = await fetch(`${BASE}/api/tracks${q ? `?${q}` : ''}`);
  if (!res.ok) throw new Error('Failed to load tracks');
  const data = await res.json();
  // Handle both array format and catalog format
  if (Array.isArray(data)) {
    return data as Track[];
  } else if (data.catalog && Array.isArray(data.catalog)) {
    return data.catalog as Track[];
  }
  return [] as Track[];
}

export function trackStreamUrl(t: Track) {
  // Priority: Use title for better local file matching, then fallback to ID
  if (t.title)     return `/api/stream/${encodeURIComponent(t.title)}`;
  if (t.streamKey) return `/api/stream/${encodeURIComponent(t.streamKey)}`;
  if (t.file)      return `/api/stream/${encodeURIComponent(t.file)}`;
  if (t.id)        return `/api/stream/${encodeURIComponent(t.id)}`;
  return `/api/stream/unknown`;
}