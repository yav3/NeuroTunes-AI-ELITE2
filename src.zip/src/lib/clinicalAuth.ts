// HIPAA-compliant clinical authentication helpers for NeuroTunes AI

export interface ClinicalUser {
  id: string;
  sub: string;
  clinicalId: string;
  role: 'clinician' | 'patient' | 'admin';
  authenticated: boolean;
  sessionExpires?: number;
}

export class ClinicalAuthService {
  private static instance: ClinicalAuthService;

  public static getInstance(): ClinicalAuthService {
    if (!ClinicalAuthService.instance) {
      ClinicalAuthService.instance = new ClinicalAuthService();
    }
    return ClinicalAuthService.instance;
  }

  // Clinical login - for demonstration/development
  async clinicalLogin(clinicalId: string, role: 'clinician' | 'patient' | 'admin' = 'clinician'): Promise<ClinicalUser> {
    try {
      const response = await fetch('/auth/clinical-login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ clinicalId, role })
      });

      if (!response.ok) {
        throw new Error('Clinical login failed');
      }

      const data = await response.json();
      console.log('🏥 Clinical authentication successful:', data.user.clinicalId);
      return data.user;
    } catch (error) {
      console.error('Clinical login error:', error);
      throw error;
    }
  }

  // Check current clinical session
  async checkSession(): Promise<ClinicalUser | null> {
    try {
      const response = await fetch('/api/auth/user', {
        credentials: 'include'
      });

      if (!response.ok) {
        return null;
      }

      const user = await response.json();
      return user;
    } catch (error) {
      console.error('Session check error:', error);
      return null;
    }
  }

  // Clinical logout
  async logout(): Promise<void> {
    try {
      const response = await fetch('/auth/logout', {
        method: 'POST',
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Logout failed');
      }

      console.log('🏥 Clinical logout successful');
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  }

  // Make authenticated API calls
  async authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
    const response = await fetch(url, {
      ...options,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        ...options.headers
      }
    });

    if (response.status === 401) {
      // Session expired, redirect to login
      console.warn('Clinical session expired');
      window.location.href = '/login';
      throw new Error('Session expired');
    }

    return response;
  }
}

// Export singleton instance
export const clinicalAuth = ClinicalAuthService.getInstance();

// Helper hook for React components (if using React Query)
export function useClinicalAuth() {
  const auth = ClinicalAuthService.getInstance();
  
  return {
    login: auth.clinicalLogin.bind(auth),
    logout: auth.logout.bind(auth),
    checkSession: auth.checkSession.bind(auth),
    authenticatedFetch: auth.authenticatedFetch.bind(auth)
  };
}