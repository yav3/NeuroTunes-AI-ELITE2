// Album art from MP3s - client-side parsing with caching
import { parseBlob } from 'music-metadata-browser';

const coverCache = new Map<string, string>();

export async function getCoverFromMp3(publicUrl: string): Promise<string> {
  if (coverCache.has(publicUrl)) {
    return coverCache.get(publicUrl)!;
  }

  try {
    const res = await fetch(publicUrl, { method: 'GET' });
    const blob = await res.blob();
    const { common } = await parseBlob(blob);
    const pic = common.picture?.[0];
    
    if (!pic) {
      coverCache.set(publicUrl, '');
      return '';
    }
    
    const url = URL.createObjectURL(
      new Blob([pic.data], { type: pic.format || 'image/jpeg' })
    );
    
    coverCache.set(publicUrl, url);
    return url;
  } catch (error) {
    console.warn('Failed to extract cover art:', error);
    coverCache.set(publicUrl, '');
    return '';
  }
}

export function clearCoverCache(): void {
  // Clean up blob URLs to prevent memory leaks
  for (const [, url] of coverCache) {
    if (url) {
      URL.revokeObjectURL(url);
    }
  }
  coverCache.clear();
}

// Preload cover art for a batch of tracks
export async function preloadCovers(urls: string[], maxConcurrent = 3): Promise<void> {
  const chunks = [];
  for (let i = 0; i < urls.length; i += maxConcurrent) {
    chunks.push(urls.slice(i, i + maxConcurrent));
  }

  for (const chunk of chunks) {
    await Promise.all(chunk.map(url => getCoverFromMp3(url).catch(() => '')));
  }
}