import { Outlet, Route, Routes } from 'react-router-dom';
import BottomTabs from './components/BottomTabs';
import HomePage from './pages/HomePage';
import MoodPage from './pages/MoodPage';
import AIDJPageSimple from './pages/AIDJPageSimple';
import Profile from './pages/profile';
import { useAudio } from './context/AudioContext';

function Layout() {
  const { current, isPlaying, currentTime, duration, error, toggle, seek } = useAudio();

  const pct = duration > 0 ? Math.min(100, Math.max(0, (currentTime / duration) * 100)) : 0;

  return (
    <div className="min-h-screen max-w-2xl mx-auto px-4 pt-4 pb-24 bg-black text-white">
      <header className="mb-6">
        <h1 className="text-3xl font-semibold">NeuroTunes AI+</h1>

        <div className="text-xs text-white/40 mt-2">v3.0 — bottom tabs, brand blues, wired APIs</div>
      </header>

      {error && (
        <div className="mb-3 p-3 rounded-lg bg-red-500/20 border border-red-500/30 text-sm">
          {error}
        </div>
      )}

      <Outlet />

      {/* Mini player (sticky above tabs) */}
      {current && (
        <div className="fixed left-0 right-0 bottom-16 md:bottom-16 z-40">
          <div className="max-w-2xl mx-auto px-4">
            <div className="rounded-xl bg-black/95 backdrop-blur-xl border border-white/10 p-3">
              <div className="flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-sm font-medium truncate">{current.title}</div>
                  <div className="text-xs text-white/60 truncate">{current.artist ?? 'Unknown artist'}</div>
                </div>
                <button
                  onClick={toggle}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-sm"
                >
                  {isPlaying ? 'Pause' : 'Play'}
                </button>
              </div>
              <div className="mt-2 h-2 bg-white/10 rounded">
                <div
                  className="h-2 bg-blue-500 rounded"
                  style={{ width: `${pct}%` }}
                  aria-label="progress"
                />
              </div>
              <div className="mt-2 flex justify-between text-xs text-white/60">
                <span>{Math.floor(currentTime)}s</span>
                <span>{Number.isFinite(duration) && duration > 0 ? `${Math.floor(duration)}s` : '—'}</span>
              </div>
              <input
                className="mt-2 w-full"
                type="range"
                min={0}
                max={Number.isFinite(duration) && duration > 0 ? Math.floor(duration) : 100}
                value={Math.floor(currentTime)}
                onChange={e => seek(Number(e.target.value))}
              />
            </div>
          </div>
        </div>
      )}

      <BottomTabs />
    </div>
  );
}

export default function AppWithReactRouter() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="/mood" element={<MoodPage />} />
        <Route path="/ai" element={<AIDJPageSimple />} />
        <Route path="/profile" element={<Profile />} />
      </Route>
    </Routes>
  );
}