import React, { useState } from 'react';
import { Outlet, Route, Routes, Link, useLocation } from 'react-router-dom';
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { StableAudioProvider } from './context/StableAudioContext';
import HomePageRefresh from './pages/HomePageRefresh';
import EmotionsPageNew from './pages/EmotionsPageNew';
import AIDJPageRefresh from './pages/AIDJPageRefresh';
import TracksDemo from './pages/TracksDemo';
import UploadPage from './pages/UploadPage';
import Profile from './pages/profile';
import FullPagePlayer from './components/FullPagePlayer';
import PersistentMusicPlayer from './components/PersistentMusicPlayer';

function Layout() {
  const location = useLocation();
  
  return (
    <div className="min-h-[100svh] flex flex-col bg-gradient-to-br from-[#0c1929] to-[#0a2a7a] text-white">
      {/* Scrollable content area */}
      <main className="flex-1 overflow-y-auto px-4 pb-20">
        <Outlet />
      </main>

      {/* Bottom navigation tabs */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-slate-900/90 backdrop-blur-md border-t border-slate-700/50">
        <div className="max-w-2xl mx-auto px-4 py-3">
          <div className="flex justify-between">
            <Link to="/" className={`flex flex-col items-center text-xs transition-colors ${
              location.pathname === '/' ? 'text-blue-400' : 'text-slate-400 hover:text-blue-400'
            }`}>
              <span className="text-lg font-bold">H</span>
              <span>Home</span>
            </Link>
            <Link to="/ai-dj" className={`flex flex-col items-center text-xs transition-colors ${
              location.pathname === '/ai-dj' ? 'text-blue-400' : 'text-slate-400 hover:text-blue-400'
            }`}>
              <span className="text-lg font-bold">DJ</span>
              <span>AI DJ</span>
            </Link>
            <Link to="/profile" className={`flex flex-col items-center text-xs transition-colors ${
              location.pathname === '/profile' ? 'text-blue-400' : 'text-slate-400 hover:text-blue-400'
            }`}>
              <span className="text-lg font-bold">P</span>
              <span>Profile</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <StableAudioProvider>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<HomePageRefresh />} />
            <Route path="ai-dj" element={<AIDJPageRefresh />} />
            <Route path="upload" element={<UploadPage />} />
            <Route path="profile" element={<Profile />} />
          </Route>
          <Route path="/player" element={<FullPagePlayer />} />
        </Routes>
        <PersistentMusicPlayer />
      </StableAudioProvider>
    </QueryClientProvider>
  );
}
