import { useState, useEffect } from 'react';

interface Track {
  id: number;
  title: string;
  artist: string;
  audioUrl?: string;
  mood?: string;
  therapeuticTags?: string[];
}

export default function AppTest() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    console.log('App is mounting...');
    
    fetch('/api/tracks')
      .then(res => {
        console.log('Response status:', res.status);
        return res.json();
      })
      .then(data => {
        console.log('Data received:', data);
        const trackCount = data.catalog ? data.catalog.length : 0;
        console.log('Loaded tracks:', trackCount);
        setTracks(data.catalog || []);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading tracks:', err);
        setError('Failed to load tracks');
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '18px'
      }}>
        Loading NeuroTunes...
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        color: 'white',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        fontSize: '18px',
        gap: '16px'
      }}>
        <div>Error: {error}</div>
        <button 
          onClick={() => window.location.reload()}
          style={{
            padding: '12px 24px',
            background: '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer'
          }}
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      color: 'white',
      overflow: 'auto',
      padding: '20px'
    }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <h1 style={{ fontSize: '32px', fontWeight: '600', marginBottom: '16px' }}>
          NeuroTunes AI Clinical Companion
        </h1>

        
        <div style={{ marginBottom: '24px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '16px' }}>Music Library</h2>
          <p style={{ color: '#a5b4fc', marginBottom: '16px' }}>
            {tracks.length} tracks loaded
          </p>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
          gap: '16px'
        }}>
          {tracks.slice(0, 12).map(track => (
            <div
              key={track.id}
              style={{
                background: 'rgba(12, 25, 41, 0.7)',
                border: '1px solid rgba(59, 130, 246, 0.2)',
                borderRadius: '12px',
                padding: '16px',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              <h3 style={{ fontSize: '16px', fontWeight: '500', marginBottom: '8px' }}>
                {track.title}
              </h3>
              <p style={{ color: '#a5b4fc', fontSize: '14px', marginBottom: '8px' }}>
                {track.artist || 'Unknown Artist'}
              </p>
              {track.mood && (
                <div style={{
                  display: 'inline-block',
                  background: 'rgba(59, 130, 246, 0.2)',
                  color: '#3b82f6',
                  padding: '4px 8px',
                  borderRadius: '6px',
                  fontSize: '12px'
                }}>
                  {track.mood}
                </div>
              )}
            </div>
          ))}
        </div>

        {tracks.length > 12 && (
          <div style={{ textAlign: 'center', marginTop: '32px' }}>
            <p style={{ color: '#a5b4fc' }}>
              And {tracks.length - 12} more tracks...
            </p>
          </div>
        )}
      </div>
    </div>
  );
}