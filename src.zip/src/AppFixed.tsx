import { useState, useEffect } from 'react';

// Simple track interface
interface Track {
  id: number;
  title: string;
  artist: string;
  audioUrl: string;
  mood?: string;
  therapeuticTags?: string[];
}

// Simple audio context
const useSimpleAudio = () => {
  const [current, setCurrent] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  const play = (track: Track) => {
    setCurrent(track);
    setIsPlaying(true);
  };

  const toggle = () => {
    setIsPlaying(!isPlaying);
  };

  return { current, isPlaying, currentTime, duration, play, toggle };
};

// Album Art Component
function AlbumArt({ track, size = 48 }: { track: { id: number; title: string }; size?: number }) {
  return (
    <div 
      className="bg-gradient-to-br from-blue-800 to-blue-900 rounded-lg flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      <svg width={size/2} height={size/2} viewBox="0 0 24 24" fill="currentColor" className="text-blue-300">
        <path d="M12 3V13.55C11.41 13.21 10.73 13 10 13C7.79 13 6 14.79 6 17S7.79 21 10 21 14 19.21 14 17V7H18V3H12Z"/>
      </svg>
    </div>
  );
}

// Track Card Component
function TrackCard({ track, onPlay }: { track: Track; onPlay: (track: Track) => void }) {
  return (
    <div 
      className="bg-slate-800 rounded-xl p-4 hover:bg-slate-700 transition-colors cursor-pointer"
      onClick={() => onPlay(track)}
    >
      <div className="flex items-center gap-3">
        <AlbumArt track={track} size={56} />
        <div className="min-w-0 flex-1">
          <div className="font-medium text-white truncate">{track.title}</div>
          <div className="text-slate-400 text-sm truncate">{track.artist}</div>
          {track.mood && (
            <div className="text-blue-400 text-xs mt-1">{track.mood}</div>
          )}
        </div>
        <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" className="text-white ml-0.5">
            <path d="M3 1v10l6-5-6-5z"/>
          </svg>
        </div>
      </div>
    </div>
  );
}

// Main App Component
export default function AppFixed() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'home' | 'mood' | 'aidj' | 'profile'>('home');
  const audio = useSimpleAudio();

  // Load tracks
  useEffect(() => {
    fetch('/api/tracks')
      .then(res => res.json())
      .then(data => {
        setTracks(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load tracks:', err);
        setLoading(false);
      });
  }, []);

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const progressPercent = audio.duration > 0 ? (audio.currentTime / audio.duration) * 100 : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-white">
      {/* Header */}
      <header className="px-4 pt-6 pb-4 max-w-2xl mx-auto">
        <h1 className="text-2xl font-semibold">NeuroTunes AI</h1>

      </header>

      {/* Main Content */}
      <main className="px-4 pb-32 max-w-2xl mx-auto">
        {tab === 'home' && (
          <div>
            <h2 className="text-xl font-medium mb-4">Your Music Library</h2>
            {loading ? (
              <div className="text-center py-8">
                <div className="text-slate-400">Loading your music...</div>
              </div>
            ) : (
              <div className="space-y-3">
                {tracks.slice(0, 20).map(track => (
                  <TrackCard key={track.id} track={track} onPlay={audio.play} />
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'mood' && (
          <div>
            <h2 className="text-xl font-medium mb-4">Mood Selection</h2>
            <div className="grid grid-cols-2 gap-3">
              {['Focus', 'Relax', 'Energy', 'Sleep'].map(mood => (
                <button key={mood} className="bg-slate-800 rounded-xl p-4 text-center hover:bg-slate-700 transition-colors">
                  <div className="font-medium">{mood}</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {tab === 'aidj' && (
          <div>
            <h2 className="text-xl font-medium mb-4">AI DJ</h2>
            <div className="bg-slate-800 rounded-xl p-6 text-center">
              <div className="text-slate-400 mb-4">Create personalized playlists</div>
              <button className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg font-medium transition-colors">
                Generate Playlist
              </button>
            </div>
          </div>
        )}

        {tab === 'profile' && (
          <div>
            <h2 className="text-xl font-medium mb-4">Profile</h2>
            <div className="bg-slate-800 rounded-xl p-6">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" className="text-white">
                    <path d="M12 2a5 5 0 100 10 5 5 0 000-10zm0 14c-5.523 0-10 2.477-10 5.5V24h20v-2.5c0-3.023-4.477-5.5-10-5.5z"/>
                  </svg>
                </div>
                <div className="font-medium">Neural Music User</div>
                <div className="text-slate-400 text-sm">Therapeutic Music Companion</div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Music Player */}
      {audio.current && (
        <div className="fixed bottom-16 left-0 right-0 bg-slate-900/95 backdrop-blur border-t border-slate-700 p-4">
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center gap-3">
              <AlbumArt track={audio.current} size={48} />
              <div className="min-w-0 flex-1">
                <div className="font-medium truncate">{audio.current.title}</div>
                <div className="text-slate-400 text-sm truncate">{audio.current.artist}</div>
              </div>

              {/* Control Buttons */}
              <div className="flex items-center gap-2">
                {/* Heart */}
                <button className="w-8 h-8 rounded-lg bg-slate-700 hover:bg-slate-600 flex items-center justify-center">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-slate-300">
                    <path d="M7 11.5L3 8.5C1.5 7.2 1.5 5 3 3.8C4.5 2.5 6.5 3 7 4C7.5 3 9.5 2.5 11 3.8C12.5 5 12.5 7.2 11 8.5L7 11.5Z"/>
                  </svg>
                </button>

                {/* Play/Pause */}
                <button 
                  onClick={audio.toggle}
                  className="w-10 h-10 rounded-full bg-blue-600 hover:bg-blue-700 flex items-center justify-center"
                >
                  {audio.isPlaying ? (
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" className="text-white">
                      <rect x="4" y="2" width="2" height="12" rx="1"/>
                      <rect x="10" y="2" width="2" height="12" rx="1"/>
                    </svg>
                  ) : (
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" className="text-white ml-0.5">
                      <path d="M4 2v12l8-6-8-6z"/>
                    </svg>
                  )}
                </button>

                {/* Thumbs Down */}
                <button className="w-8 h-8 rounded-lg bg-slate-700 hover:bg-slate-600 flex items-center justify-center">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-slate-300">
                    <path d="M7 2.5V6H3.5C2.7 6 2 6.7 2 7.5V9.5C2 10.3 2.7 11 3.5 11H9C9.8 11 10.5 10.3 10.5 9.5V7.5L9 2.5H7Z"/>
                  </svg>
                </button>

                {/* Spatial Audio */}
                <button className="w-8 h-8 rounded-lg bg-slate-700 hover:bg-slate-600 flex items-center justify-center">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-slate-300">
                    <circle cx="7" cy="7" r="2"/>
                    <circle cx="7" cy="7" r="4" strokeDasharray="2 2"/>
                    <circle cx="7" cy="7" r="6" strokeDasharray="3 3"/>
                  </svg>
                </button>

                {/* Lightning/Boost */}
                <button className="w-8 h-8 rounded-lg bg-slate-700 hover:bg-slate-600 flex items-center justify-center">
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor" className="text-slate-300">
                    <path d="M8 1L3 7H6L5 13L10 7H7L8 1Z"/>
                  </svg>
                </button>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="mt-3">
              <div className="h-1 bg-slate-700 rounded-full overflow-hidden">
                <div 
                  className="h-1 bg-blue-500 rounded-full transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <div className="mt-1 flex justify-between text-xs text-slate-400">
                <span>{formatTime(audio.currentTime)}</span>
                <span>{formatTime(audio.duration)}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 inset-x-0 bg-slate-900/90 backdrop-blur border-t border-slate-700">
        <div className="max-w-2xl mx-auto grid grid-cols-4 text-center">
          {[
            { key: 'home', icon: 'M10 2L3 8v10h4v-6h6v6h4V8l-7-6z', label: 'Home' },
            { key: 'mood', icon: 'M10 18s-8-5.582-8-10c0-3.037 2.463-5.5 5.5-5.5C9.5 2.5 10 4 10 4s.5-1.5 2.5-1.5C15.537 2.5 18 4.963 18 8c0 4.418-8 10-8 10z', label: 'Mood' },
            { key: 'aidj', icon: 'M10 2a8 8 0 100 16 8 8 0 000-16zm0 12a4 4 0 110-8 4 4 0 010 8z', label: 'AI DJ' },
            { key: 'profile', icon: 'M10 2a4 4 0 100 8 4 4 0 000-8zM4 16c0-3.314 2.686-6 6-6s6 2.686 6 6v2H4v-2z', label: 'Profile' }
          ].map(({ key, icon }) => (
            <button 
              key={key}
              onClick={() => setTab(key as any)}
              className={`py-3 flex items-center justify-center ${tab === key ? 'text-blue-400' : 'text-slate-400'}`}
            >
              <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor">
                <path d={icon}/>
              </svg>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}