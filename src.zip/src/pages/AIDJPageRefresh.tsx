import React, { useState, useEffect } from 'react';
import { Track } from '../lib/apiNew';
import { useStableAudio } from '../context/StableAudioContext';



export default function AIDJPageRefresh() {
  const { play, setQueue } = useStableAudio();
  const [selectedTherapeutic, setSelectedTherapeutic] = useState<string>('');
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);

  const therapeuticGoals = [
    { 
      id: 'focus', 
      name: 'Focus',
      description: 'Concentration and mental clarity',
      albumArt: '/api/art/Battle%20Song%20Edm%20Focus'
    },
    { 
      id: 'mood_boost', 
      name: 'Mood Boost',
      description: 'Emotional enhancement and positivity',
      albumArt: '/api/art/Beautiful%20Babe'
    },
    { 
      id: 'relaxation', 
      name: 'Relaxation',
      description: 'Stress relief and calm',
      albumArt: '/api/art/Breathe%20through%20It'
    },
    { 
      id: 'meditation', 
      name: 'Meditation & Pain Management',
      description: 'Mindfulness and inner peace',
      albumArt: '/api/art/Ethereal%20Composition%20Lumie%20re%20Suspendue'
    },
    { 
      id: 'energy_boost', 
      name: 'Energy Boost',
      description: 'Vitality and motivation',
      albumArt: '/api/art/Beast%20Mode'
    }
  ];

  // Load tracks when therapeutic goal is selected
  useEffect(() => {
    if (!selectedTherapeutic) {
      setTracks([]);
      return;
    }

    const loadTracks = async () => {
      setLoading(true);
      try {
        console.log(`[AI DJ] Loading tracks for goal: ${selectedTherapeutic}`);
        const response = await fetch(`/api/tracks/mood/${selectedTherapeutic}`);
        if (response.ok) {
          const trackData = await response.json();
          console.log(`[AI DJ] Received ${trackData.length} tracks for ${selectedTherapeutic}`);
          setTracks(trackData.slice(0, 20)); // Show first 20 tracks
        } else {
          console.error(`[AI DJ] Failed to fetch tracks for ${selectedTherapeutic}:`, response.status);
        }
      } catch (error) {
        console.error('Failed to load tracks:', error);
      } finally {
        setLoading(false);
      }
    };

    loadTracks();
  }, [selectedTherapeutic]);

  const handlePlay = async (track: Track) => {
    // When playing a track from AI DJ, set up the queue for continuous play
    const trackIndex = tracks.findIndex(t => t.id === track.id);
    if (trackIndex !== -1) {
      setQueue(tracks, trackIndex);
    } else {
      await play(track);
    }
  };

  return (
    <div className="w-full space-y-3" data-cache="bust-descriptions-removed-1755634666">
      {/* Header - Only show on AI DJ page */}
      <header className="mb-6 pt-4">
        <h1 className="text-2xl font-semibold text-white tracking-tight">Music & Emotion</h1>
        <p className="text-blue-200/80 text-sm mt-1">NeuroTunes</p>
      </header>

      <div className="flex items-center justify-between">
        <div>
          <div className="text-xl font-medium text-white">AI DJ</div>
          <div className="text-sm text-blue-200 mt-1" style={{ fontSize: '14pt' }}>
            Choose Your Therapeutic Goal
          </div>
        </div>
        {selectedTherapeutic && (
          <button
            onClick={() => setSelectedTherapeutic('')}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors"
          >
            Back
          </button>
        )}
      </div>

      {!selectedTherapeutic ? (
        <div className="space-y-4">
          <div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {therapeuticGoals.map((goal) => (
                <button
                  key={goal.id}
                  onClick={() => setSelectedTherapeutic(goal.id)}
                  className="group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all"
                >
                  <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                    <img 
                      src={goal.albumArt}
                      alt={goal.name}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                      }}
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                        <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-white text-sm leading-tight line-clamp-2">{goal.name}</h3>
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {loading ? (
            <div className="text-blue-300 text-center py-8">
              Loading your personalized tracks...
            </div>
          ) : tracks.length > 0 ? (
            <div className="space-y-4">
              <div className="text-center py-4">
                <div className="text-white text-lg font-medium">
                  {therapeuticGoals.find(g => g.id === selectedTherapeutic)?.name}
                </div>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {tracks.map((track) => (
                  <div 
                    key={track.id}
                    className="group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all"
                  >
                    <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                      <img 
                        src={track.coverUrl || `/api/art/${encodeURIComponent(track.title)}`}
                        alt={track.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                      <button 
                        onClick={() => handlePlay(track)}
                        className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                          <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                        </div>
                      </button>
                    </div>
                    <h4 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{track.title}</h4>
                    <p className="text-xs text-blue-200 line-clamp-1">
                      {track.artist ?? 'Neural Positive Music'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-blue-300 text-center py-8">
              No tracks found for this therapeutic goal.
            </div>
          )}
        </div>
      )}
    </div>
  );
}