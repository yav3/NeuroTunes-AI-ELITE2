import { useEffect, useState } from 'react';
import { fetchTracks } from '../lib/apiNew';
import type { Track } from '../lib/apiNew';
import TrackCard from '../components/TrackCardNew';

export default function TracksDemo() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | undefined>();

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(undefined);

    fetchTracks({ sort: 'popular', limit: 20 })
      .then(list => {
        if (!alive) return;
        setTracks(Array.isArray(list) ? list : []);
      })
      .catch(e => {
        if (!alive) return;
        setError(e?.message ?? 'Failed to load tracks');
      })
      .finally(() => alive && setLoading(false));

    return () => { alive = false; };
  }, []);

  return (
    <div className="min-h-screen p-6 max-w-2xl mx-auto">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold text-white">Popular</h2>
          <div className="text-sm text-blue-300">
            {loading ? 'Loading…' : `${tracks.length} tracks`}
          </div>
        </div>

        {error && (
          <div className="text-red-400 text-sm border border-red-500/30 bg-red-500/10 rounded-md p-3">
            {error}
          </div>
        )}

        {loading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 bg-white/5 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            {tracks.map(t => (
              <TrackCard key={t.id} track={t} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}