import React, { useEffect, useState } from 'react';
import { useAudio } from '../context/AudioContext';

interface Track {
  id: number;
  title: string;
  artist?: string;
  coverUrl?: string;
  therapeuticTags?: string[];
}

export default function MoodPage() {
  const { play } = useAudio();
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTracks = async () => {
      try {
        const response = await fetch('/api/tracks');
        const data = await response.json();
        const catalog = data.catalog || data;
        setTracks(catalog.slice(0, 20)); // Show first 20 tracks
      } catch (error) {
        console.error('Failed to load tracks:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadTracks();
  }, []);

  const handlePlay = (track: Track) => {
    play(track, tracks).catch(err => {
      console.warn(`[AUDIO] Play failed: ${track.title}`, err);
      alert(`Cannot play: ${track.title}`);
    });
  };

  if (loading) {
    return (
      <div className="text-blue-300 text-center py-8">Loading music library...</div>
    );
  }

  return (
    <div className="w-full space-y-6">
      <div className="text-xl font-medium text-white">Emotions & Moods</div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
        {tracks.map(track => (
          <div key={track.id} className="group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all">
            <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
              <img 
                src={track.coverUrl || `/api/art/${encodeURIComponent(track.title)}`}
                alt={track.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                }}
              />
              <button 
                onClick={() => handlePlay(track)}
                className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                  <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                </div>
              </button>
            </div>
            <h4 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{track.title}</h4>
            <p className="text-xs text-blue-200 line-clamp-1">
              {track.artist ?? 'Neural Positive Music'}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}