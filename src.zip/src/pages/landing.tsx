import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { Brain, Music, Heart, Zap } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen deep-blue-gradient">
      {/* Header with Theme Toggle */}
      <div className="absolute top-4 right-4 z-10">
        <ThemeToggle />
      </div>
      
      {/* Hero Section */}
      <div className="container mx-auto px-6 py-16">
        <div className="text-center space-y-8">
          <div className="flex flex-col items-center justify-center space-y-4 mb-8">
            <div className="w-16 h-16 glass-card rounded-3xl flex items-center justify-center">
              <Music className="w-8 h-8 text-blue-400" />
            </div>
            <div className="text-center">
              <h1 className="text-5xl font-bold text-gray-900 dark:text-gray-100">NeuroTunes AI</h1>
              <p className="text-xl text-gray-600 dark:text-gray-400 mt-2">For Clinical Applications</p>
            </div>
          </div>
          
          <div className="space-y-6 max-w-4xl mx-auto">
            <h2 className="text-5xl font-light text-gray-900 dark:text-gray-100 leading-tight">
              Music recommendation that adapts to your state.
            </h2>

          </div>
          
          <div className="space-y-4">
            <Button 
              size="lg"
              className="glass-button px-8 py-4 rounded-2xl text-lg font-medium text-white"
              onClick={() => window.location.href = '/api/login'}
            >
              Start Your Clinical Wellness Journey
            </Button>
            <p className="text-sm text-gray-500 dark:text-gray-400">Access clinical-grade therapeutic music recommendations</p>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-24">
          <Card className="glass-card border-0 text-center p-6">
            <CardHeader>
              <div className="w-16 h-16 mx-auto bg-calm-primary/20 rounded-full flex items-center justify-center mb-4">
                <Brain className="w-8 h-8 text-calm-primary" />
              </div>
              <CardTitle className="font-light text-gray-900 dark:text-gray-100">Clinical Performance Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400">Advanced AI analyzes your mental state and wellness metrics to optimize therapeutic focus and recovery.</p>
            </CardContent>
          </Card>

          <Card className="glass-card border-0 text-center p-6">
            <CardHeader>
              <div className="w-16 h-16 mx-auto bg-calm-secondary/20 rounded-full flex items-center justify-center mb-4">
                <Music className="w-8 h-8 text-calm-secondary" />
              </div>
              <CardTitle className="font-light text-gray-900 dark:text-gray-100">Clinical Therapeutic Music</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400">218 therapeutic tracks specifically designed for clinical wellness, focus, and recovery phases.</p>
            </CardContent>
          </Card>

          <Card className="glass-card border-0 text-center p-6">
            <CardHeader>
              <div className="w-16 h-16 mx-auto bg-therapeutic-coral/20 rounded-full flex items-center justify-center mb-4">
                <Heart className="w-8 h-8 text-therapeutic-coral" />
              </div>
              <CardTitle className="font-light text-gray-900 dark:text-gray-100">Performance Tracking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400">Track your mental wellness metrics with detailed analytics designed for clinical therapeutic development.</p>
            </CardContent>
          </Card>

          <Card className="glass-card border-0 text-center p-6">
            <CardHeader>
              <div className="w-16 h-16 mx-auto bg-therapeutic-sage/20 rounded-full flex items-center justify-center mb-4">
                <Zap className="w-8 h-8 text-therapeutic-sage" />
              </div>
              <CardTitle className="font-light text-gray-900 dark:text-gray-100">Closed Loop Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400">Real-time biometric monitoring with closed loop analysis and music recommendation that adapts to your training state.</p>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-24 glass-card rounded-5xl p-12 max-w-4xl mx-auto">
          <h3 className="text-3xl font-light text-gray-900 dark:text-gray-100 mb-6">Ready to Begin Clinical Wellness?</h3>

          <Button 
            size="lg"
            className="bg-calm-primary hover:bg-calm-primary/90 text-white px-8 py-4 rounded-2xl text-lg font-medium"
            onClick={() => window.location.href = '/api/login'}
          >
            Access Clinical Platform
          </Button>
        </div>
      </div>
    </div>
  );
}
