import React, { useEffect, useState } from 'react';
import { fetchTracks, Track } from '../lib/apiNew';
import { useStableAudio } from '../context/StableAudioContext';

interface TherapeuticSection {
  goal: string;
  description: string;
  albumArt: string;
  tracks: Track[];
}

async function fetchTracksByGoal(goal: string): Promise<Track[]> {
  const res = await fetch(`/api/tracks/mood/${goal}`);
  if (!res.ok) throw new Error(`Failed to fetch ${goal} tracks`);
  return await res.json();
}

export default function HomePageRefresh() {
  const [tab, setTab] = useState('therapeutic');
  const [tracks, setTracks] = useState([]);
  const [therapeuticSections, setTherapeuticSections] = useState([]);
  const [loading, setLoading] = useState(true);
  const { play } = useStableAudio();

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    
    if (tab === 'therapeutic') {
      const loadTherapeuticSections = async () => {
        try {
          // THERAPEUTIC GOALS: Clinical/wellness objectives for specific treatment outcomes
          const therapeuticGoals = [
            { 
              goal: 'focus', 
              description: 'Concentration enhancement for cognitive performance',
              category: 'therapeutic',
              albumArt: '/api/art/focus-on-nature-as-she-rejoices'
            },
            { 
              goal: 'mood_boost', 
              description: 'Clinical mood enhancement and emotional regulation',
              category: 'therapeutic',
              albumArt: '/api/art/Beautiful%20Babe'
            },
            { 
              goal: 'relaxation', 
              description: 'Stress reduction and autonomic nervous system regulation',
              category: 'therapeutic',
              albumArt: '/api/art/Breathe%20through%20It'
            },
            { 
              goal: 'energy_boost', 
              description: 'Vitality enhancement and motivational support',
              category: 'therapeutic',
              albumArt: '/api/art/Beast%20Mode'
            }
          ];

          const fetchTracksByGoal = async (goal: string) => {
            const response = await fetch(`/api/tracks/${goal === 'focus' ? 'classical-focus' : `mood/${goal}`}`);
            if (!response.ok) throw new Error(`Failed to fetch ${goal} tracks`);
            const rawTracks = await response.json();
            
            // AGGRESSIVE DEDUPLICATION: Remove all duplicates at source level
            const uniqueTrackMap = new Map();
            const filteredTracks: Track[] = [];
            
            for (const track of rawTracks) {
              // Create comprehensive deduplication key
              const titleKey = track.title.toLowerCase()
                .replace(/[^\w\s]/g, ' ')     // Replace special chars with spaces
                .replace(/\s+/g, ' ')         // Normalize multiple spaces
                .trim();
              
              const artistKey = (track.artist || 'unknown').toLowerCase().trim();
              const compositeKey = `${titleKey}|${artistKey}`;
              
              // Only add if we haven't seen this exact combination
              if (!uniqueTrackMap.has(compositeKey)) {
                uniqueTrackMap.set(compositeKey, true);
                filteredTracks.push(track);
              }
            }
            
            console.log(`🔧 ${goal}: Raw ${rawTracks.length} → Filtered ${filteredTracks.length} (removed ${rawTracks.length - filteredTracks.length} duplicates)`);
            
            // Debug: Log actual duplicate titles if any
            if (rawTracks.length !== filteredTracks.length) {
              const duplicateTitles = rawTracks.map(t => t.title).filter((title, index, arr) => arr.indexOf(title) !== index);
              console.log(`📋 ${goal} duplicates found:`, [...new Set(duplicateTitles)]);
            }
            
            return filteredTracks;
          };

          // GLOBAL DEDUPLICATION: Ensure no track appears multiple times across ALL categories
          const globalTrackSet = new Set<string>();
          const sectionsDataWithUniqueTracksAcrossAll: TherapeuticSection[] = [];

          // Process each goal sequentially to maintain global uniqueness
          for (const { goal, description, albumArt } of therapeuticGoals) {
            try {
              const tracks = await fetchTracksByGoal(goal);
              
              // Filter out tracks that have already been used in previous categories
              const globallyUniqueTracks: Track[] = [];
              
              for (const track of tracks) {
                const globalKey = track.title.toLowerCase().trim();
                
                // Only add if this track hasn't been used in ANY previous category
                if (!globalTrackSet.has(globalKey)) {
                  globalTrackSet.add(globalKey);
                  globallyUniqueTracks.push(track);
                }
              }
              
              console.log(`🎵 ${goal}: ${tracks.length} → ${globallyUniqueTracks.length} after GLOBAL uniqueness check`);
              console.log(`🎯 ${goal} first 5 unique tracks:`, globallyUniqueTracks.slice(0, 5).map((t: Track) => t.title));
              
              sectionsDataWithUniqueTracksAcrossAll.push({ 
                goal, 
                description, 
                albumArt, 
                tracks: globallyUniqueTracks.slice(0, 48) 
              });
            } catch (error) {
              console.warn(`Failed to load ${goal} tracks:`, error);
              sectionsDataWithUniqueTracksAcrossAll.push({ goal, description, albumArt, tracks: [] });
            }
          }

          const sectionsData = sectionsDataWithUniqueTracksAcrossAll;

          if (mounted) {
            // Show sections with at least 1 track - let the user see all available content
            console.log(`📊 Therapeutic sections loaded:`, sectionsData.map(s => `${s.goal}: ${s.tracks.length} tracks`));
            setTherapeuticSections(sectionsData.filter(section => section.tracks.length >= 1));
          }
        } catch (error) {
          console.error('Failed to load therapeutic sections:', error);
        } finally {
          if (mounted) {
            setLoading(false);
          }
        }
      };
      
      loadTherapeuticSections();
    } else {
      const params: Record<string, string | number> = tab === 'popular' ? { sort: 'popular', limit: 120 }
                   : tab === 'recent'  ? { sort: 'recent',  limit: 120 }
                   : { limit: 120 };
      fetchTracks(params).then((t) => { 
        if(mounted) {
          // Enhanced deduplication for non-therapeutic tabs as well
          const uniqueTrackMap = new Map();
          const artistTrackCounts = new Map();
          const deduplicatedTracks: Track[] = [];
          
          for (const track of t) {
            // Create a more sophisticated key that catches variations
            const baseTitle = track.title.toLowerCase()
              .replace(/[^\w\s-]/g, '') // Remove special chars
              .replace(/\s+/g, ' ')     // Normalize spaces
              .trim();
            
            // Extract base track name (remove remix/mix/version indicators)
            const cleanTitle = baseTitle
              .replace(/\s*(deep|ambient|acoustic|instrumental|extended|radio|edit|remix|mix|version|remaster)(\s+mix|\s+edit|\s+version)?\s*$/i, '')
              .replace(/\s*\(.*?\)\s*$/g, '') // Remove parenthetical content
              .trim();
            
            const artist = (track.artist || 'Unknown').toLowerCase();
            const artistCount = artistTrackCounts.get(artist) || 0;
            
            // Skip if we already have this base track
            if (uniqueTrackMap.has(cleanTitle)) {
              continue;
            }
            
            // Limit tracks per artist to ensure variety (max 4 per artist for non-therapeutic)
            if (artistCount >= 4) {
              continue;
            }
            
            uniqueTrackMap.set(cleanTitle, track);
            artistTrackCounts.set(artist, artistCount + 1);
            deduplicatedTracks.push(track);
          }
          
          console.log(`🎵 ${tab}: ${t.length} → ${deduplicatedTracks.length} after deduplication`);
          setTracks(deduplicatedTracks);
        }
      })
        .catch(console.error)
        .finally(() => mounted && setLoading(false));
    }
    
    return () => { mounted = false; }
  }, [tab]);

  const handlePlay = (track: Track, allTracks?: Track[]) => {
    try {
      // Convert to new audio context format
      const audioTrack = {
        id: track.id,
        title: track.title,
        artist: track.artist || 'NeuroTunes Library',
        audioUrl: `/api/stream/${encodeURIComponent((track as any).filename || track.title)}`,
        coverUrl: track.coverUrl,
        duration: track.duration
      };
      
      play(audioTrack);
    } catch (err) {
      console.warn(`[AUDIO] Play failed: ${track.title}`, err);
      alert(`Cannot play: ${track.title}`);
    }
  };



  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <header className="mb-6 pt-4">
        <h1 className="text-2xl font-semibold text-white tracking-tight">Home</h1>
        <p className="text-blue-200/80 text-sm mt-1">NeuroTunes</p>
      </header>

      <div className="flex items-center justify-between gap-2 sm:gap-4">
        <div className="text-lg sm:text-xl font-medium text-white">Trending</div>
        <div className="flex bg-white/5 rounded-lg p-0.5 sm:p-1 border border-white/10 gap-0.5 sm:gap-1 shrink-0">
          <Tab v="therapeutic" cur={tab} set={setTab} />
          <Tab v="popular" cur={tab} set={setTab} />
          <Tab v="recent"  cur={tab} set={setTab} />
          <Tab v="all"     cur={tab} set={setTab} />
        </div>
      </div>

      {loading ? (
        <div className="text-blue-300 text-center py-8">Loading your music library…</div>
      ) : tab === 'therapeutic' ? (
        <div className="space-y-8">
          {therapeuticSections.map(section => (
            <div key={section.goal} className="space-y-4">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 rounded-xl overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 flex-shrink-0">
                  <img 
                    src={section.albumArt}
                    alt={section.goal}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = 'none';
                    }}
                  />
                </div>
                <div className="flex-1">
                  <h2 className="text-lg font-semibold text-white capitalize">
                    {section.goal === 'focus' ? 'Focus' : section.goal.replace('_', ' ')}
                  </h2>
                  <p className="text-sm text-blue-200">{section.description}</p>
                </div>
              </div>
              
              {/* Show all therapeutic tracks in proper grid layout */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {section.tracks
                  .filter((track, index, self) => {
                    // Final frontend deduplication - ensure no duplicates in rendering
                    const key = `${track.title.toLowerCase().trim()}|${(track.artist || '').toLowerCase().trim()}`;
                    return index === self.findIndex(t => 
                      `${t.title.toLowerCase().trim()}|${(t.artist || '').toLowerCase().trim()}` === key
                    );
                  })
                  .map((track, trackIndex) => (
                  <div key={`${track.title}-${track.artist}-${trackIndex}`} className="group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all">
                    <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                      <img 
                        src={`/api/art/${encodeURIComponent(track.title)}`}
                        alt={track.title}
                        className="w-full h-full object-cover"
                        onLoad={(e) => {
                          const target = e.target as HTMLImageElement;
                          console.log('Album art loaded for:', track.title);
                        }}
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          console.log('Album art failed for:', track.title);
                          target.style.display = 'none';
                        }}
                      />
                      <button 
                        onClick={() => handlePlay(track, section.tracks)}
                        className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                          <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                        </div>
                      </button>
                    </div>
                    <h4 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{track.title}</h4>
                    <p className="text-xs text-blue-200 line-clamp-1">
                      {track.artist ?? 'Neural Positive Music'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {tracks.map(t => (
            <div key={String(t.id)} className="group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all">
              <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                <img 
                  src={`/api/art/${encodeURIComponent(t.title)}`}
                  alt={t.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                />
                <button 
                  onClick={() => handlePlay(t)}
                  className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                    <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                  </div>
                </button>
              </div>
              <h3 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{t.title}</h3>
              <p className="text-xs text-blue-200 line-clamp-1">
                {t.artist ?? 'Neural Positive Music'} • {t.therapeuticTags?.slice(0, 1).join('') || 'Therapeutic'}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Tab({v,cur,set}:{v:'popular'|'recent'|'all'|'therapeutic';cur:any;set:(x:any)=>void}) {
  const active = cur===v;
  return (
    <button 
      onClick={() => set(v)} 
      className={`px-2 sm:px-3 py-1.5 text-xs font-medium transition-colors rounded-md whitespace-nowrap ${
        active ? 'bg-blue-600 text-white' : 'text-blue-200 hover:text-white'
      }`}
    >
      {v === 'therapeutic' ? 'Goals' : v.charAt(0).toUpperCase() + v.slice(1)}
    </button>
  );
}