import React, { useState, useEffect } from 'react';
import { useAudio } from '../context/AudioContext';
import { Track } from '../lib/apiNew';

interface MoodOption {
  id: string;
  label: string;
  description: string;
  albumArt: string;
}

const MOOD_OPTIONS: MoodOption[] = [
  { 
    id: 'focus', 
    label: 'Unfocused', 
    description: 'Scattered attention and difficulty concentrating',
    albumArt: '/api/art/Battle%20Song%20Edm%20Focus'
  },
  { 
    id: 'energy_boost', 
    label: 'Tired', 
    description: 'Low energy and feeling drained',
    albumArt: '/api/art/Beast%20Mode'
  },
  { 
    id: 'relaxation', 
    label: 'Stressed', 
    description: 'Tense and overwhelmed feeling',
    albumArt: '/api/art/Breathe%20through%20It'
  },
  { 
    id: 'sleep', 
    label: 'Pain', 
    description: 'Physical or emotional discomfort',
    albumArt: '/api/art/Sarabande%204%20Baroque%20Classical%20Sleep'
  }
];

export default function EmotionsPageFixed() {
  const { play } = useAudio();
  const [selectedMood, setSelectedMood] = useState<string>('focus'); // Default to focus mood
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);

  // Load default mood tracks on component mount
  React.useEffect(() => {
    if (selectedMood) {
      fetchMoodTracks(selectedMood);
    }
  }, []); // Only run on mount

  const fetchMoodTracks = async (moodId: string) => {
    setLoading(true);
    try {
      console.log(`[Emotions] Loading tracks for mood: ${moodId}`);
      const response = await fetch(`/api/tracks/mood/${moodId}`);
      if (response.ok) {
        const trackData = await response.json();
        console.log(`[Emotions] Received ${trackData.length} tracks for ${moodId}`);
        setTracks(trackData.slice(0, 24)); // Show first 24 tracks
      } else {
        console.error(`[Emotions] Failed to fetch tracks for ${moodId}:`, response.status);
        setTracks([]);
      }
    } catch (error) {
      console.error('Failed to load tracks:', error);
      setTracks([]);
    } finally {
      setLoading(false);
    }
  };

  const handleMoodSelect = (moodId: string) => {
    setSelectedMood(moodId);
    fetchMoodTracks(moodId);
  };

  const handlePlay = (track: Track) => {
    play(track, tracks).catch(err => {
      console.warn(`[AUDIO] Play failed: ${track.title}`, err);
      alert(`Cannot play: ${track.title}`);
    });
  };

  return (
    <div className="w-full space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-xl font-medium text-white">Emotions & Moods</div>
          <div className="text-sm text-blue-200 mt-1">
            How are you feeling? Choose your mood for personalized music
          </div>
        </div>
        {selectedMood && (
          <button
            onClick={() => {
              setSelectedMood('');
              setTracks([]);
            }}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm transition-colors"
          >
            Back
          </button>
        )}
      </div>

      {!selectedMood ? (
        <div className="space-y-4">
          <div>
            <h2 className="text-lg font-semibold text-white mb-3">Select Your Mood</h2>
            {/* Cache buster: 2025-08-19-v2 */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {MOOD_OPTIONS.map((mood) => (
                <button
                  key={mood.id}
                  onClick={() => handleMoodSelect(mood.id)}
                  className="group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all"
                >
                  <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                    <img 
                      src={mood.albumArt}
                      alt={mood.label}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.style.display = 'none';
                      }}
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                        <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                      </div>
                    </div>
                  </div>
                  <h3 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{mood.label}</h3>
                  <p className="text-xs text-blue-200 line-clamp-1">{mood.description}</p>
                </button>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {loading ? (
            <div className="text-blue-300 text-center py-8">
              Loading your personalized tracks...
            </div>
          ) : tracks.length > 0 ? (
            <div className="space-y-4">
              <div className="text-center py-4">
                <div className="text-white text-lg font-medium">
                  {MOOD_OPTIONS.find(m => m.id === selectedMood)?.label}
                </div>
                <div className="text-blue-200 text-sm mt-1">
                  {MOOD_OPTIONS.find(m => m.id === selectedMood)?.description}
                </div>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {tracks.map((track, trackIndex) => (
                  <div key={`${track.id}-${trackIndex}-${track.title}`} className="group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all">
                    <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                      <img 
                        src={track.coverUrl || `/api/art/${encodeURIComponent(track.title)}`}
                        alt={track.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                      <button 
                        onClick={() => handlePlay(track)}
                        className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                          <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                        </div>
                      </button>
                    </div>
                    <h4 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{track.title}</h4>
                    <p className="text-xs text-blue-200 line-clamp-1">
                      {track.artist ?? 'Neural Positive Music'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-blue-200">No tracks found for this mood</div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}