import React, { useEffect, useMemo, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useStableAudio } from "../context/StableAudioContext";

// tiny inline SVGs (no lucide-react dependency)
const Icon = {
  Back: (p: any) => (
    <svg width="24" height="24" viewBox="0 0 24 24" {...p}><path fill="none" stroke="currentColor" strokeWidth="2" d="M15 6l-6 6 6 6"/></svg>
  ),
  Pause: (p: any) => (
    <svg width="28" height="28" viewBox="0 0 24 24" {...p}><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>
  ),
  Play: (p: any) => (
    <svg width="28" height="28" viewBox="0 0 24 24" {...p}><polygon points="6,4 20,12 6,20"/></svg>
  ),
  Prev: (p: any) => (
    <svg width="24" height="24" viewBox="0 0 24 24" {...p}><polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="5" x2="5" y2="19" stroke="currentColor" strokeWidth="2"/></svg>
  ),
  Next: (p: any) => (
    <svg width="24" height="24" viewBox="0 0 24 24" {...p}><polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19" stroke="currentColor" strokeWidth="2"/></svg>
  ),
  Volume: (p: any) => (
    <svg width="20" height="20" viewBox="0 0 24 24" {...p}><path d="M11 5L6 9H3v6h3l5 4z"/><path d="M15 9a5 5 0 0 1 0 6"/></svg>
  ),
  Full: (p: any) => (
    <svg width="22" height="22" viewBox="0 0 24 24" {...p}><path d="M4 9V4h5"/><path d="M20 15v5h-5"/><path d="M20 9V4h-5"/><path d="M4 15v5h5" fill="none" stroke="currentColor" strokeWidth="2"/></svg>
  ),
  ExitFull: (p: any) => (
    <svg width="22" height="22" viewBox="0 0 24 24" {...p}><path d="M9 9H4V4"/><path d="M15 15h5v5"/><path d="M15 9h5V4"/><path d="M9 15H4v5" fill="none" stroke="currentColor" strokeWidth="2"/></svg>
  ),
};

function fmt(n: number) {
  if (!Number.isFinite(n)) return "0:00";
  const m = Math.floor(n / 60);
  const s = Math.floor(n % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function FullPlayer() {
  const nav = useNavigate();
  const { current: currentTrack, isPlaying, toggle, volume, setVolume, currentTime, duration, seek } = useStableAudio();

  // derive track fields safely
  const { title, artist, cover } = useMemo(() => {
    const t = currentTrack as any || {};
    return {
      title: t.title || t.name || "Untitled",
      artist: t.artist || (Array.isArray(t.artists) ? t.artists.join(", ") : t.artists) || "",
      cover: t.image || t.cover || t.artUrl || "",
    };
  }, [currentTrack]);

  // keyboard support
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space") { e.preventDefault(); toggle(); }
      else if (e.code === "ArrowRight") seek((currentTime || 0) + 5);
      else if (e.code === "ArrowLeft") seek(Math.max(0, (currentTime || 0) - 5));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [seek, toggle, currentTime]);

  // fullscreen toggle
  const wrapRef = useRef<HTMLDivElement>(null);
  const toggleFull = async () => {
    try {
      if (!document.fullscreenElement && wrapRef.current) {
        await wrapRef.current.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {}
  };

  const pct = duration ? (currentTime / duration) * 100 : 0;

  return (
    <div ref={wrapRef} className="fixed inset-0 z-[60] bg-[#0b1020] text-white pb-[env(safe-area-inset-bottom)]">
      {/* header */}
      <div className="flex items-center justify-between px-4 pt-[env(safe-area-inset-top)] h-14">
        <button onClick={() => nav(-1)} className="p-2 rounded-xl hover:bg-white/10" aria-label="Back">
          <Icon.Back />
        </button>
        <div className="text-sm opacity-70">Now Playing</div>
        <button onClick={toggleFull} className="p-2 rounded-xl hover:bg-white/10" aria-label="Toggle fullscreen">
          {document.fullscreenElement ? <Icon.ExitFull/> : <Icon.Full/>}
        </button>
      </div>

      {/* album art + play */}
      <div className="px-6">
        <div className="relative mx-auto w-full max-w-md aspect-square rounded-3xl overflow-hidden shadow-2xl">
          {cover ? (
            <img src={cover} alt={title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-slate-700 via-slate-800 to-slate-900" />
          )}
          <button
            onClick={toggle}
            className="absolute inset-0 grid place-items-center group"
            aria-label={isPlaying ? "Pause" : "Play"}
          >
            <div className="rounded-full backdrop-blur-md bg-white/15 p-6 border border-white/20 group-active:scale-95 transition">
              {isPlaying ? <Icon.Pause/> : <Icon.Play/>}
            </div>
          </button>
        </div>

        {/* title/artist */}
        <div className="mt-6 text-center">
          <div className="text-lg font-semibold">{title}</div>
          {artist && <div className="text-sm opacity-70 mt-1">{artist}</div>}
        </div>

        {/* transport */}
        <div className="mt-6 flex items-center justify-center gap-6">
          <button className="p-3 rounded-xl hover:bg-white/10 opacity-50" aria-label="Previous" disabled><Icon.Prev/></button>
          <button onClick={toggle} className="p-4 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20" aria-label="Play/Pause">
            {isPlaying ? <Icon.Pause/> : <Icon.Play/>}
          </button>
          <button className="p-3 rounded-xl hover:bg-white/10 opacity-50" aria-label="Next" disabled><Icon.Next/></button>
        </div>

        {/* progress */}
        <div className="mt-5">
          <input
            type="range"
            min={0}
            max={duration || 0}
            step={0.1}
            value={currentTime || 0}
            onChange={(e) => seek(parseFloat(e.target.value))}
            className="w-full accent-white"
          />
          <div className="flex justify-between text-xs opacity-70 mt-1">
            <span>{fmt(currentTime || 0)}</span>
            <span>{fmt(duration || 0)}</span>
          </div>
        </div>

        {/* volume */}
        <div className="mt-5 flex items-center gap-3">
          <Icon.Volume className="opacity-70" />
          <input
            type="range"
            min={0}
            max={1}
            step={0.01}
            value={volume ?? 1}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="w-full accent-white"
          />
        </div>

        {/* subtle progress bar under header for long songs */}
        <div className="mt-6 h-1 rounded-full bg-white/10">
          <div className="h-full rounded-full bg-white/50" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </div>
  );
}