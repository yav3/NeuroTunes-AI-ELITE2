import React, { useState, useEffect } from 'react';
import { User, Settings, HeadphonesIcon, Music } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import HapticControls from '../components/HapticControls';

interface UserProfile {
  id: string;
  name: string;
  email: string;
  preferences: {
    preferredGenres: string[];
    therapeuticGoals: string[];
    sessionDuration: number;
    spatialAudioEnabled: boolean;
    autoPlayEnabled: boolean;
  };
  stats: {
    totalListeningTime: number;
    sessionsCompleted: number;
    favoriteGenre: string;
    averageSessionLength: number;
  };
}

interface ProfilePageProps {
  onSettingsUpdate?: (settings: any) => void;
}

export default function ProfilePage({ onSettingsUpdate }: ProfilePageProps) {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'profile' | 'preferences' | 'stats'>('profile');
  
  const { hapticEnabled, hapticIntensity, setHapticEnabled, setHapticIntensity } = useAudio();

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await fetch('/api/user/profile');
      if (response.ok) {
        const data = await response.json();
        setProfile(data);
      } else {
        console.error('Failed to fetch profile');
      }
    } catch (error) {
      console.error('Error fetching profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const updatePreferences = async (preferences: Partial<UserProfile['preferences']>) => {
    try {
      const response = await fetch('/api/user/preferences', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(preferences)
      });

      if (response.ok) {
        const updated = await response.json();
        setProfile(prev => prev ? { ...prev, preferences: updated } : null);
        if (onSettingsUpdate) {
          onSettingsUpdate(updated);
        }
      }
    } catch (error) {
      console.error('Error updating preferences:', error);
    }
  };

  if (loading) {
    return (
      <div style={{ 
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        color: 'white'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ 
            width: '40px', 
            height: '40px', 
            border: '3px solid rgba(255,255,255,0.3)',
            borderTop: '3px solid #3b82f6',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 16px'
          }}></div>
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      padding: '20px',
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      minHeight: '100vh',
      color: 'white'
    }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <h1 style={{ 
            fontSize: '32px', 
            fontWeight: 'bold', 
            marginBottom: '8px'
          }}>
            Profile & Settings
          </h1>
          <p style={{ 
            fontSize: '16px', 
            opacity: 0.8 
          }}>
            Manage your therapeutic music preferences
          </p>
        </div>

        {/* Tab Navigation */}
        <div style={{ 
          display: 'flex', 
          gap: '0', 
          marginBottom: '32px',
          background: 'rgba(255,255,255,0.05)',
          borderRadius: '8px',
          padding: '4px'
        }}>
          {[
            { id: 'profile', label: 'Profile' },
            { id: 'preferences', label: 'Preferences' },
            { id: 'stats', label: 'Statistics' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              style={{
                flex: 1,
                padding: '12px',
                borderRadius: '6px',
                border: 'none',
                background: activeTab === tab.id ? 'rgba(59, 130, 246, 0.3)' : 'transparent',
                color: 'white',
                fontSize: '14px',
                fontWeight: '600',
                cursor: 'pointer',
                transition: 'all 0.2s ease'
              }}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Profile Tab */}
        {activeTab === 'profile' && profile && (
          <div style={{ 
            padding: '24px',
            background: 'rgba(255,255,255,0.05)',
            borderRadius: '12px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <h2 style={{ fontSize: '20px', fontWeight: '600', marginBottom: '24px' }}>
              Account Information
            </h2>
            
            <div style={{ display: 'grid', gap: '20px' }}>
              <div>
                <label style={{ 
                  display: 'block', 
                  fontSize: '14px', 
                  fontWeight: '600', 
                  marginBottom: '8px',
                  opacity: 0.8
                }}>
                  Display Name
                </label>
                <input
                  type="text"
                  value={profile.name}
                  readOnly
                  style={{
                    width: '100%',
                    padding: '12px',
                    borderRadius: '6px',
                    border: '1px solid rgba(255,255,255,0.2)',
                    background: 'rgba(255,255,255,0.05)',
                    color: 'white',
                    fontSize: '14px'
                  }}
                />
              </div>
              
              <div>
                <label style={{ 
                  display: 'block', 
                  fontSize: '14px', 
                  fontWeight: '600', 
                  marginBottom: '8px',
                  opacity: 0.8
                }}>
                  Email Address
                </label>
                <input
                  type="email"
                  value={profile.email}
                  readOnly
                  style={{
                    width: '100%',
                    padding: '12px',
                    borderRadius: '6px',
                    border: '1px solid rgba(255,255,255,0.2)',
                    background: 'rgba(255,255,255,0.05)',
                    color: 'white',
                    fontSize: '14px'
                  }}
                />
              </div>
            </div>
          </div>
        )}

        {/* Preferences Tab */}
        {activeTab === 'preferences' && profile && (
          <div style={{ 
            padding: '24px',
            background: 'rgba(255,255,255,0.05)',
            borderRadius: '12px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <h2 style={{ fontSize: '20px', fontWeight: '600', marginBottom: '24px' }}>
              Music Preferences
            </h2>
            
            <div style={{ display: 'grid', gap: '24px' }}>
              {/* Therapeutic Goals */}
              <div>
                <label style={{ 
                  display: 'block', 
                  fontSize: '14px', 
                  fontWeight: '600', 
                  marginBottom: '12px'
                }}>
                  Therapeutic Goals
                </label>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))', gap: '8px' }}>
                  {['Focus', 'Stress Relief', 'Sleep', 'Energy', 'Meditation', 'Pain Management'].map((goal) => (
                    <label key={goal} style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                      <input
                        type="checkbox"
                        checked={profile.preferences.therapeuticGoals.includes(goal.toLowerCase())}
                        onChange={(e) => {
                          const goals = e.target.checked
                            ? [...profile.preferences.therapeuticGoals, goal.toLowerCase()]
                            : profile.preferences.therapeuticGoals.filter(g => g !== goal.toLowerCase());
                          updatePreferences({ therapeuticGoals: goals });
                        }}
                        style={{ marginRight: '8px' }}
                      />
                      <span style={{ fontSize: '14px' }}>{goal}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Audio Settings */}
              <div>
                <label style={{ 
                  display: 'block', 
                  fontSize: '14px', 
                  fontWeight: '600', 
                  marginBottom: '12px'
                }}>
                  Audio Settings
                </label>
                <div style={{ display: 'grid', gap: '12px' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={profile.preferences.spatialAudioEnabled}
                      onChange={(e) => updatePreferences({ spatialAudioEnabled: e.target.checked })}
                    />
                    <span style={{ fontSize: '14px' }}>Enable Spatial Audio by default</span>
                  </label>
                  <label style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={profile.preferences.autoPlayEnabled}
                      onChange={(e) => updatePreferences({ autoPlayEnabled: e.target.checked })}
                    />
                    <span style={{ fontSize: '14px' }}>Auto-play next track</span>
                  </label>
                </div>
              </div>

              {/* Haptic Feedback Controls */}
              <div>
                <HapticControls />
              </div>

              {/* Session Duration */}
              <div>
                <label style={{ 
                  display: 'block', 
                  fontSize: '14px', 
                  fontWeight: '600', 
                  marginBottom: '8px'
                }}>
                  Default Session Duration: {profile.preferences.sessionDuration} minutes
                </label>
                <input
                  type="range"
                  min="15"
                  max="120"
                  step="15"
                  value={profile.preferences.sessionDuration}
                  onChange={(e) => updatePreferences({ sessionDuration: parseInt(e.target.value) })}
                  style={{
                    width: '100%',
                    height: '6px',
                    borderRadius: '3px',
                    background: 'rgba(255,255,255,0.2)',
                    outline: 'none'
                  }}
                />
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px', opacity: 0.6, marginTop: '4px' }}>
                  <span>15 min</span>
                  <span>120 min</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Statistics Tab */}
        {activeTab === 'stats' && profile && (
          <div style={{ 
            padding: '24px',
            background: 'rgba(255,255,255,0.05)',
            borderRadius: '12px',
            border: '1px solid rgba(255,255,255,0.1)'
          }}>
            <h2 style={{ fontSize: '20px', fontWeight: '600', marginBottom: '24px' }}>
              Listening Statistics
            </h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px' }}>
              <div style={{ 
                padding: '20px',
                background: 'rgba(59, 130, 246, 0.1)',
                borderRadius: '8px',
                border: '1px solid rgba(59, 130, 246, 0.2)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#60a5fa', marginBottom: '8px' }}>
                  {Math.round(profile.stats.totalListeningTime / 60)}h
                </div>
                <div style={{ fontSize: '14px', opacity: 0.8 }}>Total Listening Time</div>
              </div>

              <div style={{ 
                padding: '20px',
                background: 'rgba(34, 197, 94, 0.1)',
                borderRadius: '8px',
                border: '1px solid rgba(34, 197, 94, 0.2)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#4ade80', marginBottom: '8px' }}>
                  {profile.stats.sessionsCompleted}
                </div>
                <div style={{ fontSize: '14px', opacity: 0.8 }}>Sessions Completed</div>
              </div>

              <div style={{ 
                padding: '20px',
                background: 'rgba(168, 85, 247, 0.1)',
                borderRadius: '8px',
                border: '1px solid rgba(168, 85, 247, 0.2)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '18px', fontWeight: 'bold', color: '#a855f7', marginBottom: '8px' }}>
                  {profile.stats.favoriteGenre}
                </div>
                <div style={{ fontSize: '14px', opacity: 0.8 }}>Favorite Genre</div>
              </div>

              <div style={{ 
                padding: '20px',
                background: 'rgba(249, 115, 22, 0.1)',
                borderRadius: '8px',
                border: '1px solid rgba(249, 115, 22, 0.2)',
                textAlign: 'center'
              }}>
                <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#fb923c', marginBottom: '8px' }}>
                  {Math.round(profile.stats.averageSessionLength)}m
                </div>
                <div style={{ fontSize: '14px', opacity: 0.8 }}>Average Session</div>
              </div>
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}