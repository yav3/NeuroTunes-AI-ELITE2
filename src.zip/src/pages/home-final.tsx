import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { 
  Menu,
  X,
  Home as HomeIcon, 
  Heart,
  Settings, 
  Shield,
  Brain,
  Library,
  Target,
  Activity
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import CleanMoodCheckIn from "@/components/CleanMoodCheckIn";

export default function Home() {
  const { user = {}, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-lg text-white">Loading...</div>
      </div>
    );
  }

  const handleNavigation = (path: string) => {
    setLocation(path);
    setSidebarOpen(false);
  };

  const sidebarItems = [
    { icon: HomeIcon, label: "Dashboard", path: "/", active: true },
    { icon: Library, label: "My Library", path: "/library" },
    { icon: Heart, label: "Favorites", path: "/favorites" },
    { icon: Heart, label: "Wellness", path: "/wellness" },
    { icon: Activity, label: "Biometrics", path: "/biometrics" },
    { icon: Target, label: "Session", path: "/session" },
    { icon: Shield, label: "Admin", path: "/admin" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  return (
    <div className="min-h-screen bg-black">
      {/* Mobile Menu Button */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="bg-gray-900 border-gray-700 text-white hover:bg-gray-800"
        >
          {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </Button>
      </div>

      {/* Sidebar Overlay (Mobile) */}
      {sidebarOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed left-0 top-0 h-full bg-gray-900 border-r border-gray-700 z-50 transition-transform duration-300",
        "w-64",
        sidebarOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}>
        {/* Header */}
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-white">NeuroTunes</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-3 md:p-4 space-y-1 md:space-y-2">
          {sidebarItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavigation(item.path)}
              className={cn(
                "w-full flex items-center space-x-3 px-3 md:px-4 py-2 md:py-3 rounded-lg text-left transition-colors text-sm md:text-base",
                item.active
                  ? "bg-blue-600 text-white"
                  : "text-gray-300 hover:bg-gray-800 hover:text-white"
              )}
            >
              <item.icon className="w-4 h-4 md:w-5 md:h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="absolute bottom-6 left-4 right-4">
          <div className="flex items-center space-x-3 p-3 rounded-lg bg-gray-800">
            <div className="w-2 h-2 rounded-full bg-green-400"></div>
            <span className="text-sm text-white">Welcome back, Brian</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="md:ml-64 flex items-center justify-center min-h-screen p-4">
        <div className="w-full max-w-lg">
          <CleanMoodCheckIn
            onStartTherapy={(data) => {
              console.log('Therapy session started:', data);
              setLocation('/session');
            }}
          />
        </div>
      </div>
    </div>
  );
}