import { useState, useEffect } from 'react';
import { Play, Shuffle, SkipForward, Heart, Star, Zap, Music, Target, Headphones, Plus, Volume2 } from 'lucide-react';

interface Track {
  id: number;
  title: string;
  artist: string;
  duration: number;
  audioUrl: string;
  genre?: string;
  therapeutic_use?: string;
}

interface AIPlaylist {
  tracks: Track[];
  mood: string;
  totalDuration: number;
  message: string;
}

interface AIDJPageProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
}

export default function AIDJPage({ onPlayTrack, currentTrack }: AIDJPageProps) {
  const [currentPlaylist, setCurrentPlaylist] = useState<AIPlaylist | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedMood, setSelectedMood] = useState('focus');
  const [favorites, setFavorites] = useState<Track[]>([]);
  const [availableGenres, setAvailableGenres] = useState<string[]>([]);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  // Load favorites from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('neurotunes-favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  // Load available genres from actual music library
  useEffect(() => {
    const loadGenres = async () => {
      try {
        const response = await fetch('/api/genres');
        if (response.ok) {
          const genres = await response.json();
          setAvailableGenres(genres.slice(0, 12)); // Limit for horizontal display
        }
      } catch (error) {
        console.error('Failed to load genres:', error);
        // Fallback from VAD analysis data
        setAvailableGenres([
          'Classical', 'Electronic', 'Ambient', 'Focus', 'Energy', 'House', 
          'Instrumental', 'EDM', 'Pop', 'Baroque', 'Indie', 'Relaxation'
        ]);
      }
    };
    loadGenres();
  }, []);

  const therapeuticGoals = [
    { id: 'confidence_building', name: 'Confidence Building', icon: Star, description: 'Build self-assurance', count: 240 },
    { id: 'positivity', name: 'Positivity', icon: Heart, description: 'Positive mindset', count: 231 },
    { id: 'mood_elevation', name: 'Mood Elevation', icon: Zap, description: 'Lift your spirits', count: 224 },
    { id: 'leadership', name: 'Leadership', icon: Target, description: 'Lead with confidence', count: 220 },
    { id: 'empowerment', name: 'Empowerment', icon: Star, description: 'Feel empowered', count: 220 },
    { id: 'energy_boost', name: 'Energy Boost', icon: Zap, description: 'Increase vitality', count: 124 },
    { id: 'focus', name: 'Deep Focus', icon: Target, description: 'Enhanced concentration', count: 124 },
    { id: 'meditation', name: 'Meditation & Pain Management', icon: Heart, description: 'Mindful practice', count: 85 },
    { id: 'relaxation', name: 'Relaxation', icon: Volume2, description: 'Calm and unwind', count: 78 },
    { id: 'celebration', name: 'Celebration', icon: Music, description: 'Joyful moments', count: 216 }
  ];

  const generatePlaylist = async (mood: string, duration: number = 60) => {
    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai-dj/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          mood, 
          duration,
          genre: selectedGenre,
          therapeuticGoal: selectedGoal
        }),
      });

      if (response.ok) {
        const playlist = await response.json();
        setCurrentPlaylist(playlist);
      } else {
        console.error('Failed to generate playlist');
      }
    } catch (error) {
      console.error('Error generating playlist:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const generateSmartMix = async () => {
    if (!selectedGoal && !selectedGenre) return;
    
    const mood = selectedGoal === 'energy_boost' ? 'energy' : 
                 selectedGoal === 'focus' ? 'focus' : 
                 selectedGoal === 'relaxation' ? 'relaxation' : 'focus';
    
    await generatePlaylist(mood, 45);
  };

  const playFavorite = (track: Track) => {
    onPlayTrack(track);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      <div className="container mx-auto px-6 py-8">
        
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
              <Music className="w-6 h-6" />
            </div>
            <h1 className="text-3xl font-bold">AI DJ Studio</h1>
          </div>
          <p className="text-blue-200">Therapeutic playlist generation powered by VAD analysis and Camelot wheel mixing</p>
        </div>

        {/* Three Horizontal Sections */}
        <div className="space-y-8">
          
          {/* Favorites Section */}
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Heart className="w-6 h-6 text-red-400" />
                <h2 className="text-2xl font-semibold">Your Favorites</h2>

              </div>
              <button 
                onClick={() => favorites.length > 0 && generatePlaylist('favorites', 30)}
                className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 rounded-lg text-red-300 text-sm transition-colors"
                disabled={favorites.length === 0}
              >
                Mix Favorites
              </button>
            </div>

            <div className="overflow-x-auto">
              <div className="flex gap-4 pb-2" style={{ minWidth: 'fit-content' }}>
                {favorites.length === 0 ? (
                  <div className="flex-1 text-center py-12 text-slate-400">
                    <Heart className="w-12 h-12 mx-auto mb-3 opacity-30" />
                    <p>No favorite tracks yet</p>
                    <p className="text-sm">Heart tracks while listening to add them here</p>
                  </div>
                ) : (
                  favorites.slice(0, 8).map((track) => (
                    <div
                      key={track.id}
                      className="min-w-48 bg-slate-700/30 rounded-xl p-4 hover:bg-slate-700/50 cursor-pointer transition-colors group"
                      onClick={() => playFavorite(track)}
                    >
                      <div className="aspect-square bg-gradient-to-br from-red-400 to-pink-500 rounded-lg mb-3 flex items-center justify-center relative overflow-hidden">
                        <Music className="w-8 h-8 text-white" />
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Play className="w-6 h-6 text-white" />
                        </div>
                      </div>
                      <h3 className="font-medium text-sm mb-1 truncate">{track.title}</h3>
                      <p className="text-xs text-slate-400 truncate">{track.artist}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-red-300 bg-red-500/20 px-2 py-1 rounded">
                          Favorite
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Genres Section */}
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Headphones className="w-6 h-6 text-blue-400" />
                <h2 className="text-2xl font-semibold">Musical Genres</h2>

              </div>
              <button 
                onClick={() => selectedGenre && generatePlaylist('focus', 45)}
                className="px-4 py-2 bg-blue-500/20 hover:bg-blue-500/30 rounded-lg text-blue-300 text-sm transition-colors"
                disabled={!selectedGenre}
              >
                Generate Mix
              </button>
            </div>

            <div className="overflow-x-auto">
              <div className="flex gap-4 pb-2" style={{ minWidth: 'fit-content' }}>
                {availableGenres.map((genre, index) => (
                  <div
                    key={genre}
                    className={`min-w-40 rounded-xl p-4 cursor-pointer transition-all group ${
                      selectedGenre === genre 
                        ? 'bg-blue-500/30 border-2 border-blue-400' 
                        : 'bg-slate-700/30 hover:bg-slate-700/50 border-2 border-transparent'
                    }`}
                    onClick={() => setSelectedGenre(selectedGenre === genre ? null : genre)}
                  >
                    <div className="aspect-square bg-gradient-to-br from-blue-400 to-cyan-500 rounded-lg mb-3 flex items-center justify-center relative overflow-hidden">
                      <Music className="w-8 h-8 text-white" />
                      {selectedGenre === genre && (
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                          <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          </div>
                        </div>
                      )}
                    </div>
                    <h3 className="font-medium text-sm mb-1 text-center">{genre}</h3>
                    <p className="text-xs text-slate-400 text-center">Genre</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Therapeutic Goals Section */}
          <div className="bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Target className="w-6 h-6 text-green-400" />
                <h2 className="text-2xl font-semibold">Therapeutic Goals</h2>
                <span className="text-sm text-slate-400">Clinical applications</span>
              </div>
              <button 
                onClick={generateSmartMix}
                className="px-4 py-2 bg-green-500/20 hover:bg-green-500/30 rounded-lg text-green-300 text-sm transition-colors flex items-center gap-2"
                disabled={!selectedGoal}
              >
                <Zap className="w-4 h-4" />
                Smart Mix
              </button>
            </div>

            <div className="overflow-x-auto">
              <div className="flex gap-4 pb-2" style={{ minWidth: 'fit-content' }}>
                {therapeuticGoals.map((goal) => {
                  const IconComponent = goal.icon;
                  return (
                    <div
                      key={goal.id}
                      className={`min-w-52 rounded-xl p-4 cursor-pointer transition-all group ${
                        selectedGoal === goal.id 
                          ? 'bg-green-500/30 border-2 border-green-400' 
                          : 'bg-slate-700/30 hover:bg-slate-700/50 border-2 border-transparent'
                      }`}
                      onClick={() => setSelectedGoal(selectedGoal === goal.id ? null : goal.id)}
                    >
                      <div className="aspect-square bg-gradient-to-br from-green-400 to-emerald-500 rounded-lg mb-3 flex items-center justify-center relative overflow-hidden">
                        <IconComponent className="w-8 h-8 text-white" />
                        {selectedGoal === goal.id && (
                          <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                            <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            </div>
                          </div>
                        )}
                      </div>
                      <h3 className="font-medium text-sm mb-1">{goal.name}</h3>
                      <p className="text-xs text-slate-400 mb-2">{goal.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-green-300 bg-green-500/20 px-2 py-1 rounded">
                          {goal.count} tracks
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

        </div>

        {/* Generated Playlist Section */}
        {currentPlaylist && (
          <div className="mt-8 bg-slate-800/40 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <Shuffle className="w-6 h-6 text-purple-400" />
                <h2 className="text-2xl font-semibold">Generated Playlist</h2>
                <span className="text-sm text-slate-400">({currentPlaylist.tracks.length} tracks • {currentPlaylist.totalDuration}min)</span>
              </div>
              <div className="flex gap-2">
                <button 
                  onClick={() => generatePlaylist(selectedMood, 45)}
                  className="px-4 py-2 bg-purple-500/20 hover:bg-purple-500/30 rounded-lg text-purple-300 text-sm transition-colors flex items-center gap-2"
                  disabled={isGenerating}
                >
                  <Shuffle className="w-4 h-4" />
                  Regenerate
                </button>
                <button 
                  onClick={() => currentPlaylist.tracks[0] && onPlayTrack(currentPlaylist.tracks[0])}
                  className="px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg text-white text-sm transition-colors flex items-center gap-2"
                >
                  <Play className="w-4 h-4" />
                  Play All
                </button>
              </div>
            </div>

            <div className="space-y-2 max-h-80 overflow-y-auto">
              {currentPlaylist.tracks.map((track, index) => (
                <div
                  key={track.id}
                  className="flex items-center gap-4 p-3 bg-slate-700/30 hover:bg-slate-700/50 rounded-lg cursor-pointer transition-colors group"
                  onClick={() => onPlayTrack(track)}
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-purple-400 to-blue-500 rounded flex items-center justify-center text-white text-sm font-semibold">
                    ♪
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-sm">{track.title}</h3>
                    <p className="text-xs text-slate-400">{track.artist}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">{Math.floor(track.duration / 60)}:{String(track.duration % 60).padStart(2, '0')}</span>
                    <Play className="w-4 h-4 text-slate-400 group-hover:text-white transition-colors" />
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <p className="text-sm text-blue-200">{currentPlaylist.message}</p>
            </div>
          </div>
        )}

        {isGenerating && (
          <div className="mt-8 text-center">
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-slate-700/50 rounded-lg">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-400"></div>
              <span className="text-slate-300">Generating therapeutic playlist...</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}