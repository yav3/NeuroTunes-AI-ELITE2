import React, { useState, useEffect } from 'react';
import { Play, Pause, SkipForward, Heart, Volume2 } from 'lucide-react';
import { useAudio } from '../context/AudioContext';

interface MoodOption {
  id: string;
  label: string;
  description: string;
  energy: number;
  valence: number;
}

const MOOD_OPTIONS: MoodOption[] = [
  { id: 'Focus', label: 'Focus', description: 'Target', energy: 6, valence: 7 },
  { id: 'Energy Boost', label: 'Energy Boost', description: 'Power', energy: 9, valence: 8 },
  { id: 'Sleep', label: 'Sleep', description: 'Rest', energy: 1, valence: 5 },
  { id: 'Workout', label: 'Workout', description: 'Fitness', energy: 10, valence: 8 }
];

interface Track {
  id: number;
  title: string;
  artist?: string;
  audioUrl?: string;
  mood?: string;
  therapeuticTags?: string[];
}

interface EmotionsPageProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
  isPlaying?: boolean;
  onTogglePlay?: () => void;
  onNextTrack?: () => void;
}

export default function EmotionsPage() {
  const { playTrack, currentTrack, isPlaying, togglePlayPause } = useAudio();
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [moodTracks, setMoodTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [showPlayer, setShowPlayer] = useState(false);

  const fetchMoodTracks = async (moodId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/tracks/mood/${moodId}`);
      if (response.ok) {
        const tracks = await response.json();
        setMoodTracks(tracks);
      } else {
        console.error('Failed to fetch mood tracks');
        setMoodTracks([]);
      }
    } catch (error) {
      console.error('Error fetching mood tracks:', error);
      setMoodTracks([]);
    } finally {
      setLoading(false);
    }
  };

  const handleMoodSelect = (moodId: string) => {
    setSelectedMood(moodId);
    fetchMoodTracks(moodId);
  };

  const handleTrackPlay = (track: Track, index: number) => {
    setCurrentTrackIndex(index);
    setShowPlayer(true);
    playTrack(track);
  };

  const handleNextTrack = () => {
    if (moodTracks.length === 0) return;
    const nextIndex = (currentTrackIndex + 1) % moodTracks.length;
    setCurrentTrackIndex(nextIndex);
    playTrack(moodTracks[nextIndex]);
  };

  const addToFavorites = (track: Track) => {
    const favorites = JSON.parse(localStorage.getItem('neurotunes-favorites') || '[]');
    const isAlreadyFavorite = favorites.some((fav: Track) => fav.id === track.id);
    
    if (!isAlreadyFavorite) {
      favorites.push(track);
      localStorage.setItem('neurotunes-favorites', JSON.stringify(favorites));
      console.log('Added to favorites');
    }
  };

  return (
    <div style={{ 
      padding: '20px',
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      minHeight: '100vh',
      color: 'white'
    }}>
      <div style={{ maxWidth: '800px', margin: '0 auto' }}>
        <h1 style={{ 
          fontSize: '32px', 
          fontWeight: 'bold', 
          marginBottom: '8px',
          textAlign: 'center'
        }}>
          How are you feeling?
        </h1>
        <p style={{ 
          fontSize: '16px', 
          opacity: 0.8, 
          marginBottom: '32px',
          textAlign: 'center'
        }}>
          Select your current mood for personalized therapeutic music
        </p>

        {/* Mood Selection - Horizontal Layout */}
        <div style={{ 
          overflowX: 'auto',
          marginBottom: '32px',
          paddingBottom: '8px'
        }}>
          <div style={{
            display: 'flex',
            gap: '16px',
            minWidth: 'fit-content',
            paddingBottom: '8px'
          }}>
          {MOOD_OPTIONS.map((mood) => (
            <button
              key={mood.id}
              onClick={() => handleMoodSelect(mood.id)}
              style={{
                minWidth: '280px',
                padding: '20px',
                borderRadius: '12px',
                border: selectedMood === mood.id ? '2px solid #3b82f6' : '1px solid rgba(255,255,255,0.2)',
                background: selectedMood === mood.id 
                  ? 'rgba(59, 130, 246, 0.2)' 
                  : 'rgba(255,255,255,0.05)',
                color: 'white',
                textAlign: 'left',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                transform: selectedMood === mood.id ? 'scale(1.02)' : 'scale(1)',
                boxShadow: selectedMood === mood.id ? '0 8px 25px rgba(59, 130, 246, 0.3)' : 'none'
              }}
            >
              <h3 style={{ 
                fontSize: '18px', 
                fontWeight: '600', 
                marginBottom: '8px' 
              }}>
                {mood.label}
              </h3>
              <p style={{ 
                fontSize: '14px', 
                opacity: 0.8, 
                marginBottom: '12px' 
              }}>
                {mood.description}
              </p>
              <div style={{ display: 'flex', gap: '12px', fontSize: '12px', opacity: 0.6 }}>
                <span>Energy: {mood.energy}/10</span>
                <span>Positivity: {mood.valence}/10</span>
              </div>
            </button>
          ))}
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <div style={{ 
              width: '40px', 
              height: '40px', 
              border: '3px solid rgba(255,255,255,0.3)',
              borderTop: '3px solid #3b82f6',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto 16px'
            }}></div>
            <p>Finding your perfect tracks...</p>
          </div>
        )}

        {/* Mood Tracks Display */}
        {selectedMood && !loading && (
          <div>
            <h2 style={{ 
              fontSize: '24px', 
              fontWeight: '600', 
              marginBottom: '16px',
              textAlign: 'center'
            }}>
              {MOOD_OPTIONS.find(m => m.id === selectedMood)?.label} Music
            </h2>
            
            {moodTracks.length > 0 ? (
              <div style={{ 
                display: 'grid', 
                gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
                gap: '16px' 
              }}>
                {moodTracks.map((track, index) => (
                  <div
                    key={track.id}
                    onClick={() => handleTrackPlay(track, index)}
                    style={{
                      padding: '16px',
                      borderRadius: '8px',
                      background: 'rgba(255,255,255,0.05)',
                      border: '1px solid rgba(255,255,255,0.1)',
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(255,255,255,0.1)';
                      e.currentTarget.style.transform = 'translateY(-2px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'rgba(255,255,255,0.05)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <h4 style={{ 
                      fontSize: '16px', 
                      fontWeight: '600', 
                      marginBottom: '4px' 
                    }}>
                      {track.title}
                    </h4>
                    <p style={{ 
                      fontSize: '14px', 
                      opacity: 0.7, 
                      marginBottom: '8px' 
                    }}>
                      {track.artist || 'Unknown Artist'}
                    </p>
                    {track.therapeuticTags && track.therapeuticTags.length > 0 && (
                      <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                        {track.therapeuticTags.slice(0, 3).map((tag, index) => (
                          <span
                            key={index}
                            style={{
                              fontSize: '11px',
                              padding: '2px 8px',
                              borderRadius: '12px',
                              background: 'rgba(59, 130, 246, 0.2)',
                              color: '#60a5fa'
                            }}
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ 
                textAlign: 'center', 
                padding: '40px',
                background: 'rgba(255,255,255,0.05)',
                borderRadius: '8px',
                border: '1px solid rgba(255,255,255,0.1)'
              }}>
                <p style={{ opacity: 0.7 }}>
                  No tracks found for this mood. Try selecting a different mood.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Minified Music Player */}
        {showPlayer && currentTrack && (
          <div style={{
            position: 'fixed',
            bottom: '0',
            left: '0',
            right: '0',
            background: 'rgba(15, 23, 42, 0.95)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            borderBottom: 'none',
            padding: '12px 20px',
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
            zIndex: 1000
          }}>
            {/* Album Art */}
            <div style={{
              width: '48px',
              height: '48px',
              borderRadius: '8px',
              background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              fontSize: '14px',
              fontWeight: '600',
              flexShrink: 0
            }}>
              {currentTrack.title.substring(0, 2).toUpperCase()}
            </div>

            {/* Track Info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <h4 style={{
                fontSize: '14px',
                fontWeight: '600',
                color: 'white',
                margin: 0,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}>
                {currentTrack.title}
              </h4>
              <p style={{
                fontSize: '12px',
                color: '#94a3b8',
                margin: 0,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}>
                {currentTrack.artist || 'Unknown Artist'}
              </p>
            </div>

            {/* Controls */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px'
            }}>
              <button
                onClick={() => {
                  // Add to favorites functionality would go here
                  console.log('Added to favorites:', currentTrack?.title);
                }}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#94a3b8',
                  cursor: 'pointer',
                  padding: '8px',
                  borderRadius: '6px',
                  transition: 'color 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = '#f87171';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = '#94a3b8';
                }}
              >
                <Heart style={{ width: '18px', height: '18px' }} />
              </button>

              <button
                onClick={onTogglePlay}
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
                  border: 'none',
                  color: 'white',
                  padding: '10px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'transform 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'scale(1.05)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                }}
              >
                {isPlaying ? 
                  <Pause style={{ width: '18px', height: '18px' }} /> : 
                  <Play style={{ width: '18px', height: '18px' }} />
                }
              </button>

              <button
                onClick={handleNextTrack}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#94a3b8',
                  cursor: 'pointer',
                  padding: '8px',
                  borderRadius: '6px',
                  transition: 'color 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = 'white';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = '#94a3b8';
                }}
              >
                <SkipForward style={{ width: '18px', height: '18px' }} />
              </button>

              <button
                onClick={() => setShowPlayer(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#94a3b8',
                  cursor: 'pointer',
                  padding: '8px',
                  fontSize: '18px'
                }}
              >
                ×
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}