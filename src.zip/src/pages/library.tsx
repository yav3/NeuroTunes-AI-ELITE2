import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Home as HomeIcon, 
  Music, 
  Heart,
  Settings, 
  Shield,
  Brain,
  Library,
  Play,
  Pause,
  RefreshCw
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Track {
  id: number;
  title: string;
  artist: string;
  audioUrl: string | null;
  duration?: number;
  mood?: string;
  album?: string;
}

export default function LibraryPage() {
  const [, setLocation] = useLocation();
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const { toast } = useToast();

  const { data: tracks = [], isLoading: tracksLoading, refetch } = useQuery({
    queryKey: ["/api/tracks"],
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("/api/sync/supabase", "POST", {});
    },
    onSuccess: (data) => {
      toast({
        title: "Sync Complete",
        description: `Synced ${data.syncedCount} tracks from Supabase`,
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Sync Failed",
        description: "Could not sync music from Supabase",
        variant: "destructive",
      });
    },
  });

  const sidebarItems = [
    { icon: HomeIcon, label: "Dashboard", path: "/" },
    { icon: Library, label: "My Library", path: "/library", active: true },
    { icon: Heart, label: "Wellness", path: "/wellness" },
    { icon: Shield, label: "Admin", path: "/admin" },
    { icon: Settings, label: "Settings", path: "/settings" },
  ];

  const handleNavigation = (path: string) => {
    setLocation(path);
  };

  const handlePlayTrack = (track: Track) => {
    setCurrentTrack(track);
    setIsPlaying(true);
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Sidebar */}
      <div className="fixed left-0 top-0 h-full w-64 bg-black border-r border-white/20">
        {/* Header */}
        <div className="p-6 border-b border-white/20">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-white">AI Music Wellness</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-2">
          {sidebarItems.map((item) => (
            <button
              key={item.label}
              onClick={() => handleNavigation(item.path)}
              className={cn(
                "w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors",
                item.active
                  ? "bg-blue-600 text-white"
                  : "text-white/70 hover:bg-white/10 hover:text-white"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="absolute bottom-6 left-4 right-4">
          <div className="flex items-center space-x-3 p-3 rounded-lg bg-white/10">
            <div className="w-2 h-2 rounded-full bg-green-400"></div>
            <span className="text-sm text-white">Brian</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="ml-64 p-8">
        <div className="max-w-4xl space-y-6">
          <Card className="bg-black border-white/20 rounded-2xl">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-white">My Music Library</CardTitle>
                <Button
                  onClick={() => syncMutation.mutate()}
                  disabled={syncMutation.isPending}
                  variant="outline"
                  size="sm"
                  className="bg-blue-600/20 border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                >
                  {syncMutation.isPending ? (
                    <RefreshCw className="w-4 h-4 animate-spin mr-2" />
                  ) : (
                    <RefreshCw className="w-4 h-4 mr-2" />
                  )}
                  Sync from Supabase
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {tracksLoading ? (
                <div className="text-center py-8">
                  <div className="text-white/70">Loading music library...</div>
                </div>
              ) : tracks.length === 0 ? (
                <div className="text-center py-8">
                  <div className="text-white/70 mb-4">No tracks found in your library</div>
                  <Button
                    onClick={() => syncMutation.mutate()}
                    disabled={syncMutation.isPending}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    Sync Music from Supabase
                  </Button>
                </div>
              ) : (
                <div className="grid gap-4">
                  {(tracks as Track[]).map((track) => (
                    <div key={track.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 rounded-lg bg-blue-600 flex items-center justify-center">
                          <Music className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <p className="text-white font-medium">{track.title}</p>
                          <p className="text-white/70 text-sm">{track.artist}</p>
                          {track.album && (
                            <p className="text-white/50 text-xs">{track.album}</p>
                          )}
                          {track.mood && (
                            <Badge variant="outline" className="mt-1 border-blue-500/50 text-blue-400 bg-blue-500/10">
                              {track.mood}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button
                        onClick={() => handlePlayTrack(track)}
                        variant="ghost"
                        size="sm"
                        className="text-white/70 hover:bg-white/10"
                      >
                        <Play className="w-5 h-5" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Music Player */}
      {currentTrack && (
        <div className="fixed bottom-0 left-64 right-0 bg-slate-800/95 backdrop-blur-xl border-t border-slate-700/50 p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 rounded-lg bg-blue-600 flex items-center justify-center">
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="text-white font-medium">{currentTrack.title}</p>
                <p className="text-slate-300 text-sm">{currentTrack.artist}</p>
              </div>
              <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsPlaying(!isPlaying)}
                className="text-slate-300 hover:bg-slate-700/50"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}