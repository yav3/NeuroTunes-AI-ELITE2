import React, { useState, useEffect } from 'react';
import { useAudio } from '../context/AudioContext';

interface Track {
  id: number;
  title: string;
  artist?: string;
  genre?: string;
  genres?: string[];
  therapeuticTags?: string[];
  coverUrl?: string;
  audioUrl?: string;
  filename?: string;
}

interface TherapeuticSection {
  goal: string;
  description: string;
  albumArt: string;
  genres: {
    name: string;
    tracks: Track[];
  }[];
}

async function fetchTracksByGoal(goal: string): Promise<Track[]> {
  const res = await fetch(`/api/tracks/mood/${goal}`);
  if (!res.ok) throw new Error(`Failed to fetch ${goal} tracks`);
  return await res.json();
}

// Group tracks by genre
function groupTracksByGenre(tracks: Track[]): { name: string; tracks: Track[] }[] {
  const genreMap = new Map<string, Track[]>();
  
  tracks.forEach(track => {
    // Handle both single genre string and genres array
    const genres = track.genres ? track.genres : (track.genre ? [track.genre] : ['Instrumental']);
    
    genres.forEach(genre => {
      const cleanGenre = genre.trim() || 'Instrumental';
      if (!genreMap.has(cleanGenre)) {
        genreMap.set(cleanGenre, []);
      }
      genreMap.get(cleanGenre)!.push(track);
    });
  });
  
  return Array.from(genreMap.entries())
    .map(([name, tracks]) => ({ name, tracks }))
    .filter(genre => genre.tracks.length > 0)
    .sort((a, b) => b.tracks.length - a.tracks.length) // Sort by track count
    .slice(0, 8); // Limit to top 8 genres to prevent UI overflow
}

export default function HomePageTrending() {
  const { play } = useAudio();
  const [sections, setSections] = useState<TherapeuticSection[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    
    const loadTherapeuticSections = async () => {
      try {
        setLoading(true);
        
        // Authentic therapeutic goals from July 8th inventory
        const therapeuticGoals = [
          { 
            goal: 'focus', 
            description: 'Concentration and mental clarity',
            albumArt: '/api/art/Battle%20Song%20Edm%20Focus'
          },
          { 
            goal: 'mood_boost', 
            description: 'Emotional enhancement and positivity',
            albumArt: '/api/art/Beautiful%20Babe'
          },
          { 
            goal: 'relaxation', 
            description: 'Stress relief and calm',
            albumArt: '/api/art/Breathe%20through%20It'
          },
          { 
            goal: 'meditation', 
            description: 'Mindfulness and inner peace',
            albumArt: '/api/art/Ethereal%20Composition%20Lumie%20re%20Suspendue'
          },
          { 
            goal: 'energy_boost', 
            description: 'Vitality and motivation',
            albumArt: '/api/art/Beast%20Mode'
          }
        ];

        const sectionsData = await Promise.all(
          therapeuticGoals.map(async ({ goal, description, albumArt }) => {
            try {
              const tracks = await fetchTracksByGoal(goal);
              const genres = groupTracksByGenre(tracks.slice(0, 100)); // Increased limit for better population
              return { goal, description, albumArt, genres };
            } catch (error) {
              console.warn(`Failed to load ${goal} tracks:`, error);
              return { goal, description, albumArt, genres: [] };
            }
          })
        );

        if (mounted) {
          setSections(sectionsData.filter(section => section.genres.length > 0));
        }
      } catch (error) {
        console.error('Failed to load therapeutic sections:', error);
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    loadTherapeuticSections();
    return () => { mounted = false; };
  }, []);

  const handlePlay = (track: Track, allTracks: Track[]) => {
    console.log('[TRENDING] Play button clicked for track:', track.title);
    console.log('[TRENDING] Track list length:', allTracks.length);
    play(track, allTracks).catch(err => {
      console.error(`[TRENDING] Play failed: ${track.title}`, err);
      alert(`Cannot play: ${track.title}`);
    });
  };

  if (loading) {
    return (
      <div className="w-full space-y-6">
        <div className="text-xl font-medium text-white">Trending</div>
        <div className="text-blue-300 text-center py-8">Loading therapeutic music sections...</div>
      </div>
    );
  }

  return (
    <div className="w-full space-y-8">
      <div className="text-xl font-medium text-white">Trending</div>
      
      {sections.map(section => (
        <div key={section.goal} className="space-y-4">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-xl overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 flex-shrink-0">
              <img 
                src={section.albumArt}
                alt={section.goal}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                }}
              />
            </div>
            <div className="flex-1">
              <h2 className="text-lg font-semibold text-white capitalize">{section.goal.replace('_', ' ')}</h2>
              <p className="text-sm text-blue-200">{section.description}</p>
            </div>
          </div>
          
          {/* For Focus section, show as single genre without subdivisions */}
          {section.goal === 'focus' ? (
            <div className="space-y-3">
              <h3 className="text-md font-medium text-blue-100">Focus</h3>
              
              <div className="overflow-x-auto pb-4 -mx-4 px-4" style={{WebkitOverflowScrolling: 'touch'}}>
                <div className="flex gap-4 w-max">
                  {section.genres.flatMap(g => g.tracks).map((track, trackIndex) => (
                    <div key={`${track.id}-${trackIndex}-${track.title}`} className="w-40 flex-shrink-0 group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all">
                      <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                        <img 
                          src={track.coverUrl || `/api/art/${encodeURIComponent(track.title)}`}
                          alt={track.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                          }}
                        />
                        <button 
                          onClick={() => handlePlay(track, section.genres.flatMap(g => g.tracks))}
                          className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                            <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                          </div>
                        </button>
                      </div>
                      <h4 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{track.title}</h4>
                      <p className="text-xs text-blue-200 line-clamp-1">
                        {track.artist ?? 'Neural Positive Music'}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* For other therapeutic goals, show genre subdivisions */
            section.genres.map(genre => (
              <div key={genre.name} className="space-y-3">
                <h3 className="text-md font-medium text-blue-100">{genre.name}</h3>
                
                <div className="overflow-x-auto pb-4 -mx-4 px-4" style={{WebkitOverflowScrolling: 'touch'}}>
                  <div className="flex gap-4 w-max">
                    {genre.tracks.map((track, trackIndex) => (
                      <div key={`${track.id}-${trackIndex}-${track.title}`} className="w-40 flex-shrink-0 group bg-white/5 rounded-xl p-3 border border-white/10 hover:bg-white/10 transition-all">
                        <div className="relative aspect-square rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 mb-3">
                          <img 
                            src={track.coverUrl || `/api/art/${encodeURIComponent(track.title)}`}
                            alt={track.title}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.style.display = 'none';
                            }}
                          />
                          <button 
                            onClick={() => handlePlay(track, genre.tracks)}
                            className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                              <div className="w-0 h-0 border-l-[8px] border-l-black border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
                            </div>
                          </button>
                        </div>
                        <h4 className="font-medium text-white text-sm leading-tight line-clamp-2 mb-1">{track.title}</h4>
                        <p className="text-xs text-blue-200 line-clamp-1">
                          {track.artist ?? 'Neural Positive Music'}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      ))}
    </div>
  );
}