import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

// Simple icon replacements for lucide-react (text-based for compatibility)
const User = () => <span>P</span>;
const Settings = () => <span>S</span>;
const Heart = () => <span>H</span>;
const BarChart3 = () => <span>A</span>;
const Shield = () => <span>Sh</span>;
const LogOut = () => <span>L</span>;
const Clock = () => <span>C</span>;
const TrendingUp = () => <span>T</span>;
const Music = () => <span>M</span>;
const Calendar = () => <span>Cal</span>;
const Play = () => <span>Play</span>;
const Wifi = () => <span>W</span>;


interface UserData {
  firstName?: string;
  lastName?: string;
  email?: string;
  id?: string;
}

interface UserAnalytics {
  totalHours: number;
  totalSessions: number;
  favoriteGenres: { genre: string; count: number }[];
  preferredTimeOfDay: string;
  therapeuticGoalProgress: { goal: string; progress: number; sessions: number }[];
  weeklyActivity: { day: string; hours: number }[];
}

export default function Profile() {
  const { user } = useAuth() as { user?: UserData };
  const [activeTab, setActiveTab] = useState<'overview' | 'analytics' | 'streaming' | 'settings'>('overview');

  const { data: analytics, isLoading } = useQuery<UserAnalytics>({
    queryKey: ['/api/user/analytics'],
    retry: false,
  });

  const { data: progress } = useQuery({
    queryKey: ['/api/user/progress'],
    retry: false,
  });

  const { data: favorites } = useQuery({
    queryKey: ['/api/user/favorites'],
    retry: false,
  });

  const formatGoalName = (goal: string) => {
    const goalMap: Record<string, string> = {
      'focus': 'Focus Enhancement',
      'mood_boost': 'Mood Enhancement',
      'relaxation': 'Relaxation & Stress Relief',
      'meditation': 'Meditation & Pain Management',
      'energy_boost': 'Energy & Motivation'
    };
    return goalMap[goal] || goal;
  };

  const getTimeIcon = (timeOfDay: string) => {
    switch (timeOfDay) {
      case 'morning': return '🌅';
      case 'afternoon': return '☀️';
      case 'evening': return '🌆';
      case 'night': return '🌙';
      default: return '🎵';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0c1929] to-[#0a2a7a] text-white pb-24">
        <div className="p-6 flex items-center justify-center h-64">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-blue-400 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-blue-200">Loading your profile...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0c1929] to-[#0a2a7a] text-white pb-24">
      <div className="p-6">
        {/* Page Header */}
        <header className="mb-6 pt-4">
          <h1 className="text-2xl font-semibold text-white tracking-tight">Profile</h1>
          <p className="text-blue-200/80 text-sm mt-1">NeuroTunes</p>
        </header>

        {/* User Header */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <User size={32} className="text-white" />
          </div>
          <h1 className="text-2xl font-bold mb-2">
            {user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : 'User Profile'}
          </h1>
          <p className="text-blue-200">{user?.email || 'neurotunes@example.com'}</p>
        </div>

        {/* Tab Navigation */}
        <div className="flex bg-white/10 rounded-xl p-1 mb-6">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'overview' 
                ? 'bg-blue-600 text-white' 
                : 'text-blue-200 hover:text-white'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'analytics' 
                ? 'bg-blue-600 text-white' 
                : 'text-blue-200 hover:text-white'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => setActiveTab('streaming')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'streaming' 
                ? 'bg-blue-600 text-white' 
                : 'text-blue-200 hover:text-white'
            }`}
          >
            <Wifi size={14} className="inline mr-1" />
            Edge
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
              activeTab === 'settings' 
                ? 'bg-blue-600 text-white' 
                : 'text-blue-200 hover:text-white'
            }`}
          >
            Settings
          </button>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <>
            {/* Quick Stats */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-white/10 backdrop-blur rounded-xl p-4 text-center border border-white/20">
                <BarChart3 size={24} className="mx-auto mb-2 text-blue-400" />
                <div className="text-xl font-bold">{analytics?.totalHours || 0}h</div>
                <div className="text-xs text-blue-200">Listening Hours</div>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-xl p-4 text-center border border-white/20">
                <Music size={24} className="mx-auto mb-2 text-green-400" />
                <div className="text-xl font-bold">{analytics?.totalSessions || 0}</div>
                <div className="text-xs text-blue-200">Sessions</div>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-xl p-4 text-center border border-white/20">
                <Clock size={24} className="mx-auto mb-2 text-purple-400" />
                <div className="text-lg font-bold">{getTimeIcon(analytics?.preferredTimeOfDay || 'evening')}</div>
                <div className="text-xs text-blue-200">Best Time</div>
              </div>
            </div>

            {/* Therapeutic Progress */}
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 mb-6 border border-white/20">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <TrendingUp size={20} className="text-blue-400" />
                Your Therapeutic Progress
              </h2>
              <div className="space-y-4">
                {analytics?.therapeuticGoalProgress?.length ? analytics.therapeuticGoalProgress.map((goal) => (
                  <div key={goal.goal}>
                    <div className="flex justify-between text-sm mb-2">
                      <span>{formatGoalName(goal.goal)}</span>
                      <span className="text-blue-200">{goal.progress}% • {goal.sessions} sessions</span>
                    </div>
                    <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                        style={{ width: `${goal.progress}%` }}
                      />
                    </div>
                  </div>
                )) : (
                  <div className="text-center text-blue-200 py-8">
                    <Music size={48} className="mx-auto mb-4 text-blue-400" />
                    <p>Start listening to see your therapeutic progress!</p>
                    <p className="text-sm text-blue-300 mt-2">Your journey begins with your first session.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Favorite Tracks */}
            {favorites && favorites.length > 0 && (
              <div className="bg-white/10 backdrop-blur rounded-xl p-6 mb-6 border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold flex items-center gap-2">
                    <Heart size={20} className="text-red-400" />
                    Favorites
                  </h2>
                  <Button
                    onClick={() => {
                      // Create a playlist from favorites and start playing
                      if (favorites && favorites.length > 0) {
                        const firstTrack = favorites[0];
                        const audio = new Audio(`/api/stream/${encodeURIComponent(firstTrack.title.replace(/\.[^/.]+$/, ''))}`);
                        audio.play().catch(console.error);
                      }
                    }}
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    <Play size={16} className="mr-1" />
                    Play All
                  </Button>
                </div>
                <div className="space-y-3">
                  {favorites.slice(0, 10).map((track: any, index: number) => (
                    <div key={track.id || index} className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                      <div className="w-12 h-12 rounded-lg overflow-hidden bg-gradient-to-br from-blue-600 to-purple-600 flex-shrink-0">
                        <img 
                          src={`/api/art/${encodeURIComponent(track.title)}`}
                          alt={track.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                          }}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-white truncate">{track.title}</div>
                        <div className="text-sm text-blue-200 truncate">{track.artist || 'Unknown Artist'}</div>
                      </div>
                      <div className="text-xs text-blue-300">
                        {track.genre && <span className="bg-blue-600/30 px-2 py-1 rounded">{track.genre}</span>}
                      </div>
                    </div>
                  ))}
                  {favorites.length > 10 && (
                    <div className="text-center pt-3">
                      <p className="text-sm text-blue-200">And {favorites.length - 10} more favorites...</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Favorite Genres */}
            {analytics?.favoriteGenres?.length > 0 && (
              <div className="bg-white/10 backdrop-blur rounded-xl p-6 mb-6 border border-white/20">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Heart size={20} className="text-pink-400" />
                  Your Music Preferences
                </h2>
                <div className="space-y-3">
                  {analytics.favoriteGenres.map((genre, index) => (
                    <div key={genre.genre} className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg flex items-center justify-center text-white text-sm font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="font-medium">{genre.genre}</div>
                        <div className="text-sm text-blue-200">{genre.count} sessions</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <>
            {/* Weekly Activity */}
            {analytics?.weeklyActivity?.length > 0 && (
              <div className="bg-white/10 backdrop-blur rounded-xl p-6 mb-6 border border-white/20">
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Calendar size={20} className="text-green-400" />
                  Weekly Activity
                </h2>
                <div className="space-y-3">
                  {analytics.weeklyActivity.map((day) => (
                    <div key={day.day} className="flex items-center justify-between">
                      <span className="text-sm">{new Date(day.day).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' })}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-white/20 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-green-500 to-blue-500 transition-all"
                            style={{ width: `${Math.min(100, (day.hours / 2) * 100)}%` }}
                          />
                        </div>
                        <span className="text-sm font-medium w-12 text-right">{day.hours}h</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Listening Patterns */}
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 mb-6 border border-white/20">
              <h2 className="text-lg font-semibold mb-4">Listening Insights</h2>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <span>Preferred Time</span>
                  <span className="font-medium capitalize">{analytics?.preferredTimeOfDay || 'Evening'} {getTimeIcon(analytics?.preferredTimeOfDay || 'evening')}</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <span>Average Session</span>
                  <span className="font-medium">{analytics?.totalSessions ? Math.round((analytics.totalHours * 60) / analytics.totalSessions) : 0} minutes</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <span>Total Listening Time</span>
                  <span className="font-medium">{analytics?.totalHours || 0} hours</span>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Edge Streaming Tab */}
        {activeTab === 'streaming' && (
          <div className="space-y-6">
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 border border-white/20">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Wifi size={20} className="text-blue-400" />
                Edge Streaming System
              </h2>
              <p className="text-blue-200 text-sm mb-6">
                Progressive music loading system for optimized streaming performance.
              </p>
              
              {/* Streaming Stats */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-white/5 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-green-400 mb-1">Active</div>
                  <div className="text-sm text-blue-200">Streaming Status</div>
                </div>
                <div className="bg-white/5 rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-blue-400 mb-1">2.8GB</div>
                  <div className="text-sm text-blue-200">Music Library</div>
                </div>
              </div>
              
              <div className="text-center text-blue-200">
                <p className="mb-2">Full therapeutic music library available</p>
                <p className="text-sm">653 tracks across all therapeutic categories</p>
              </div>
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <>
            <div className="bg-white/10 backdrop-blur rounded-xl p-6 mb-6 border border-white/20">
              <h2 className="text-lg font-semibold mb-4">Account Settings</h2>
              <div className="space-y-3">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-white/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <User size={20} className="text-blue-400" />
                    <span>Profile Information</span>
                  </div>
                  <div className="text-blue-200">›</div>
                </button>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-white/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <Settings size={20} className="text-blue-400" />
                    <span>Audio Preferences</span>
                  </div>
                  <div className="text-blue-200">›</div>
                </button>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-white/10 transition-colors">
                  <div className="flex items-center gap-3">
                    <Shield size={20} className="text-blue-400" />
                    <span>Privacy & Data</span>
                  </div>
                  <div className="text-blue-200">›</div>
                </button>
              </div>
            </div>

            {/* Logout */}
            <Button
              onClick={() => window.location.href = '/api/logout'}
              variant="outline"
              className="w-full bg-transparent border-red-500/50 text-red-400 hover:bg-red-600 hover:text-white hover:border-red-600"
            >
              <LogOut size={20} className="mr-2" />
              Sign Out
            </Button>
          </>
        )}
      </div>
    </div>
  );
}