import React, { useState, useCallback, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, Music, CheckCircle, AlertCircle, X, Wifi, WifiOff } from 'lucide-react';

interface UploadFile {
  file: File;
  id: string;
  status: 'pending' | 'uploading' | 'processing' | 'success' | 'error';
  progress: number;
  error?: string;
  title?: string;
  duration?: number;
  uploadStartTime?: number;
}

interface UploadResponse {
  success: boolean;
  trackId?: string;
  duration?: number;
  error?: string;
}

export default function UploadPage() {
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStats, setUploadStats] = useState({ total: 0, success: 0, failed: 0 });
  const [connectionStatus, setConnectionStatus] = useState<'online' | 'offline' | 'checking'>('checking');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortControllersRef = useRef<Map<string, AbortController>>(new Map());

  // Check backend connectivity on component mount
  React.useEffect(() => {
    checkConnectionStatus();
  }, []);

  const checkConnectionStatus = async () => {
    try {
      const response = await fetch('/api/health', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      if (response.ok) {
        setConnectionStatus('online');
      } else {
        setConnectionStatus('offline');
      }
    } catch (error) {
      console.error('Connection check failed:', error);
      setConnectionStatus('offline');
    }
  };

  // Get authentication token (handles multiple storage methods)
  const getAuthToken = () => {
    // Check localStorage first
    let token = localStorage.getItem('auth_token');
    
    // Check sessionStorage
    if (!token) {
      token = sessionStorage.getItem('auth_token');
    }
    
    // Check cookies
    if (!token) {
      const cookieMatch = document.cookie.split('; ').find(row => row.startsWith('auth_token='));
      token = cookieMatch ? cookieMatch.split('=')[1] : null;
    }
    
    // Check URL params (for development)
    if (!token) {
      const urlParams = new URLSearchParams(window.location.search);
      token = urlParams.get('token');
    }
    
    return token;
  };

  const validateFile = (file: File): string | null => {
    // Check file type
    if (!file.type.startsWith('audio/') && !file.name.toLowerCase().endsWith('.mp3')) {
      return 'Only audio files are supported';
    }
    
    // Check file size (50MB limit)
    const maxSize = 50 * 1024 * 1024; // 50MB
    if (file.size > maxSize) {
      return 'File size must be less than 50MB';
    }
    
    // Check filename
    if (file.name.length > 255) {
      return 'Filename is too long';
    }
    
    return null;
  };

  const handleFileSelect = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const validFiles: UploadFile[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const error = validateFile(file);
      if (error) {
        errors.push(`${file.name}: ${error}`);
      } else {
        validFiles.push({
          file,
          id: crypto.randomUUID(),
          status: 'pending',
          progress: 0,
          title: file.name.replace(/\.[^/.]+$/, "") // Remove extension
        });
      }
    });

    if (errors.length > 0) {
      alert(`Some files were rejected:\n${errors.join('\n')}`);
    }

    setUploadFiles(prev => [...prev, ...validFiles]);
    setUploadStats(prev => ({ ...prev, total: prev.total + validFiles.length }));

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }, []);

  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragEnter = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    if (connectionStatus === 'online') {
      setIsDragOver(true);
    }
  }, [connectionStatus]);

  const handleDragLeave = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    // Only set to false if leaving the drop area completely
    if (!event.currentTarget.contains(event.relatedTarget as Node)) {
      setIsDragOver(false);
    }
  }, []);

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setIsDragOver(false);
    
    if (connectionStatus === 'offline') {
      alert('Cannot upload files while offline. Please check your connection.');
      return;
    }
    
    const files = Array.from(event.dataTransfer.files);
    
    if (files.length === 0) {
      console.warn('No files dropped');
      return;
    }

    const validFiles: UploadFile[] = [];
    const errors: string[] = [];

    files.forEach(file => {
      const error = validateFile(file);
      if (error) {
        errors.push(`${file.name}: ${error}`);
      } else {
        // Check for duplicates
        const isDuplicate = uploadFiles.some(existingFile => 
          existingFile.file.name === file.name && 
          existingFile.file.size === file.size
        );
        
        if (isDuplicate) {
          errors.push(`${file.name}: File already added`);
        } else {
          validFiles.push({
            file,
            id: crypto.randomUUID(),
            status: 'pending',
            progress: 0,
            title: file.name.replace(/\.[^/.]+$/, "")
          });
        }
      }
    });

    if (errors.length > 0) {
      console.warn('Some files were rejected:', errors);
      alert(`Some files were rejected:\n${errors.join('\n')}`);
    }

    if (validFiles.length > 0) {
      setUploadFiles(prev => [...prev, ...validFiles]);
      setUploadStats(prev => ({ 
        ...prev, 
        total: prev.total + validFiles.length 
      }));
      console.log(`Added ${validFiles.length} files to upload queue`);
    }
  }, [uploadFiles, connectionStatus]);

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  }, []);

  const uploadSingleFile = async (uploadFile: UploadFile): Promise<void> => {
    // Create abort controller for this upload
    const abortController = new AbortController();
    abortControllersRef.current.set(uploadFile.id, abortController);

    setUploadFiles(prev => prev.map(f => 
      f.id === uploadFile.id ? { 
        ...f, 
        status: 'uploading', 
        progress: 0,
        uploadStartTime: Date.now()
      } : f
    ));

    try {
      const formData = new FormData();
      formData.append('audio', uploadFile.file);
      formData.append('title', uploadFile.title || uploadFile.file.name);
      
      // Add metadata for therapeutic categorization
      formData.append('genre', 'Therapeutic');
      formData.append('category', 'User Upload');

      // Get auth token
      const token = getAuthToken();
      const headers: HeadersInit = {};
      
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const response = await fetch('/api/tracks/upload', {
        method: 'POST',
        body: formData,
        headers,
        signal: abortController.signal,
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication required. Please log in again.');
        } else if (response.status === 413) {
          throw new Error('File too large. Maximum size is 50MB.');
        } else if (response.status === 400) {
          const errorData = await response.json().catch(() => ({ error: 'Bad request' }));
          throw new Error(errorData.error || 'Invalid file format');
        } else if (response.status === 429) {
          throw new Error('Too many uploads. Please wait a moment.');
        } else {
          throw new Error(`Upload failed: ${response.status} ${response.statusText}`);
        }
      }

      const result: UploadResponse = await response.json();

      if (!result.success) {
        throw new Error(result.error || 'Upload failed');
      }

      setUploadFiles(prev => prev.map(f => 
        f.id === uploadFile.id ? { 
          ...f, 
          status: 'success', 
          progress: 100,
          duration: result.duration 
        } : f
      ));

      setUploadStats(prev => ({ ...prev, success: prev.success + 1 }));

    } catch (error) {
      // Don't show error if request was aborted
      if (error instanceof Error && error.name === 'AbortError') {
        return;
      }

      const errorMessage = error instanceof Error ? error.message : 'Upload failed';
      
      setUploadFiles(prev => prev.map(f => 
        f.id === uploadFile.id ? { 
          ...f, 
          status: 'error', 
          error: errorMessage 
        } : f
      ));

      setUploadStats(prev => ({ ...prev, failed: prev.failed + 1 }));
    } finally {
      // Clean up abort controller
      abortControllersRef.current.delete(uploadFile.id);
    }
  };

  const startUpload = async () => {
    if (uploadFiles.length === 0) return;

    // Check connection before starting
    if (connectionStatus === 'offline') {
      alert('No connection to server. Please check your network and try again.');
      return;
    }

    setIsUploading(true);
    const pendingFiles = uploadFiles.filter(f => f.status === 'pending');

    try {
      // Upload files in batches of 2 to avoid overwhelming the server
      const batchSize = 2;
      for (let i = 0; i < pendingFiles.length; i += batchSize) {
        const batch = pendingFiles.slice(i, i + batchSize);
        await Promise.allSettled(batch.map(uploadSingleFile));
        
        // Small delay between batches
        if (i + batchSize < pendingFiles.length) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
    } catch (error) {
      console.error('Batch upload error:', error);
    } finally {
      setIsUploading(false);
    }
  };

  const cancelUpload = (id: string) => {
    const abortController = abortControllersRef.current.get(id);
    if (abortController) {
      abortController.abort();
      abortControllersRef.current.delete(id);
    }
    
    setUploadFiles(prev => prev.map(f => 
      f.id === id ? { ...f, status: 'error', error: 'Cancelled by user' } : f
    ));
  };

  const removeFile = (id: string) => {
    // Cancel upload if in progress
    const file = uploadFiles.find(f => f.id === id);
    if (file?.status === 'uploading') {
      cancelUpload(id);
    }

    setUploadFiles(prev => {
      const removedFile = prev.find(f => f.id === id);
      const updated = prev.filter(f => f.id !== id);
      
      if (removedFile) {
        setUploadStats(prevStats => ({
          total: prevStats.total - 1,
          success: removedFile.status === 'success' ? prevStats.success - 1 : prevStats.success,
          failed: removedFile.status === 'error' ? prevStats.failed - 1 : prevStats.failed
        }));
      }
      
      return updated;
    });
  };

  const retryFailed = () => {
    setUploadFiles(prev => prev.map(f => 
      f.status === 'error' ? { ...f, status: 'pending', error: undefined } : f
    ));
    setUploadStats(prev => ({ ...prev, failed: 0 }));
  };

  const clearCompleted = () => {
    // Cancel any ongoing uploads
    uploadFiles.forEach(file => {
      if (file.status === 'uploading') {
        cancelUpload(file.id);
      }
    });

    setUploadFiles(prev => prev.filter(f => f.status !== 'success' && f.status !== 'error'));
    setUploadStats({ 
      total: uploadFiles.filter(f => f.status === 'pending' || f.status === 'uploading').length, 
      success: 0, 
      failed: 0 
    });
  };



  const getStatusIcon = (status: UploadFile['status']) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'uploading':
      case 'processing':
        return <div className="h-4 w-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />;
      default:
        return <Music className="h-4 w-4 text-gray-400" />;
    }
  };

  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case 'online':
        return <Wifi className="h-4 w-4 text-green-500" />;
      case 'offline':
        return <WifiOff className="h-4 w-4 text-red-500" />;
      default:
        return <div className="h-4 w-4 border-2 border-gray-500 border-t-transparent rounded-full animate-spin" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header with Connection Status */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">Upload Music Tracks</h1>
            <p className="text-blue-200">Add new therapeutic music to your NeuroTunes library</p>
          </div>
          <div className="flex items-center gap-2 text-sm">
            {getConnectionIcon()}
            <span className={connectionStatus === 'online' ? 'text-green-400' : connectionStatus === 'offline' ? 'text-red-400' : 'text-yellow-400'}>
              {connectionStatus === 'online' ? 'Connected' : connectionStatus === 'offline' ? 'Offline' : 'Checking...'}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={checkConnectionStatus}
              className="text-blue-200 hover:text-white"
            >
              Refresh
            </Button>
          </div>
        </div>

        {/* Connection Warning */}
        {connectionStatus === 'offline' && (
          <Alert className="bg-red-900/30 border-red-700">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-red-200">
              <strong>No connection to server.</strong> Please check that your backend server is running and try refreshing the connection.
            </AlertDescription>
          </Alert>
        )}

        {/* Upload Stats */}
        {uploadFiles.length > 0 && (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Upload Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-400">{uploadStats.total}</div>
                  <div className="text-sm text-slate-400">Total</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-400">{uploadStats.success}</div>
                  <div className="text-sm text-slate-400">Success</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-red-400">{uploadStats.failed}</div>
                  <div className="text-sm text-slate-400">Failed</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upload Area */}
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Select Audio Files</CardTitle>
            <CardDescription className="text-slate-400">
              Drag and drop MP3 files or click to browse. You can select up to 300 files at once.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                isDragOver && connectionStatus === 'online'
                  ? 'border-blue-500 bg-blue-900/20' 
                  : connectionStatus === 'offline' 
                    ? 'border-slate-700 cursor-not-allowed opacity-50' 
                    : 'border-slate-600 hover:border-blue-500'
              }`}
              onDrop={connectionStatus === 'online' ? handleDrop : undefined}
              onDragOver={connectionStatus === 'online' ? handleDragOver : undefined}
              onDragEnter={handleDragEnter}
              onDragLeave={handleDragLeave}
              onClick={connectionStatus === 'online' ? () => fileInputRef.current?.click() : undefined}
            >
              <Upload className="mx-auto h-12 w-12 text-slate-400 mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">
                {isDragOver ? 'Drop files here!' : 'Drop MP3 files here'}
              </h3>
              <p className="text-slate-400 mb-4">or click to browse your computer</p>
              <Button variant="outline" className="border-slate-600 text-white hover:bg-slate-700">
                Browse Files
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept="audio/mp3,audio/mpeg,.mp3"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
            
            {uploadFiles.length > 0 && (
              <div className="flex gap-4 mt-4 flex-wrap">
                <Button 
                  onClick={startUpload} 
                  disabled={isUploading || uploadFiles.filter(f => f.status === 'pending').length === 0 || connectionStatus === 'offline'}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isUploading ? 'Uploading...' : `Upload ${uploadFiles.filter(f => f.status === 'pending').length} Files`}
                </Button>
                
                {uploadStats.failed > 0 && (
                  <Button 
                    variant="outline" 
                    onClick={retryFailed}
                    className="border-orange-600 text-orange-400 hover:bg-orange-700"
                    disabled={isUploading}
                  >
                    Retry Failed ({uploadStats.failed})
                  </Button>
                )}
                
                <Button 
                  variant="outline" 
                  onClick={clearCompleted}
                  className="border-slate-600 text-white hover:bg-slate-700"
                  disabled={isUploading}
                >
                  Clear Completed
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* File List */}
        {uploadFiles.length > 0 && (
          <Card className="bg-slate-800/50 border-slate-700">
            <CardHeader>
              <CardTitle className="text-white">Upload Queue ({uploadFiles.length} files)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {uploadFiles.map((uploadFile) => (
                  <div
                    key={uploadFile.id}
                    className="flex items-center gap-3 p-3 bg-slate-700/30 rounded-lg"
                  >
                    {getStatusIcon(uploadFile.status)}
                    
                    <div className="flex-1 min-w-0">
                      <div className="text-white font-medium truncate">
                        {uploadFile.title}
                      </div>
                      <div className="text-sm text-slate-400">
                        {(uploadFile.file.size / 1024 / 1024).toFixed(2)} MB
                        {uploadFile.duration && ` • ${Math.round(uploadFile.duration)}s`}
                      </div>
                      {uploadFile.status === 'uploading' && (
                        <Progress value={uploadFile.progress} className="mt-2 h-2" />
                      )}
                      {uploadFile.error && (
                        <div className="text-red-400 text-sm mt-1">{uploadFile.error}</div>
                      )}
                    </div>

                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(uploadFile.id)}
                      className="text-slate-400 hover:text-white"
                      disabled={uploadFile.status === 'uploading'}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Help Section */}
        <Alert className="mt-6 bg-blue-900/30 border-blue-700">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="text-blue-200">
            <strong>Tips for best results:</strong> Use high-quality MP3 files (320kbps recommended). 
            Include descriptive filenames as they will be used as track titles. 
            The system will automatically analyze audio for therapeutic categorization.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}