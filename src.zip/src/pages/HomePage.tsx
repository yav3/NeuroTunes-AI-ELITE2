import React, { useEffect, useState } from 'react';
import { fetchTracks, Track } from '../lib/apiNew';
import { useStableAudio } from '../context/StableAudioContext';
import AlbumCard from '../components/AlbumCard';

export default function HomePage() {
  const [tab, setTab] = useState<'popular'|'recent'|'all'>('popular');
  const [tracks, setTracks] = useState<Track[]>([]);

  const [loading, setLoading] = useState(true);
  const { play } = useStableAudio();

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    const params: Record<string, string | number> = tab === 'popular' ? { sort: 'popular', limit: 100 }
                 : tab === 'recent'  ? { sort: 'recent',  limit: 100 }
                 : { limit: 200 };
    fetchTracks(params).then((t) => { 
      if(mounted) {
        setTracks(t);
      }
    })
      .catch(console.error)
      .finally(() => mounted && setLoading(false));
    return () => { mounted = false; }
  }, [tab]);

  const handlePlay = (track: Track) => {
    console.log('[STABLE AUDIO] Playing track:', track.title);
    play(track);
  };

  return (
    <div className="max-w-[1040px] mx-auto px-4 sm:px-6 pt-6 pb-4 space-y-6">
      <div className="flex items-center justify-between">
        <div className="text-xl font-medium text-white">Trending</div>
        <div className="rounded-2xl overflow-hidden border border-white/10 bg-white/5">
          <Tab v="popular" cur={tab} set={setTab} />
          <Tab v="recent"  cur={tab} set={setTab} />
          <Tab v="all"     cur={tab} set={setTab} />
        </div>
      </div>

      {loading ? (
        <div className="text-blue-300 text-center py-8">Loading your music library…</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 justify-items-center">
          {tracks.map((t, idx) => (
            <AlbumCard
              key={`${t.id}-${idx}`}
              title={t.title}
              subtitle={`${t.artist ?? 'Neural Positive Music'} • ${t.therapeuticTags?.slice(0, 1).join('') || 'Therapeutic'}`}
              coverUrl={t.coverUrl || `/api/art/${encodeURIComponent(t.title)}`}
              onPlay={() => handlePlay(t)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function Tab({v,cur,set}:{v:'popular'|'recent'|'all';cur:any;set:(x:any)=>void}) {
  const active = cur===v;
  return (
    <button
      onClick={()=>set(v)}
      className={`px-4 py-2.5 text-sm font-medium transition-all ${
        active 
          ? 'bg-white/10 text-blue-300' 
          : 'text-white/70 hover:text-white/90 hover:bg-white/5'
      }`}
    >
      {v[0].toUpperCase()+v.slice(1)}
    </button>
  );
}