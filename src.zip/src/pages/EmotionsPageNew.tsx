import React, { useState, useEffect } from 'react';
import { Play, Pause, SkipForward, Heart, Volume2 } from 'lucide-react';
import { useAudio } from '../context/AudioContext';

interface MoodOption {
  id: string;
  label: string;
  energy: number;
  valence: number;
}

const MOOD_OPTIONS: MoodOption[] = [
  { id: 'focus', label: 'Focus', energy: 6, valence: 7 },
  { id: 'mood_boost', label: 'Mood Boost', energy: 7, valence: 8 },
  { id: 'relaxation', label: 'Relaxation', energy: 3, valence: 6 },
  { id: 'meditation', label: 'Meditation & Pain Management', energy: 2, valence: 5 },
  { id: 'energy_boost', label: 'Energy Boost', energy: 9, valence: 8 }
];

interface Track {
  id: number;
  title: string;
  artist?: string;
  audioUrl?: string;
  mood?: string;
  therapeuticTags?: string[];
}

interface EmotionsPageProps {
  onPlayTrack: (track: Track) => void;
  currentTrack?: Track;
  isPlaying?: boolean;
  onTogglePlay?: () => void;
  onNextTrack?: () => void;
}

export default function EmotionsPageNew() {
  const { play, current: currentTrack, isPlaying, toggle } = useAudio();
  const [selectedMood, setSelectedMood] = useState<string | null>(null);
  const [moodTracks, setMoodTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  // Removed showPlayer state - using global PersistentMusicPlayer instead

  const fetchMoodTracks = async (moodId: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/tracks/mood/${moodId}`);
      if (response.ok) {
        const tracks = await response.json();
        setMoodTracks(tracks);
      } else {
        console.error('Failed to fetch mood tracks');
        setMoodTracks([]);
      }
    } catch (error) {
      console.error('Error fetching mood tracks:', error);
      setMoodTracks([]);
    } finally {
      setLoading(false);
    }
  };

  const handleMoodSelect = (moodId: string) => {
    setSelectedMood(moodId);
    fetchMoodTracks(moodId);
  };

  const handleTrackPlay = async (track: Track, index: number) => {
    setCurrentTrackIndex(index);
    setShowPlayer(true);
    await play(track);
  };

  const handleNextTrack = async () => {
    if (moodTracks.length === 0) return;
    const nextIndex = (currentTrackIndex + 1) % moodTracks.length;
    setCurrentTrackIndex(nextIndex);
    await play(moodTracks[nextIndex]);
  };

  return (
    <div style={{ 
      padding: '20px',
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      minHeight: '100vh',
      color: 'white'
    }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <h1 style={{ 
            fontSize: '32px', 
            fontWeight: '700', 
            marginBottom: '8px',
            background: 'linear-gradient(135deg, #60a5fa, #3b82f6)',
            backgroundClip: 'text',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}>
            How are you feeling right now?
          </h1>
          <p style={{ 
            fontSize: '16px', 
            opacity: 0.8,
            fontWeight: '400'
          }}>
            Select your therapeutic goal
          </p>
        </div>

        {/* Mood Grid - Compact Cards */}
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', 
          gap: '12px', 
          marginBottom: '32px' 
        }}>
          {MOOD_OPTIONS.map((mood) => (
            <button
              key={mood.id}
              onClick={() => handleMoodSelect(mood.id)}
              style={{
                padding: '16px 12px',
                borderRadius: '12px',
                border: selectedMood === mood.id ? '2px solid #3b82f6' : '1px solid rgba(59, 130, 246, 0.3)',
                background: selectedMood === mood.id 
                  ? 'rgba(59, 130, 246, 0.25)' 
                  : 'rgba(12, 25, 41, 0.8)',
                color: 'white',
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                transform: selectedMood === mood.id ? 'scale(1.05)' : 'scale(1)',
                boxShadow: selectedMood === mood.id ? '0 8px 25px rgba(59, 130, 246, 0.4)' : '0 2px 8px rgba(0, 0, 0, 0.3)',
                backdropFilter: 'blur(8px)'
              }}
              onMouseEnter={(e) => {
                if (selectedMood !== mood.id) {
                  e.currentTarget.style.background = 'rgba(59, 130, 246, 0.15)';
                  e.currentTarget.style.transform = 'scale(1.02)';
                }
              }}
              onMouseLeave={(e) => {
                if (selectedMood !== mood.id) {
                  e.currentTarget.style.background = 'rgba(12, 25, 41, 0.8)';
                  e.currentTarget.style.transform = 'scale(1)';
                }
              }}
            >
              <h3 style={{ 
                fontSize: '16px', 
                fontWeight: '600', 
                margin: '0',
                color: 'white'
              }}>
                {mood.label}
              </h3>
            </button>
          ))}
        </div>

        {/* Loading State */}
        {loading && (
          <div style={{ textAlign: 'center', padding: '40px' }}>
            <div style={{ 
              width: '40px', 
              height: '40px', 
              border: '3px solid rgba(59, 130, 246, 0.3)',
              borderTop: '3px solid #3b82f6',
              borderRadius: '50%',
              animation: 'spin 1s linear infinite',
              margin: '0 auto 16px'
            }}></div>
            <p>Finding your perfect tracks...</p>
          </div>
        )}

        {/* Mood Tracks Display */}
        {selectedMood && !loading && (
          <div>
            <h2 style={{ 
              fontSize: '24px', 
              fontWeight: '600', 
              marginBottom: '16px',
              textAlign: 'center'
            }}>
              {MOOD_OPTIONS.find(m => m.id === selectedMood)?.label} Music
            </h2>
            
            {moodTracks.length > 0 ? (
              <div style={{ 
                display: 'grid', 
                gridTemplateColumns: 'repeat(auto-fill, minmax(100px, 1fr))', 
                gap: '12px',
                padding: '8px'
              }}>
                {moodTracks.map((track, index) => (
                  <div
                    key={`${track.id}-${index}-${track.title}`}
                    onClick={() => handleTrackPlay(track, index)}
                    style={{
                      borderRadius: '12px',
                      overflow: 'hidden',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      aspectRatio: '1',
                      position: 'relative',
                      background: 'rgba(12, 25, 41, 0.4)',
                      border: '1px solid rgba(59, 130, 246, 0.2)'
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.transform = 'scale(1.05) translateY(-4px)';
                      e.currentTarget.style.boxShadow = '0 12px 32px rgba(59, 130, 246, 0.4)';
                      e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.6)';
                      // Show play button on hover
                      const playBtn = e.currentTarget.querySelector('.play-overlay') as HTMLElement;
                      if (playBtn) playBtn.style.opacity = '1';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.transform = 'scale(1) translateY(0)';
                      e.currentTarget.style.boxShadow = 'none';
                      e.currentTarget.style.borderColor = 'rgba(59, 130, 246, 0.2)';
                      // Hide play button
                      const playBtn = e.currentTarget.querySelector('.play-overlay') as HTMLElement;
                      if (playBtn) playBtn.style.opacity = '0';
                    }}
                  >
                    {/* Album Art - Full Coverage */}
                    <img 
                      src={`/api/art/${encodeURIComponent(track.title)}`}
                      alt={track.title}
                      style={{
                        width: '100%',
                        height: '100%',
                        objectFit: 'cover'
                      }}
                      onError={(e) => {
                        // Fallback gradient background
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.parentElement!.style.background = 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 50%, #1e40af 100%)';
                        e.currentTarget.parentElement!.innerHTML = `
                          <div style="
                            display: flex; 
                            align-items: center; 
                            justify-content: center; 
                            height: 100%; 
                            color: white; 
                            font-weight: 600; 
                            font-size: 24px;
                            opacity: 0.8;
                          ">M</div>
                          <div class="play-overlay" style="
                            position: absolute;
                            top: 50%;
                            left: 50%;
                            transform: translate(-50%, -50%);
                            width: 32px;
                            height: 32px;
                            border-radius: 50%;
                            background: rgba(59, 130, 246, 0.9);
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            color: white;
                            font-size: 12px;
                            opacity: 0;
                            transition: opacity 0.3s ease;
                            backdrop-filter: blur(4px);
                            border: 2px solid rgba(255, 255, 255, 0.3);
                          ">▶</div>
                        `;
                      }}
                    />
                    
                    {/* Play Button Overlay */}
                    <div 
                      className="play-overlay"
                      style={{
                        position: 'absolute',
                        top: '50%',
                        left: '50%',
                        transform: 'translate(-50%, -50%)',
                        width: '32px',
                        height: '32px',
                        borderRadius: '50%',
                        background: 'rgba(59, 130, 246, 0.9)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        color: 'white',
                        fontSize: '12px',
                        opacity: '0',
                        transition: 'opacity 0.3s ease',
                        backdropFilter: 'blur(4px)',
                        border: '2px solid rgba(255, 255, 255, 0.3)'
                      }}
                    >
                      ▶
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{ 
                textAlign: 'center', 
                padding: '40px',
                background: 'rgba(12, 25, 41, 0.8)',
                borderRadius: '12px',
                border: '1px solid rgba(59, 130, 246, 0.3)'
              }}>
                <p style={{ opacity: 0.7 }}>
                  No tracks found for this mood. Try selecting a different therapeutic goal.
                </p>
              </div>
            )}
          </div>
        )}

        {/* COMPLETELY REMOVED - using only PersistentMusicPlayer */}
        {false && false && (
          <div style={{
            position: 'fixed',
            bottom: '0',
            left: '0',
            right: '0',
            background: 'rgba(12, 25, 41, 0.95)',
            backdropFilter: 'blur(12px)',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            borderBottom: 'none',
            padding: '12px 20px',
            display: 'flex',
            alignItems: 'center',
            gap: '16px',
            zIndex: 1000
          }}>
            {/* Album Art */}
            <div style={{
              width: '48px',
              height: '48px',
              borderRadius: '8px',
              overflow: 'hidden',
              flexShrink: 0
            }}>
              <img 
                src={`/api/art/${encodeURIComponent(currentTrack.title)}`}
                alt={currentTrack.title}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover'
                }}
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                  e.currentTarget.parentElement!.style.background = 'linear-gradient(135deg, #3b82f6, #1d4ed8)';
                  e.currentTarget.parentElement!.innerHTML = `
                    <div style="
                      display: flex; 
                      align-items: center; 
                      justify-content: center; 
                      height: 100%; 
                      color: white; 
                      font-weight: 600; 
                      font-size: 14px;
                    ">
                      ${currentTrack.title.substring(0, 2).toUpperCase()}
                    </div>
                  `;
                }}
              />
            </div>

            {/* Track Info */}
            <div style={{ flex: 1, minWidth: 0 }}>
              <h4 style={{
                fontSize: '14px',
                fontWeight: '600',
                color: 'white',
                margin: 0,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}>
                {currentTrack.title}
              </h4>
              <p style={{
                fontSize: '12px',
                color: '#94a3b8',
                margin: 0,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                textOverflow: 'ellipsis'
              }}>
                {currentTrack.artist || 'Unknown Artist'}
              </p>
            </div>

            {/* Controls */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '12px'
            }}>
              <button
                onClick={() => {
                  console.log('Added to favorites:', currentTrack?.title);
                }}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#94a3b8',
                  cursor: 'pointer',
                  padding: '8px',
                  borderRadius: '6px',
                  transition: 'color 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = '#f87171';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = '#94a3b8';
                }}
              >
                <Heart style={{ width: '18px', height: '18px' }} />
              </button>

              <button
                onClick={toggle}
                style={{
                  background: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
                  border: 'none',
                  color: 'white',
                  padding: '10px',
                  borderRadius: '8px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  transition: 'transform 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.transform = 'scale(1.05)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.transform = 'scale(1)';
                }}
              >
                {isPlaying ? 
                  <Pause style={{ width: '18px', height: '18px' }} /> : 
                  <Play style={{ width: '18px', height: '18px' }} />
                }
              </button>

              <button
                onClick={handleNextTrack}
                style={{
                  background: 'none',
                  border: 'none',
                  color: '#94a3b8',
                  cursor: 'pointer',
                  padding: '8px',
                  borderRadius: '6px',
                  transition: 'color 0.2s'
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.color = 'white';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.color = '#94a3b8';
                }}
              >
                <SkipForward style={{ width: '18px', height: '18px' }} />
              </button>

              <button
                onClick={() => {
                  console.log('[MINI PLAYER] Expand button clicked!');
                  window.location.href = '/player';
                }}
                className="p-2 rounded-full flex-shrink-0 bg-blue-600 hover:bg-blue-700 text-white transition-colors active:scale-95 touch-manipulation cursor-pointer border-2 border-blue-400 shadow-lg"
                style={{ 
                  minWidth: '40px', 
                  minHeight: '40px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}
                aria-label="Expand Player"
              >
                🔼
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}