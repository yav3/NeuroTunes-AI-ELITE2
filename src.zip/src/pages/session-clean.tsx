import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { Moon, Sun, Clock, Heart } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

const GOALS = [
  "Relaxation",
  "Pain Reduction", 
  "Cardio",
  "Weightlifting",
  "Walking",
  "Yoga",
  "Meditation & Pain Management",
  "Work",
  "Focus",
  "Prep for Sleep",
  "Energy Boost"
];

const GENRES = [
  "Any Genre",
  "Classical",
  "Folk", 
  "Bluegrass",
  "Country",
  "Pop",
  "Singer-Songwriter",
  "Jazz",
  "Samba & Bossa Nova",
  "World",
  "Baroque Classical",
  "Renaissance Classical",
  "Indie",
  "Alternative",
  "Rock"
];

const MOOD_LABELS = ["Awful", "Poor", "Neutral", "Good", "Great"];

export default function SessionPersonalization() {
  const [moodLevel, setMoodLevel] = useState([2]); // 0-4 scale (Awful to Great)
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const createSessionMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("/api/sessions/create", "POST", data);
    },
    onSuccess: () => {
      toast({
        title: "Session Created",
        description: "Your personalized music session is ready!",
      });
      // Reset form
      setMoodLevel([2]);
      setSelectedGoal(null);
      setSelectedGenre("");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create session. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = async () => {
    if (!selectedGoal) {
      toast({
        title: "Missing Information",
        description: "Please select a goal.",
        variant: "destructive",
      });
      return;
    }

    if (!selectedGenre || selectedGenre === "") {
      toast({
        title: "Missing Information",
        description: "Please select a music preference.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      await createSessionMutation.mutateAsync({
        mood: MOOD_LABELS[moodLevel[0]], // Convert slider value to mood label
        goal: selectedGoal,
        genres: selectedGenre === "Any Genre" ? GENRES.slice(1) : [selectedGenre], // Exclude "Any Genre" when sending all
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 p-6">
      <div className="max-w-md mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-between items-center mb-8">
            <Moon className="h-6 w-6 text-blue-300" />
            <Sun className="h-6 w-6 text-blue-300" />
          </div>
          
          <h1 className="text-4xl font-bold text-white">How are you feeling?</h1>
          <p className="text-blue-200 text-lg">Let's start your therapeutic music session</p>
        </div>

        {/* Mood Slider */}
        <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
          <CardContent className="p-8">
            <div className="space-y-6">
              <h3 className="text-xl font-semibold text-white text-center">How are you feeling?</h3>
              
              <div className="space-y-4">
                <div className="flex justify-between text-sm text-slate-300">
                  <span>Awful</span>
                  <span>Great</span>
                </div>
                
                <Slider
                  value={moodLevel}
                  onValueChange={setMoodLevel}
                  max={4}
                  min={0}
                  step={1}
                  className="w-full"
                />
                
                <div className="text-center">
                  <span className="text-lg font-medium text-blue-400">
                    {MOOD_LABELS[moodLevel[0]]}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Goal Selection */}
        <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
          <CardContent className="p-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Choose your goal</h3>
              <Select value={selectedGoal || ""} onValueChange={setSelectedGoal}>
                <SelectTrigger className="w-full bg-slate-700/50 border-slate-600 text-white">
                  <SelectValue placeholder="Select your goal..." />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  {GOALS.map((goal) => (
                    <SelectItem key={goal} value={goal} className="text-white hover:bg-slate-700">
                      {goal}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Music Preference */}
        <Card className="bg-slate-800/90 backdrop-blur-xl border-slate-600/50 rounded-2xl">
          <CardContent className="p-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-white">Choose your music preference</h3>
              <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                <SelectTrigger className="w-full bg-slate-700/50 border-slate-600 text-white">
                  <SelectValue placeholder="Any Genre" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  {GENRES.map((genre) => (
                    <SelectItem key={genre} value={genre} className="text-white hover:bg-slate-700">
                      {genre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <div className="space-y-4">
          <div className="flex gap-4">
            <Button variant="outline" className="flex-1 bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50">
              Add entry
            </Button>
            <Button variant="outline" className="flex-1 bg-slate-700/50 border-slate-600 text-white hover:bg-slate-600/50">
              View history
            </Button>
          </div>
          
          <Button 
            onClick={handleSubmit}
            disabled={isSubmitting || !selectedGoal}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-xl"
          >
            {isSubmitting ? "Creating Session..." : "Start Therapy"}
          </Button>
        </div>

        {/* Bottom Navigation */}
        <div className="flex justify-center gap-8 pt-6">
          <div className="flex items-center gap-2 text-slate-300">
            <Clock className="h-5 w-5" />
            <span>Recent</span>
          </div>
          <div className="flex items-center gap-2 text-slate-300">
            <Heart className="h-5 w-5" />
            <span>Favorites</span>
          </div>
        </div>
      </div>
    </div>
  );
}