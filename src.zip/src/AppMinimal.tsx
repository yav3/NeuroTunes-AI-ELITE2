import { useState, useEffect } from 'react';
import MergedAIDJPage from './pages/MergedAIDJPage';
import ProfilePage from './pages/ProfilePage';
import AdminPage from './pages/AdminPage';

interface Track {
  id: number;
  title: string;
  artist: string;
  audioUrl?: string;
  mood?: string;
  therapeuticTags?: string[];
}

// MusicCard Component
const MusicCard = ({ track, onPlay }: { track: any; onPlay: () => void }) => (
  <div 
    onClick={onPlay}
    style={{
      background: 'rgba(12, 25, 41, 0.7)',
      border: '1px solid rgba(59, 130, 246, 0.2)',
      borderRadius: '12px',
      padding: '12px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      minWidth: '160px',
      width: '160px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '8px',
      boxSizing: 'border-box',
      scrollSnapAlign: 'start',
      flexShrink: 0
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.background = 'rgba(59, 130, 246, 0.15)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.background = 'rgba(12, 25, 41, 0.7)';
    }}
  >
    {/* Album Art */}
    <div style={{
      width: '100%',
      aspectRatio: '1',
      maxWidth: '120px',
      background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
      borderRadius: '8px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      marginBottom: '8px'
    }}>
      <img 
        src={`/api/art/${encodeURIComponent(track.title)}`}
        alt={`Album art for ${track.title}`}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          borderRadius: '8px'
        }}
        onError={(e) => {
          (e.target as HTMLImageElement).style.display = 'none';
        }}
      />

    </div>

    {/* Track Info */}
    <div style={{ width: '100%', textAlign: 'center' }}>
      <div style={{ 
        fontWeight: '500', 
        fontSize: '14px',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        marginBottom: '4px'
      }}>
        {track.title}
      </div>
      <div style={{ 
        color: '#a5b4fc', 
        fontSize: '12px',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        marginBottom: '12px'
      }}>
        {track.artist || 'Neural Positive Music'}
      </div>
      
      {/* Play Button */}
      <div style={{
        width: '36px',
        height: '36px',
        background: '#3b82f6',
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto'
      }}>
        <svg width="14" height="14" viewBox="0 0 12 12" fill="currentColor" style={{ color: 'white', marginLeft: '1px' }}>
          <path d="M3 1v10l6-5-6-5z"/>
        </svg>
      </div>
    </div>
  </div>
);

export default function AppMinimal() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTab, setActiveTab] = useState<'trending' | 'all' | 'recent'>('trending');
  const [currentView, setCurrentView] = useState<'home' | 'aidj' | 'profile'>('home');
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isFavorited, setIsFavorited] = useState(false);
  const [spatialAudioEnabled, setSpatialAudioEnabled] = useState(false);
  const [isLightningMode, setIsLightningMode] = useState(false);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [pannerNode, setPannerNode] = useState<PannerNode | null>(null);
  const [gainNode, setGainNode] = useState<GainNode | null>(null);
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [adminKeyStrokes, setAdminKeyStrokes] = useState('');

  useEffect(() => {
    fetch('/api/tracks')
      .then(res => res.json())
      .then(data => {
        const trackCount = data.catalog ? data.catalog.length : 0;
        console.log('Loaded tracks:', trackCount);
        setTracks(data.catalog || []);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading tracks:', err);
        setTracks([]);
        setLoading(false);
      });
  }, []);

  // Admin keyboard shortcut handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.altKey && e.key === 'A') {
        setShowAdminPanel(true);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Admin panel check (hidden from regular users)
  if (showAdminPanel) {
    return <AdminPage />;
  }

  // Camelot wheel compatible key relationships for novelty selection
  const camelotKeys = [
    '1A', '1B', '2A', '2B', '3A', '3B', '4A', '4B', 
    '5A', '5B', '6A', '6B', '7A', '7B', '8A', '8B',
    '9A', '9B', '10A', '10B', '11A', '11B', '12A', '12B'
  ];

  // Get compatible keys for harmonic mixing (±1 semitone, relative major/minor)
  const getCompatibleKeys = (currentKey: string) => {
    const index = camelotKeys.indexOf(currentKey);
    if (index === -1) return [];
    
    const compatible = [];
    // Same key
    compatible.push(currentKey);
    // Adjacent keys (±1)
    compatible.push(camelotKeys[(index + 1) % camelotKeys.length]);
    compatible.push(camelotKeys[(index - 1 + camelotKeys.length) % camelotKeys.length]);
    // Relative major/minor (A <-> B)
    if (currentKey.endsWith('A')) {
      compatible.push(currentKey.replace('A', 'B'));
    } else {
      compatible.push(currentKey.replace('B', 'A'));
    }
    
    return compatible;
  };

  // Advanced track selection with Camelot wheel and novelty focus
  const getDisplayTracks = () => {
    if (!tracks || !Array.isArray(tracks)) {
      return [];
    }
    
    if (activeTab === 'trending') {
      // Show ALL tracks for trending - user requested to see all available songs
      return tracks;
    } else if (activeTab === 'recent') {
      // Show most recent tracks (assuming higher IDs are newer)
      return tracks.sort((a, b) => b.id - a.id).slice(0, 20);
    } else {
      // Show all tracks with variety
      const shuffled = [...tracks].sort(() => Math.random() - 0.5);
      return shuffled.slice(0, 25);
    }
  };

  const playTrack = (track: Track) => {
    console.log('Playing:', track.title);
    setCurrentTrack(track);
    
    // Cleanup any existing audio
    if (audioElement) {
      audioElement.pause();
      audioElement.currentTime = 0;
      // Remove all event listeners from previous audio element
      audioElement.removeEventListener('loadedmetadata', () => {});
      audioElement.removeEventListener('timeupdate', () => {});
      audioElement.removeEventListener('ended', () => {});
      audioElement.removeEventListener('error', () => {});
    }
    
    // Use the proper audio URL format for local files
    const audioUrl = track.audioUrl || `/api/stream/${encodeURIComponent(track.title)}`;
    console.log('Audio URL:', audioUrl);
    
    // Create new audio element
    const audio = new Audio(audioUrl);
    setAudioElement(audio);
    
    // Set up audio event listeners with proper cleanup
    const handleLoadedMetadata = () => {
      setDuration(audio.duration);
    };
    
    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };
    
    const handleEnded = () => {
      console.log('Track ended naturally');
      setIsPlaying(false);
      // NO AUTO-SKIP - let user control playback
    };
    
    const handleError = (e: Event) => {
      const target = e.target as HTMLAudioElement;
      console.error('Audio error details:', target.error);
      console.error('Failed to load audio from:', audioUrl);
      setIsPlaying(false);
    };
    
    // Add event listeners
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);
    
    // Play the audio
    audio.play()
      .then(() => {
        setIsPlaying(true);
        console.log('Audio started playing');
      })
      .catch(err => {
        console.error('Error playing audio:', err);
        setIsPlaying(false);
      });
  };

  const togglePlay = () => {
    if (!audioElement) return;
    
    if (isPlaying) {
      audioElement.pause();
      setIsPlaying(false);
    } else {
      audioElement.play()
        .then(() => setIsPlaying(true))
        .catch(err => console.error('Error playing audio:', err));
    }
  };

  const toggleFavorite = () => {
    setIsFavorited(!isFavorited);
    console.log(isFavorited ? 'Removed from favorites' : 'Added to favorites');
  };

  const initializeAudioContext = () => {
    if (!audioContext && audioElement) {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const source = ctx.createMediaElementSource(audioElement);
        const panner = ctx.createPanner();
        const gain = ctx.createGain();
        
        // Configure panner for spatial audio
        panner.panningModel = 'HRTF';
        panner.distanceModel = 'inverse';
        panner.refDistance = 1;
        panner.maxDistance = 10000;
        panner.rolloffFactor = 1;
        panner.coneInnerAngle = 360;
        panner.coneOuterAngle = 0;
        panner.coneOuterGain = 0;
        
        // Connect the audio graph
        source.connect(panner);
        panner.connect(gain);
        gain.connect(ctx.destination);
        
        setAudioContext(ctx);
        setPannerNode(panner);
        setGainNode(gain);
        
        console.log('Spatial audio context initialized');
      } catch (error) {
        console.error('Failed to initialize spatial audio:', error);
      }
    }
  };

  const toggleSpatialAudio = () => {
    const newState = !spatialAudioEnabled;
    setSpatialAudioEnabled(newState);
    
    if (newState && audioElement) {
      // Initialize spatial audio if not already done
      if (!audioContext) {
        initializeAudioContext();
      }
      
      if (pannerNode) {
        // Create a subtle 3D effect by positioning the sound slightly to the right and forward
        pannerNode.positionX.setValueAtTime(0.5, audioContext!.currentTime);
        pannerNode.positionY.setValueAtTime(0.3, audioContext!.currentTime);
        pannerNode.positionZ.setValueAtTime(-0.5, audioContext!.currentTime);
        
        // Set listener orientation for immersive effect
        if (audioContext!.listener.forwardX) {
          audioContext!.listener.forwardX.setValueAtTime(0, audioContext!.currentTime);
          audioContext!.listener.forwardY.setValueAtTime(0, audioContext!.currentTime);
          audioContext!.listener.forwardZ.setValueAtTime(-1, audioContext!.currentTime);
          audioContext!.listener.upX.setValueAtTime(0, audioContext!.currentTime);
          audioContext!.listener.upY.setValueAtTime(1, audioContext!.currentTime);
          audioContext!.listener.upZ.setValueAtTime(0, audioContext!.currentTime);
        }
      }
      console.log('Spatial audio enabled - immersive 3D positioning active');
    } else if (pannerNode) {
      // Reset to center position for normal stereo
      pannerNode.positionX.setValueAtTime(0, audioContext!.currentTime);
      pannerNode.positionY.setValueAtTime(0, audioContext!.currentTime);
      pannerNode.positionZ.setValueAtTime(0, audioContext!.currentTime);
      console.log('Spatial audio disabled - stereo positioning restored');
    }
  };

  const toggleLightningMode = () => {
    const newState = !isLightningMode;
    setIsLightningMode(newState);
    
    if (newState && gainNode) {
      // Lightning mode: boost volume and add subtle distortion effect
      gainNode.gain.setValueAtTime(1.3, audioContext!.currentTime);
      console.log('Lightning mode enabled - audio boost active');
    } else if (gainNode) {
      // Normal mode: reset gain
      gainNode.gain.setValueAtTime(1.0, audioContext!.currentTime);
      console.log('Lightning mode disabled - normal audio restored');
    }
  };

  const skipToNext = () => {
    console.log('Skipping to next track');
    const displayTracks = getDisplayTracks();
    const currentIndex = displayTracks.findIndex(track => track.id === currentTrack?.id);
    const nextIndex = (currentIndex + 1) % displayTracks.length;
    const nextTrack = displayTracks[nextIndex];
    
    if (nextTrack) {
      // Stop current audio before starting next
      if (audioElement) {
        audioElement.pause();
        audioElement.currentTime = 0;
      }
      setIsPlaying(false);
      
      // Small delay to ensure clean transition
      setTimeout(() => {
        playTrack(nextTrack);
      }, 100);
    }
  };

  const skipToPrevious = () => {
    console.log('Skipping to previous track');
    const displayTracks = getDisplayTracks();
    const currentIndex = displayTracks.findIndex(track => track.id === currentTrack?.id);
    const prevIndex = currentIndex > 0 ? currentIndex - 1 : displayTracks.length - 1;
    const prevTrack = displayTracks[prevIndex];
    
    if (prevTrack) {
      // Stop current audio before starting previous
      if (audioElement) {
        audioElement.pause();
        audioElement.currentTime = 0;
      }
      setIsPlaying(false);
      
      // Small delay to ensure clean transition
      setTimeout(() => {
        playTrack(prevTrack);
      }, 100);
    }
  };

  const giveThumbsDown = () => {
    console.log('Thumbs down - stopping track');
    if (audioElement) {
      audioElement.pause();
      setIsPlaying(false);
    }
    // Don't auto-skip, let user choose next track manually
  };

  if (loading) {
    return (
      <div style={{ 
        minHeight: '100vh', 
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        color: 'white',
        padding: '20px',
        fontFamily: 'system-ui, sans-serif'
      }}>
        <div style={{ maxWidth: '600px', margin: '0 auto', textAlign: 'center', paddingTop: '100px' }}>
          <h1 style={{ fontSize: '24px', marginBottom: '40px' }}>NeuroTunes AI</h1>
          <div style={{ 
            width: '40px', 
            height: '40px', 
            border: '3px solid #3b82f6', 
            borderTop: '3px solid transparent',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto'
          }}></div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      minHeight: '100vh',
      height: '100vh',
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      color: 'white',
      fontFamily: 'system-ui, sans-serif',
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      overflow: 'hidden'
    }}>
      {/* Header */}
      <div style={{ 
        padding: '20px', 
        maxWidth: '600px', 
        margin: '0 auto',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        zIndex: 100,
        borderBottom: '1px solid rgba(59, 130, 246, 0.2)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        {/* Logo Sprite */}
        <div style={{
          width: '32px',
          height: '32px',
          background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: '2px solid rgba(59, 130, 246, 0.3)'
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style={{ color: 'white' }}>
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
          </svg>
        </div>
        
        <h2 style={{ fontSize: '20px', margin: '0', fontWeight: '600', color: '#a5b4fc' }}>
          Trending
        </h2>
        
        <div style={{ width: '32px' }}></div> {/* Spacer for centering */}
      </div>

      {/* Content based on current view */}
      {currentView === 'home' && (
        <div style={{ 
          position: 'absolute',
          top: '100px',
          left: 0,
          right: 0,
          bottom: '80px',
          overflowY: 'auto',
          overflowX: 'hidden',
          background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)'
        }}>
        <div style={{ 
          padding: '0 16px 40px', 
          maxWidth: '600px', 
          margin: '0 auto',
          boxSizing: 'border-box'
        }}>
        {/* Show ALL tracks - no tabs needed */}
        {(
          <div>
            {/* No need for title since it's in header */}

            {/* Horizontal scrolling showing ALL tracks */}
            <div 
              className="horizontal-scroll"
              style={{ 
                display: 'flex',
                gap: '12px',
                padding: '0 0 20px',
                overflowX: 'auto',
                overflowY: 'hidden',
                scrollSnapType: 'x mandatory'
              }}>
              {tracks.map(track => (
                <MusicCard key={`trending-all-${track.id}`} track={track} onPlay={() => playTrack(track)} />
              ))}
            </div>
            
            {/* SLEEP Purpose - From your library */}
            <div style={{ marginBottom: '48px' }}>
              <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
                Sleep
              </h2>
              <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
                authentic sleep music from your library
              </p>
              
              <div 
                  className="horizontal-scroll"
                  style={{ 
                    display: 'flex',
                    gap: '12px',
                    padding: '0 0 20px',
                    overflowX: 'auto',
                    overflowY: 'hidden',
                    scrollSnapType: 'x mandatory'
                  }}>
                  {(() => {
                    const sleepTracks = tracks.filter(track => 
                      track.title.toLowerCase().includes('sleep')
                    );
                    if (sleepTracks.length > 0) {
                      return sleepTracks.map(track => (
                        <MusicCard key={`sleep-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                      ));
                    } else {
                      // Fallback: Show relaxation tracks
                      const fallbackTracks = tracks.filter(track => 
                        track.title.toLowerCase().includes('relaxation') ||
                        track.title.toLowerCase().includes('calm') ||
                        track.title.toLowerCase().includes('gentle')
                      ).slice(0, 8);
                      return fallbackTracks.map(track => (
                        <MusicCard key={`sleep-fallback-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                      ));
                    }
                  })()}
                </div>
            </div>

            {/* RELAXATION Purpose - From your library */}
            <div style={{ marginBottom: '48px' }}>
              <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
                Relaxation
              </h2>
              <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
                authentic relaxation music from your library
              </p>
              <div 
                className="horizontal-scroll"
                style={{ 
                  display: 'flex',
                  gap: '12px',
                  padding: '0 0 20px',
                  overflowX: 'auto',
                  overflowY: 'hidden',
                  scrollSnapType: 'x mandatory'
                }}>
                {(() => {
                  const relaxationTracks = tracks.filter(track => 
                    track.title.toLowerCase().includes('relaxation')
                  );
                  if (relaxationTracks.length > 0) {
                    return relaxationTracks.map(track => (
                      <MusicCard key={`relaxation-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                    ));
                  } else {
                    // Fallback: Show focus tracks for concentration  
                    const fallbackTracks = tracks.filter(track => 
                      track.title.toLowerCase().includes('focus') ||
                      track.title.toLowerCase().includes('calm') ||
                      track.title.toLowerCase().includes('meditation')
                    ).slice(0, 8);
                    return fallbackTracks.map(track => (
                      <MusicCard key={`relaxation-fallback-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                    ));
                  }
                })()}
              </div>
            </div>

            {/* RE-ENERGIZE Purpose - From your library */}
            <div style={{ marginBottom: '48px' }}>
              <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
                Re-Energize
              </h2>
              <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
                authentic re-energize music from your library
              </p>
              
              <div 
                className="horizontal-scroll"
                style={{ 
                  display: 'flex',
                  gap: '12px',
                  padding: '0 0 20px',
                  overflowX: 'auto',
                  overflowY: 'hidden',
                  scrollSnapType: 'x mandatory'
                }}>
                {(() => {
                  const reEnergizeTracks = tracks.filter(track => 
                    track.title.toLowerCase().includes('re-energize') ||
                    track.title.toLowerCase().includes('energy') ||
                    track.title.toLowerCase().includes('boost')
                  );
                  if (reEnergizeTracks.length > 0) {
                    return reEnergizeTracks.map(track => (
                      <MusicCard key={`re-energize-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                    ));
                  } else {
                    // Fallback: Show upbeat tracks
                    const fallbackTracks = tracks.filter(track => 
                      track.title.toLowerCase().includes('edm') ||
                      track.title.toLowerCase().includes('rock') ||
                      track.title.toLowerCase().includes('electronic')
                    ).slice(0, 8);
                    return fallbackTracks.map(track => (
                      <MusicCard key={`re-energize-fallback-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                    ));
                  }
                })()}
              </div>
            </div>
          </div>
        )}

        {/* OTHER TABS: Recent and All - Show at top */}
        {(activeTab === 'recent' || activeTab === 'all') && (
          <div style={{ marginBottom: '48px' }}>
            <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
              {activeTab === 'recent' ? '[NEW] Recently Added' : '[ALL] Complete Library'}
            </h2>
            <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
              {activeTab === 'recent' ? 'newest additions • fresh tracks' : 'all genres • therapeutic music • wellness'}
            </p>
            
            <div 
              className="horizontal-scroll"
              style={{ 
                display: 'flex',
                gap: '12px',
                padding: '0 0 20px',
                overflowX: 'auto',
                overflowY: 'hidden',
                scrollSnapType: 'x mandatory'
              }}>
              {getDisplayTracks().map(track => (
                <MusicCard key={`${activeTab}-${track.id}`} track={track} onPlay={() => playTrack(track)} />
              ))}
            </div>
          </div>
        )}

        {/* AUTHENTIC CATEGORIES ONLY: Based on your actual music library */}
        {activeTab !== 'trending' && (
        <>
        {/* SLEEP Purpose - From your library */}
        <div style={{ marginBottom: '48px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
            Sleep
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '24px', opacity: 0.8 }}>
            authentic sleep music from your library
          </p>
          
          <div 
              className="horizontal-scroll"
              style={{ 
                display: 'flex',
                gap: '12px',
                padding: '0 0 20px',
                overflowX: 'auto',
                overflowY: 'hidden',
                scrollSnapType: 'x mandatory'
              }}>
              {(() => {
                const sleepTracks = tracks.filter(track => 
                  track.title.toLowerCase().includes('sleep')
                );
                if (sleepTracks.length > 0) {
                  return sleepTracks.map(track => (
                    <MusicCard key={`sleep-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ));
                } else {
                  // Fallback: Show relaxation tracks
                  const fallbackTracks = tracks.filter(track => 
                    track.title.toLowerCase().includes('relaxation') ||
                    track.title.toLowerCase().includes('calm') ||
                    track.title.toLowerCase().includes('gentle')
                  ).slice(0, 8);
                  return fallbackTracks.map(track => (
                    <MusicCard key={`sleep-fallback-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ));
                }
              })()}
            </div>
        </div>

        {/* RELAXATION Purpose - From your library */}
        <div style={{ marginBottom: '48px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
            Relaxation
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic relaxation music from your library
          </p>
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {(() => {
              const relaxationTracks = tracks.filter(track => 
                track.title.toLowerCase().includes('relaxation')
              );
              if (relaxationTracks.length > 0) {
                return relaxationTracks.map(track => (
                  <MusicCard key={`relaxation-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                ));
              } else {
                // Fallback: Show focus tracks for concentration  
                const fallbackTracks = tracks.filter(track => 
                  track.title.toLowerCase().includes('focus') ||
                  track.title.toLowerCase().includes('calm') ||
                  track.title.toLowerCase().includes('meditation')
                ).slice(0, 8);
                return fallbackTracks.map(track => (
                  <MusicCard key={`relaxation-fallback-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                ));
              }
            })()}
          </div>
        </div>

        {/* RE-ENERGIZE Purpose - From your library */}
        <div style={{ marginBottom: '48px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
            Re-Energize
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic re-energize music from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('re-energize')
            ).map(track => (
              <MusicCard key={`reenergize-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>

        {/* FOCUS Purpose - From your library */}
        <div style={{ marginBottom: '48px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
            Focus
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic focus music from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('focus')
            ).map(track => (
              <MusicCard key={`focus-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>

        {/* HIIT Purpose - From your library */}
        <div style={{ marginBottom: '48px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
            HIIT
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic HIIT workout music from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('hiit')
            ).map(track => (
              <MusicCard key={`hiit-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>

        {/* EDM & Electronic Genre - From your library */}
        <div style={{ marginBottom: '48px' }}>
          <h2 style={{ fontSize: '24px', marginBottom: '4px', fontWeight: '600' }}>
            EDM & Electronic
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic EDM tracks from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('edm')
            ).map(track => (
              <MusicCard key={`edm-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>

        {/* Classical & Baroque Genre - From your library */}
        <div style={{ marginBottom: '32px' }}>
          <h2 style={{ fontSize: '20px', marginBottom: '4px', fontWeight: '600' }}>
            Classical & Baroque
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic classical music from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('classical') || 
              track.title.toLowerCase().includes('baroque')
            ).map(track => (
              <MusicCard key={`classical-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>

        {/* Jazz & Big Band Genre - From your library */}
        <div style={{ marginBottom: '32px' }}>
          <h2 style={{ fontSize: '20px', marginBottom: '4px', fontWeight: '600' }}>
            Jazz & Big Band
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic jazz music from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('jazz') || 
              track.title.toLowerCase().includes('big band')
            ).map(track => (
              <MusicCard key={`jazz-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>



        {/* Indie Pop Genre - From your library */}
        <div style={{ marginBottom: '32px' }}>
          <h2 style={{ fontSize: '20px', marginBottom: '4px', fontWeight: '600' }}>
            Indie Pop
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic indie pop from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('indie pop')
            ).map(track => (
              <MusicCard key={`indie-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>

        {/* Bluegrass Genre - From your library */}
        <div style={{ marginBottom: '32px' }}>
          <h2 style={{ fontSize: '20px', marginBottom: '4px', fontWeight: '600' }}>
            Bluegrass
          </h2>
          <p style={{ fontSize: '12px', color: '#a5b4fc', marginBottom: '16px', opacity: 0.8 }}>
            authentic bluegrass from your library
          </p>
          
          <div 
            className="horizontal-scroll"
            style={{ 
              display: 'flex',
              gap: '12px',
              padding: '0 0 20px',
              overflowX: 'auto',
              overflowY: 'hidden',
              scrollSnapType: 'x mandatory'
            }}>
            {tracks.filter(track => 
              track.title.toLowerCase().includes('bluegrass')
            ).map(track => (
              <MusicCard key={`bluegrass-${track.id}`} track={track} onPlay={() => playTrack(track)} />
            ))}
          </div>
        </div>

        </>
        )}
        </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <div style={{
        position: 'fixed',
        bottom: '0',
        left: '0',
        right: '0',
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        backdropFilter: 'blur(12px)',
        borderTop: '1px solid rgba(59, 130, 246, 0.3)',
        zIndex: 100
      }}>
        {/* Navigation Tabs */}
        <div style={{
          padding: '12px 16px',
          maxWidth: '600px',
          margin: '0 auto'
        }}>
          <div style={{
            display: 'flex',
            justifyContent: 'space-around',
            alignItems: 'center'
          }}>
            <div 
              onClick={() => setCurrentView('home')}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '4px',
                cursor: 'pointer',
                padding: '4px'
              }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: currentView === 'home' ? '#3b82f6' : '#a5b4fc' }}>
                <path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z"/>
              </svg>
              <span style={{ fontSize: '10px', color: currentView === 'home' ? '#3b82f6' : '#a5b4fc', fontWeight: currentView === 'home' ? '500' : '400' }}>Home</span>
            </div>



            <div 
              onClick={() => setCurrentView('aidj')}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '4px',
                cursor: 'pointer',
                padding: '4px'
              }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: currentView === 'aidj' ? '#3b82f6' : '#a5b4fc' }}>
                <path d="M9 18V5l12-2v13"/>
                <circle cx="6" cy="18" r="3"/>
                <circle cx="18" cy="16" r="3"/>
              </svg>
              <span style={{ fontSize: '10px', color: currentView === 'aidj' ? '#3b82f6' : '#a5b4fc', fontWeight: currentView === 'aidj' ? '500' : '400' }}>AI DJ</span>
            </div>

            <div 
              onClick={() => setCurrentView('profile')}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '4px',
                cursor: 'pointer',
                padding: '4px'
              }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: currentView === 'profile' ? '#3b82f6' : '#a5b4fc' }}>
                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                <circle cx="12" cy="7" r="4"/>
              </svg>
              <span style={{ fontSize: '10px', color: currentView === 'profile' ? '#3b82f6' : '#a5b4fc', fontWeight: currentView === 'profile' ? '500' : '400' }}>Profile</span>
            </div>
          </div>
        </div>
        
        {/* Mini Music Player (shows when track is playing) */}
        {currentTrack && (
          <div style={{
            padding: '12px 16px',
            borderBottom: '1px solid rgba(59, 130, 246, 0.1)',
            background: 'rgba(12, 25, 41, 0.8)'
          }}>
            <div style={{ maxWidth: '600px', margin: '0 auto', display: 'flex', alignItems: 'center', gap: '12px' }}>
              {/* Mini Album Art */}
              <div style={{
                width: '40px',
                height: '40px',
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
                borderRadius: '6px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0
              }}>
                <img 
                  src={`/api/art/${encodeURIComponent(currentTrack.title)}`}
                  alt=""
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'cover',
                    borderRadius: '6px'
                  }}
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                  }}
                />
              </div>

              {/* Track Info */}
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ 
                  fontWeight: '500', 
                  fontSize: '13px',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  {currentTrack.title}
                </div>
                <div style={{ 
                  color: '#a5b4fc', 
                  fontSize: '11px',
                  whiteSpace: 'nowrap',
                  overflow: 'hidden',
                  textOverflow: 'ellipsis'
                }}>
                  {currentTrack.artist || 'Neural Positive Music'}
                </div>
              </div>

              {/* Mini Controls */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                {/* Heart/Favorite */}
                <button 
                  onClick={toggleFavorite}
                  style={{
                    width: '26px',
                    height: '26px',
                    background: isFavorited ? '#3b82f6' : 'transparent',
                    border: 'none',
                    borderRadius: '4px',
                    color: isFavorited ? 'white' : '#a5b4fc',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                  <svg width="10" height="10" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <path d="M7 11.5L3 8.5C1.5 7.2 1.5 5 3 3.8C4.5 2.5 6.5 3 7 4C7.5 3 9.5 2.5 11 3.8C12.5 5 12.5 7.2 11 8.5L7 11.5Z"/>
                  </svg>
                </button>

                {/* Previous Button */}
                <button 
                  onClick={skipToPrevious}
                  style={{
                    width: '26px',
                    height: '26px',
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '4px',
                    color: '#a5b4fc',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                  <svg width="10" height="10" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M12 2v12l-6-6 6-6zM4 2h-2v12h2z"/>
                  </svg>
                </button>

                {/* Play/Pause */}
                <button 
                  onClick={togglePlay}
                  style={{
                    width: '32px',
                    height: '32px',
                    background: '#3b82f6',
                    border: 'none',
                    borderRadius: '50%',
                    color: 'white',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}
                >
                  {isPlaying ? (
                    <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor">
                      <rect x="4" y="2" width="2" height="12" rx="1"/>
                      <rect x="10" y="2" width="2" height="12" rx="1"/>
                    </svg>
                  ) : (
                    <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor" style={{ marginLeft: '1px' }}>
                      <path d="M4 2v12l8-6-8-6z"/>
                    </svg>
                  )}
                </button>

                {/* Forward/Next Button */}
                <button 
                  onClick={skipToNext}
                  style={{
                    width: '26px',
                    height: '26px',
                    background: 'transparent',
                    border: 'none',
                    borderRadius: '4px',
                    color: '#a5b4fc',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                  <svg width="10" height="10" viewBox="0 0 16 16" fill="currentColor">
                    <path d="M4 2v12l6-6-6-6zM12 2h2v12h-2z"/>
                  </svg>
                </button>

                {/* Spatial Audio */}
                <button 
                  onClick={toggleSpatialAudio}
                  style={{
                    width: '26px',
                    height: '26px',
                    background: spatialAudioEnabled ? '#3b82f6' : 'transparent',
                    border: 'none',
                    borderRadius: '4px',
                    color: spatialAudioEnabled ? 'white' : '#a5b4fc',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.2s ease'
                  }}>
                  <svg width="10" height="10" viewBox="0 0 14 14" fill="none" stroke="currentColor" strokeWidth="1.5">
                    <circle cx="7" cy="7" r="2"/>
                    <circle cx="7" cy="7" r="4" strokeDasharray="2 2"/>
                  </svg>
                </button>

                {/* Lightning Mode */}
                <button 
                  onClick={toggleLightningMode}
                  style={{
                    width: '26px',
                    height: '26px',
                    background: isLightningMode ? '#3b82f6' : 'transparent',
                    border: 'none',
                    borderRadius: '4px',
                    color: isLightningMode ? 'white' : '#a5b4fc',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    transition: 'all 0.2s ease'
                  }}>
                  <svg width="10" height="10" viewBox="0 0 14 14" fill="currentColor">
                    <path d="M8 1L3 7H6L5 13L10 7H7L8 1Z"/>
                  </svg>
                </button>
              </div>
            </div>

            {/* Mini Progress Bar */}
            <div style={{
              height: '2px',
              background: 'rgba(12, 25, 41, 0.7)',
              borderRadius: '1px',
              overflow: 'hidden',
              marginTop: '8px',
              maxWidth: '600px',
              margin: '8px auto 0'
            }}>
              <div style={{
                height: '100%',
                width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%`,
                background: '#3b82f6',
                borderRadius: '1px',
                transition: 'width 0.1s ease'
              }}></div>
            </div>
          </div>
        )}
      </div>



      {/* AI DJ Page */}
      {currentView === 'aidj' && (
        <MergedAIDJPage 
          onPlayTrack={(track) => {
            setCurrentView('home');
            playTrack(track);
          }}
          currentTrack={currentTrack as any}
        />
      )}

      {/* Profile Page */}
      {currentView === 'profile' && (
        <ProfilePage />
      )}
    </div>
  );
}