import { useState } from 'react';
import { useBiometrics } from '@/hooks/useBiometrics';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { 
  Heart, 
  Activity, 
  Thermometer, 
  Zap, 
  Watch, 
  Bluetooth,
  AlertCircle,
  CheckCircle,
  Play,
  Square,
  Smartphone,
  Wifi
} from 'lucide-react';

export default function BiometricDashboard() {
  const { toast } = useToast();
  const [selectedDeviceType, setSelectedDeviceType] = useState<string>('');
  
  const {
    isMonitoring,
    currentReading,
    devices,
    biometricHistory,
    moodPrediction,
    devicesLoading,
    isConnecting,
    isDisconnecting,
    startMonitoring,
    stopMonitoring,
    connectDevice,
    disconnectDevice,
    requestDevicePermission,
    isSupported,
  } = useBiometrics();

  const handleConnectDevice = async (deviceType: string) => {
    try {
      await requestDevicePermission(deviceType);
      toast({
        title: "Device Connected",
        description: `Successfully connected ${deviceType} device`,
      });
    } catch (error) {
      toast({
        title: "Connection Failed",
        description: `Failed to connect ${deviceType} device`,
        variant: "destructive",
      });
    }
  };

  const handleStartMonitoring = async () => {
    try {
      await startMonitoring();
      toast({
        title: "Monitoring Started",
        description: "Real-time biometric monitoring is now active",
      });
    } catch (error: any) {
      toast({
        title: "Monitoring Failed",
        description: error.message || "Failed to start monitoring",
        variant: "destructive",
      });
    }
  };

  const deviceTypes = [
    { id: 'fitbit', name: 'Fitbit', icon: Watch },
    { id: 'apple_watch', name: 'Apple Watch', icon: Watch },
    { id: 'garmin', name: 'Garmin', icon: Watch },
    { id: 'polar', name: 'Polar', icon: Heart },
    { id: 'whoop', name: 'WHOOP', icon: Activity },
    { id: 'web_bluetooth', name: 'Bluetooth Device', icon: Bluetooth },
  ];

  const getMoodColor = (mood: string) => {
    switch (mood) {
      case 'stressed': return 'text-red-400';
      case 'relaxed': return 'text-green-400';
      case 'energetic': return 'text-yellow-400';
      case 'calm': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  const getStressLevelColor = (level: number) => {
    if (level > 70) return 'bg-red-500';
    if (level > 40) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white mb-2">Biometric Monitoring</h1>
        <p className="text-blue-200">Connect wearable devices for real-time mood detection</p>
      </div>

      {/* Bluetooth Support Check */}
      {!isSupported && (
        <Alert className="border-amber-500 bg-amber-500/10">
          <AlertCircle className="h-4 w-4 text-amber-500" />
          <AlertTitle className="text-amber-200">Limited Device Support</AlertTitle>
          <AlertDescription className="text-amber-100">
            Your browser doesn't support Web Bluetooth. Some device connections may not work.
          </AlertDescription>
        </Alert>
      )}

      {/* Device Connection */}
      <Card className="bg-slate-800/50 border-slate-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Wifi className="h-5 w-5" />
            Device Connections
          </CardTitle>
          <CardDescription className="text-blue-200">
            Connect your wearable devices to enable continuous monitoring
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Connected Devices */}
          {devices.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-white">Connected Devices</h3>
              {devices.map((device: any) => (
                <div key={device.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="h-4 w-4 text-green-400" />
                    <div>
                      <p className="text-white font-medium">{device.name}</p>
                      <p className="text-xs text-blue-200">
                        {device.batteryLevel && `Battery: ${device.batteryLevel}%`}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => disconnectDevice(device.id)}
                    disabled={isDisconnecting}
                    className="text-red-400 border-red-400 hover:bg-red-400/10"
                  >
                    Disconnect
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Available Device Types */}
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-white">Available Device Types</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {deviceTypes.map((deviceType) => {
                const Icon = deviceType.icon;
                return (
                  <Button
                    key={deviceType.id}
                    variant="outline"
                    onClick={() => handleConnectDevice(deviceType.id)}
                    disabled={isConnecting}
                    className="h-auto p-4 flex flex-col items-center gap-2 border-slate-600 hover:bg-slate-700/50"
                  >
                    <Icon className="h-6 w-6 text-blue-400" />
                    <span className="text-xs text-white">{deviceType.name}</span>
                  </Button>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Monitoring Controls */}
      <Card className="bg-slate-800/50 border-slate-600">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Real-time Monitoring
          </CardTitle>
          <CardDescription className="text-blue-200">
            Start continuous biometric monitoring for mood detection
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Button
              onClick={isMonitoring ? stopMonitoring : handleStartMonitoring}
              disabled={devices.length === 0}
              className={`flex items-center gap-2 ${
                isMonitoring 
                  ? 'bg-red-600 hover:bg-red-700' 
                  : 'bg-blue-600 hover:bg-blue-700'
              }`}
            >
              {isMonitoring ? (
                <>
                  <Square className="h-4 w-4" />
                  Stop Monitoring
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  Start Monitoring
                </>
              )}
            </Button>
            
            {isMonitoring && (
              <Badge variant="secondary" className="bg-green-500/20 text-green-400 border-green-500">
                Live Monitoring Active
              </Badge>
            )}
          </div>

          {devices.length === 0 && (
            <p className="text-sm text-blue-200">
              Connect at least one device to start monitoring
            </p>
          )}
        </CardContent>
      </Card>

      {/* Current Reading */}
      {currentReading && (
        <Card className="bg-slate-800/50 border-slate-600">
          <CardHeader>
            <CardTitle className="text-white">Current Biometric Reading</CardTitle>
            <CardDescription className="text-blue-200">
              Real-time data from your connected devices
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-red-400" />
                  <span className="text-sm text-white">Heart Rate</span>
                </div>
                <p className="text-2xl font-bold text-white">
                  {Math.round(currentReading.heartRate)} BPM
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Activity className="h-4 w-4 text-blue-400" />
                  <span className="text-sm text-white">HRV</span>
                </div>
                <p className="text-2xl font-bold text-white">
                  {Math.round(currentReading.heartRateVariability)} ms
                </p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Zap className="h-4 w-4 text-yellow-400" />
                  <span className="text-sm text-white">Stress Level</span>
                </div>
                <div className="space-y-1">
                  <p className="text-2xl font-bold text-white">
                    {Math.round(currentReading.stressLevel)}%
                  </p>
                  <Progress 
                    value={currentReading.stressLevel} 
                    className="h-2"
                    style={{
                      background: getStressLevelColor(currentReading.stressLevel)
                    }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Thermometer className="h-4 w-4 text-green-400" />
                  <span className="text-sm text-white">Activity</span>
                </div>
                <p className="text-2xl font-bold text-white">
                  {Math.round(currentReading.activityLevel)}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Mood Prediction */}
      {moodPrediction && (
        <Card className="bg-slate-800/50 border-slate-600">
          <CardHeader>
            <CardTitle className="text-white">AI Mood Prediction</CardTitle>
            <CardDescription className="text-blue-200">
              Based on your current biometric data
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="space-y-1">
                <p className="text-sm text-blue-200">Predicted Mood</p>
                <p className={`text-2xl font-bold capitalize ${getMoodColor(moodPrediction.predictedMood)}`}>
                  {moodPrediction.predictedMood}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-blue-200">Confidence</p>
                <p className="text-2xl font-bold text-white">
                  {Math.round(moodPrediction.confidence * 100)}%
                </p>
              </div>
            </div>

            {moodPrediction.recommendations && moodPrediction.recommendations.length > 0 && (
              <div className="space-y-2">
                <p className="text-sm font-medium text-white">Recommendations</p>
                <ul className="space-y-1">
                  {moodPrediction.recommendations.map((rec: string, index: number) => (
                    <li key={index} className="text-sm text-blue-200 flex items-start gap-2">
                      <span className="text-blue-400 mt-1">•</span>
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Recent History */}
      {biometricHistory.length > 0 && (
        <Card className="bg-slate-800/50 border-slate-600">
          <CardHeader>
            <CardTitle className="text-white">Recent History</CardTitle>
            <CardDescription className="text-blue-200">
              Your last {biometricHistory.length} biometric readings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {biometricHistory.slice(0, 5).map((reading: any) => (
                <div key={reading.id} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="text-xs text-blue-200">
                      {new Date(reading.timestamp).toLocaleTimeString()}
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-white">
                        <Heart className="h-3 w-3 inline mr-1" />
                        {Math.round(reading.heartRate)} BPM
                      </span>
                      <span className="text-white">
                        <Zap className="h-3 w-3 inline mr-1" />
                        {Math.round(reading.stressLevel)}% stress
                      </span>
                    </div>
                  </div>
                  {reading.mood && (
                    <Badge variant="outline" className={`${getMoodColor(reading.mood)} border-current`}>
                      {reading.mood}
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}