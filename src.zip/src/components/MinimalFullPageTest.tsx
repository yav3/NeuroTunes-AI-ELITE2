import React from 'react';

// Absolute minimal test - no dependencies
export default function MinimalFullPageTest() {
  const [showModal, setShowModal] = React.useState(false);

  if (showModal) {
    return (
      <div className="fixed inset-0 bg-black z-[9999] flex items-center justify-center">
        <div className="bg-white text-black p-6 rounded">
          <h2 className="text-xl font-bold mb-4">FULL PAGE PLAYER WORKS!</h2>
          <button 
            onClick={() => setShowModal(false)}
            className="px-4 py-2 bg-blue-600 text-white rounded"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <button
      onClick={() => setShowModal(true)}
      className="fixed top-4 left-4 z-[9999] bg-yellow-600 text-black px-4 py-2 rounded font-bold"
      style={{ position: 'fixed', top: '20px', left: '20px', zIndex: 9999 }}
    >
      MINIMAL TEST
    </button>
  );
}