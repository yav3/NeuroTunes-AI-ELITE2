import React, { MouseEvent } from "react";
import { useStableAudio } from '../context/StableAudioContext';
import type { Track } from '../lib/apiNew';

type Props = {
  title: string;
  subtitle?: string;
  coverUrl: string;
  track?: Track;
  onPlay?: (e: MouseEvent) => void;
};

export default function AlbumCard({ title, subtitle, coverUrl, track, onPlay }: Props) {
  const { play } = useStableAudio();
  
  const handlePlay = (e: MouseEvent) => {
    e.preventDefault();
    
    if (track) {
      // Use global audio context
      play(track);
    } else if (onPlay) {
      // Fallback to prop callback
      onPlay(e);
    }
  };
  return (
    <div className="group select-none">
      {/* Cover with centered play */}
      <div className="relative aspect-square w-40 sm:w-48 rounded-2xl overflow-hidden shadow-lg bg-gradient-to-br from-blue-600 to-purple-600">
        {coverUrl ? (
          <img
            src={coverUrl}
            alt={title}
            className="h-full w-full object-cover"
            draggable={false}
            onError={(e) => {
              // Hide broken image and show background gradient
              const target = e.target as HTMLImageElement;
              target.style.display = 'none';
            }}
          />
        ) : (
          <div className="h-full w-full flex items-center justify-center">
            <span className="text-white text-lg font-bold">♪</span>
          </div>
        )}

        {/* subtle darken on hover for readability */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />

        {/* Play button in the center */}
        <button
          aria-label={`Play ${title}`}
          onClick={handlePlay}
          className="
            absolute inset-0 m-auto h-12 w-12 rounded-full
            flex items-center justify-center
            bg-white/90 backdrop-blur
            ring-1 ring-black/10
            opacity-90 group-hover:opacity-100
            transition-all duration-150
            focus:outline-none focus-visible:ring-2 focus-visible:ring-white
          "
        >
          {/* simple triangle; replace with your sprite if needed */}
          <svg viewBox="0 0 24 24" className="h-6 w-6" fill="currentColor">
            <path d="M8 5v14l11-7z" />
          </svg>
        </button>
      </div>

      {/* Tightened text block: minimal space under image */}
      <div className="mt-2 space-y-0.5">
        <div className="text-sm font-medium tracking-tight line-clamp-1">
          {title}
        </div>
        {subtitle ? (
          <div className="text-xs text-white/70 line-clamp-1">{subtitle}</div>
        ) : null}
      </div>
    </div>
  );
}