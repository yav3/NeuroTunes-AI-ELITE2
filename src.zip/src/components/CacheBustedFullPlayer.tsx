import React from 'react';
import { useAudio } from '../context/AudioContext';

// Cache-busted full page player - timestamp 1755867999
export default function CacheBustedFullPlayer() {
  const [isFullPage, setIsFullPage] = React.useState(false);
  const { current, isPlaying, toggle } = useAudio();
  
  React.useEffect(() => {
    console.log('[CACHE BUSTED PLAYER] Component loaded successfully - timestamp 1755867999');
  }, []);
  
  if (!current) return null;
  
  if (isFullPage) {
    return (
      <div 
        className="fixed inset-0 bg-black z-[99999] flex flex-col items-center justify-center"
        style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99999 }}
      >
        <div className="text-center text-white p-8">
          <div className="w-64 h-64 bg-blue-600 rounded-full flex items-center justify-center mb-8 mx-auto">
            <span className="text-6xl">🎵</span>
          </div>
          
          <h1 className="text-3xl font-bold mb-4">{current.title}</h1>
          <p className="text-xl mb-8">{current.artist}</p>
          
          <div className="flex gap-4 justify-center mb-8">
            <button 
              onClick={toggle}
              className="px-8 py-4 bg-blue-600 text-white rounded-lg text-xl"
            >
              {isPlaying ? '⏸️ Pause' : '▶️ Play'}
            </button>
          </div>
          
          <button 
            onClick={() => setIsFullPage(false)}
            className="px-6 py-3 bg-gray-600 text-white rounded-lg"
          >
            Close Full Player
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="fixed bottom-20 right-4 z-[9999]">
      <button
        onClick={() => {
          console.log('[CACHE BUSTED PLAYER] Opening full page view');
          setIsFullPage(true);
        }}
        className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-bold shadow-lg"
        style={{ 
          position: 'fixed', 
          bottom: '100px', 
          right: '16px', 
          zIndex: 9999,
          backgroundColor: '#7c3aed',
          color: 'white',
          padding: '12px 16px',
          borderRadius: '8px',
          fontWeight: 'bold'
        }}
      >
        🟣 EXPAND PLAYER
      </button>
    </div>
  );
}