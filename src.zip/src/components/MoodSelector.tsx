import { Button } from "@/components/ui/button";
import { Brain, Zap, Heart, Moon } from "lucide-react";

interface MoodSelectorProps {
  onMoodSelect: (mood: string) => void;
  selectedMood: string | null;
}

const moods = [
  { 
    name: "Calm", 
    value: "calm", 
    icon: Heart, 
    color: "text-emerald-500 dark:text-emerald-400" 
  },
  { 
    name: "Energized", 
    value: "energized", 
    icon: Zap, 
    color: "text-amber-500 dark:text-amber-400" 
  },
  { 
    name: "Focused", 
    value: "focused", 
    icon: Brain, 
    color: "text-blue-500 dark:text-blue-400" 
  },
  { 
    name: "Peaceful", 
    value: "peaceful", 
    icon: Moon, 
    color: "text-purple-500 dark:text-purple-400" 
  },
];

export default function MoodSelector({ onMoodSelect, selectedMood }: MoodSelectorProps) {
  return (
    <section className="mb-16">
      <h3 className="text-2xl font-light text-gray-900 dark:text-gray-100 mb-8 text-center">What Is Your Goal?</h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {moods.map((mood) => {
          const Icon = mood.icon;
          const isSelected = selectedMood === mood.value;
          
          return (
            <div
              key={mood.value}
              onClick={() => onMoodSelect(mood.value)}
              className={`relative group cursor-pointer transform transition-all duration-300 hover:scale-105 ${
                isSelected ? 'scale-105' : ''
              }`}
            >
              <div className={`
                relative overflow-hidden rounded-2xl p-6 text-center 
                bg-gradient-to-br from-white to-gray-50 
                dark:from-gray-800 dark:to-gray-900
                border border-gray-200 dark:border-gray-700
                shadow-lg hover:shadow-xl
                transition-all duration-300
                ${isSelected ? 'ring-2 ring-calm-primary shadow-calm-primary/20' : ''}
                ${mood.value === 'calm' ? 'hover:shadow-emerald-200/50 dark:hover:shadow-emerald-500/20' :
                  mood.value === 'energized' ? 'hover:shadow-amber-200/50 dark:hover:shadow-amber-500/20' :
                  mood.value === 'focused' ? 'hover:shadow-blue-200/50 dark:hover:shadow-blue-500/20' :
                  'hover:shadow-purple-200/50 dark:hover:shadow-purple-500/20'
                }
              `}>
                {/* Background gradient overlay */}
                <div className={`
                  absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300
                  ${mood.value === 'calm' ? 'bg-gradient-to-br from-emerald-400 to-emerald-600' :
                    mood.value === 'energized' ? 'bg-gradient-to-br from-amber-400 to-amber-600' :
                    mood.value === 'focused' ? 'bg-gradient-to-br from-blue-400 to-blue-600' :
                    'bg-gradient-to-br from-purple-400 to-purple-600'
                  }
                `} />
                
                {/* Icon container */}
                <div className={`
                  relative w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center
                  group-hover:scale-110 transition-transform duration-300
                  ${mood.value === 'calm' ? 'bg-gradient-to-br from-emerald-100 to-emerald-200 dark:from-emerald-900/40 dark:to-emerald-800/40' :
                    mood.value === 'energized' ? 'bg-gradient-to-br from-amber-100 to-amber-200 dark:from-amber-900/40 dark:to-amber-800/40' :
                    mood.value === 'focused' ? 'bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900/40 dark:to-blue-800/40' :
                    'bg-gradient-to-br from-purple-100 to-purple-200 dark:from-purple-900/40 dark:to-purple-800/40'
                  }
                `}>
                  <Icon className={`w-8 h-8 ${mood.color} group-hover:scale-110 transition-transform duration-300`} />
                </div>
                
                {/* Text */}
                <p className="relative font-medium text-gray-900 dark:text-gray-100 text-lg group-hover:text-gray-800 dark:group-hover:text-gray-200 transition-colors duration-300">
                  {mood.name}
                </p>
                
                {/* Selection indicator */}
                {isSelected && (
                  <div className="absolute top-2 right-2 w-3 h-3 bg-calm-primary rounded-full animate-pulse" />
                )}
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
