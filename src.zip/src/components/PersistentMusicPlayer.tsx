import React from 'react';
import { useStableAudio } from '../context/StableAudioContext';
import { useNavigate } from 'react-router-dom';

export default function PersistentMusicPlayer() {
  const nav = useNavigate();
  
  const {
    current: currentTrack,
    isPlaying,
    toggle
  } = useStableAudio();

  // Don't render if no track is loaded
  if (!currentTrack) {
    return null;
  }

  const Mini = (
    <div
      className="
        fixed left-0 right-0 
        bg-slate-900/95 backdrop-blur-md border-t border-slate-700/50 
        p-3 z-[2000] shadow-lg
        safe-bottom
      "
      style={{
        bottom: "var(--safe-bottom)",
        pointerEvents: "auto",
      }}
    >
      <div className="mx-auto max-w-3xl">
        <div className="flex items-center gap-3 w-full">
          {/* Album Art */}
          <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
            <img 
              src={`/api/art/${encodeURIComponent(currentTrack.title)}`}
              alt={currentTrack.title}
              className="w-full h-full object-cover"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                e.currentTarget.parentElement!.style.background = 'linear-gradient(135deg, #3b82f6, #1d4ed8)';
                e.currentTarget.parentElement!.innerHTML = `
                  <div style="
                    display: flex; 
                    align-items: center; 
                    justify-content: center; 
                    height: 100%; 
                    color: white; 
                    font-weight: 600; 
                    font-size: 14px;
                  ">
                    ♪
                  </div>
                `;
              }}
            />
          </div>

          {/* Track info - constrained width */}
          <div className="min-w-0 flex-1 max-w-[40%]">
            <p className="truncate text-sm font-medium text-white">
              {currentTrack.title.replace(/^organized\/[^\/]+\//, '')}
            </p>
            <p className="truncate text-xs text-neutral-400">{currentTrack.artist}</p>
          </div>

          {/* Controls - fixed width to ensure visibility */}
          <div className="flex items-center gap-3 flex-shrink-0">
            {/* Play/Pause Button */}
            <button 
              onClick={toggle}
              className="rounded-full p-2 bg-white/10 text-white hover:bg-white/20 transition-colors flex-shrink-0"
              style={{ minWidth: '40px', minHeight: '40px' }}
            >
              {isPlaying ? '⏸' : '▶'}
            </button>

            {/* EXPAND BUTTON - MAXIMUM VISIBILITY */}
            <button
              aria-label="Expand Player"
              onClick={(e) => { 
                e.preventDefault(); 
                e.stopPropagation(); 
                console.log('[MINI PLAYER] Expand button clicked!');
                console.log('[MINI PLAYER] Navigating to player...');
                
                // Simple React Router navigation
                nav('/player');
              }}
              style={{ 
                minWidth: '50px', 
                minHeight: '50px',
                backgroundColor: '#2563eb',
                border: '3px solid #60a5fa',
                borderRadius: '50%',
                color: 'white',
                fontSize: '20px',
                fontWeight: 'bold',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
                boxShadow: '0 4px 12px rgba(37, 99, 235, 0.5)',
                zIndex: 10000,
                position: 'relative',
                flexShrink: 0,
                transition: 'all 0.2s ease',
                marginLeft: '8px'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#1d4ed8';
                e.currentTarget.style.transform = 'scale(1.1)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#2563eb';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              ⤴
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return Mini;
}