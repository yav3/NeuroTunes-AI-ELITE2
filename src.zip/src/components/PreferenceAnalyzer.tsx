import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Brain, Sparkles, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PreferenceAnalyzerProps {
  onAnalysisComplete: (preferences: {
    category: string;
    confidence: number;
    preferences: string;
  }) => void;
}

interface AnalysisResult {
  category: string;
  confidence: number;
  recommendations: string;
  emotions: string[];
  topics: string[];
}

export default function PreferenceAnalyzer({ onAnalysisComplete }: PreferenceAnalyzerProps) {
  const [input, setInput] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const handleAnalyze = async () => {
    if (!input.trim()) return;
    
    setIsAnalyzing(true);
    setError(null);
    
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text: input }),
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      const analysisResult: AnalysisResult = {
        category: data.analysis.mood || 'General Wellness',
        confidence: Math.round((data.analysis.confidence || 0.5) * 100),
        recommendations: data.suggestions.recommendedActivity || 'Take a mindful break',
        emotions: data.analysis.emotions || [],
        topics: data.analysis.topics || []
      };

      setResult(analysisResult);
      
      onAnalysisComplete({
        category: analysisResult.category,
        confidence: analysisResult.confidence,
        preferences: input
      });

      toast({
        title: "Analysis Complete",
        description: `Detected mood: ${analysisResult.category} (${analysisResult.confidence}% confidence)`,
      });

    } catch (error) {
      console.error('Preference analysis failed:', error);
      const errorMessage = error instanceof Error ? error.message : 'Analysis failed';
      setError(errorMessage);
      
      // Fallback analysis
      const fallbackCategories = ['Deep Focus', 'Stress Relief', 'Relaxation', 'Energy Boost'];
      const randomCategory = fallbackCategories[Math.floor(Math.random() * fallbackCategories.length)];
      
      const fallbackResult = {
        category: randomCategory,
        confidence: 65,
        recommendations: 'Take a mindful break with calming music',
        emotions: ['calm'],
        topics: ['wellness']
      };
      
      setResult(fallbackResult);
      onAnalysisComplete({
        category: fallbackResult.category,
        confidence: fallbackResult.confidence,
        preferences: input
      });

      toast({
        title: "Analysis Complete (Offline Mode)",
        description: `Using fallback analysis: ${randomCategory}`,
        variant: "destructive",
      });
    }
    
    setIsAnalyzing(false);
  };

  return (
    <Card className="glass-card border-0 rounded-5xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-xl font-light">
          <div className="w-8 h-8 bg-therapeutic-lavender/20 rounded-full flex items-center justify-center ai-pulse">
            <Brain className="w-4 h-4 text-therapeutic-lavender" />
          </div>
          AI Mood Analysis
          <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">
            Live
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="relative">
          <Textarea
            className="w-full p-6 bg-white/50 border border-white/30 rounded-3xl resize-none focus:ring-2 focus:ring-calm-primary focus:border-transparent placeholder-gray-500 text-gray-900"
            placeholder="Describe how you're feeling right now... (e.g., 'I'm feeling stressed and need something calming to help me focus')"
            rows={4}
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <Button
            className="absolute bottom-4 right-4 bg-calm-primary hover:bg-calm-primary/90 text-white px-6 py-3 rounded-2xl transition-colors font-medium"
            onClick={handleAnalyze}
            disabled={!input.trim() || isAnalyzing}
          >
            {isAnalyzing ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Analyze Mood
              </>
            )}
          </Button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-xl">
            <AlertCircle className="w-4 h-4 text-red-500" />
            <span className="text-red-700 text-sm">Analysis error: {error}</span>
          </div>
        )}

        {/* Analysis Results */}
        {result && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-green-50 border border-green-200 rounded-2xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Sparkles className="w-4 h-4 text-green-600" />
                  <span className="font-medium text-gray-900">Primary Mood</span>
                </div>
                <div className="text-2xl font-light text-green-700">{result.category}</div>
                <div className="text-sm text-gray-600">{result.confidence}% confidence</div>
              </div>
              
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Brain className="w-4 h-4 text-blue-600" />
                  <span className="font-medium text-gray-900">Detected Topics</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {result.topics.length > 0 ? (
                    result.topics.map((topic, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {topic}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-gray-500 text-sm">No topics detected</span>
                  )}
                </div>
              </div>
              
              <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  <span className="font-medium text-gray-900">Emotions</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {result.emotions.length > 0 ? (
                    result.emotions.map((emotion, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {emotion}
                      </Badge>
                    ))
                  ) : (
                    <span className="text-gray-500 text-sm">No emotions detected</span>
                  )}
                </div>
              </div>
            </div>
            
            <div className="bg-therapeutic-lavender/10 border border-therapeutic-lavender/20 rounded-2xl p-6">
              <div className="flex items-center space-x-2 mb-3">
                <Sparkles className="w-4 h-4 text-therapeutic-lavender" />
                <span className="font-medium text-gray-900">AI Recommendations</span>
              </div>
              <p className="text-gray-700">{result.recommendations}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
