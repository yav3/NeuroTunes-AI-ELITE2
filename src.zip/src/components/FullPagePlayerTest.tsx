import React from 'react';
import { useAudio } from '../context/AudioContext';

// Simple test component to verify full-page player functionality
export default function FullPagePlayerTest() {
  const { current: currentTrack, isPlaying, toggle } = useAudio();
  const [showFullPage, setShowFullPage] = React.useState(false);

  console.log('[FULLPAGE TEST] Component rendered, showFullPage:', showFullPage);

  if (!currentTrack) {
    return (
      <div className="fixed top-4 right-4 bg-red-600 text-white p-4 rounded z-50">
        No track playing - cannot test full page player
      </div>
    );
  }

  if (showFullPage) {
    return (
      <div className="fixed inset-0 bg-black/90 backdrop-blur-lg z-[9999] flex items-center justify-center">
        <div className="bg-slate-800 rounded-xl p-8 max-w-md w-full mx-4 text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Full Page Player Test</h2>
          <div className="text-white mb-4">
            <p className="text-lg mb-2">{currentTrack.title}</p>
            <p className="text-blue-200">{currentTrack.artist}</p>
          </div>
          
          <div className="flex gap-4 justify-center mb-6">
            <button
              onClick={toggle}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg text-white font-medium"
            >
              {isPlaying ? 'Pause' : 'Play'}
            </button>
          </div>

          <button
            onClick={() => {
              console.log('[FULLPAGE TEST] Closing full page player');
              setShowFullPage(false);
            }}
            className="px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded text-white"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed top-4 right-4 z-[9999]">
      <button
        onClick={() => {
          console.log('[FULLPAGE TEST] Opening full page player');
          setShowFullPage(true);
        }}
        className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg font-bold shadow-lg border-2 border-white"
        style={{ position: 'fixed', top: '20px', right: '20px', zIndex: 9999 }}
      >
        🟣 TEST FULL PLAYER
      </button>
    </div>
  );
}