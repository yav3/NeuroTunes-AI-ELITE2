import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Moon, Sun, Mountain } from 'lucide-react';

type MoodLevel = 1 | 2 | 3 | 4 | 5;

interface MoodCheckInProps {
  onMoodSelect: (mood: MoodLevel) => void;
  onStartTherapy: () => void;
  selectedMood?: MoodLevel | null;
}

export default function MoodCheckIn({ onMoodSelect, onStartTherapy, selectedMood }: MoodCheckInProps) {
  const [showHistory, setShowHistory] = useState(false);

  const getMoodData = (level: MoodLevel) => {
    const moodScales = {
      1: { 
        label: 'Very Poor', 
        description: 'Feeling very low, distressed, or overwhelmed',
        bg: 'bg-gray-900',
        color: 'text-white',
        buttonStyle: 'bg-gray-800 hover:bg-gray-700 text-white border-gray-700'
      },
      2: { 
        label: 'Poor', 
        description: 'Feeling down, stressed, or having difficulties',
        bg: 'bg-gray-900', 
        color: 'text-white',
        buttonStyle: 'bg-gray-800 hover:bg-gray-700 text-white border-gray-700'
      },
      3: { 
        label: 'Neutral', 
        description: 'Feeling okay, balanced, or neither good nor bad',
        bg: 'bg-gray-900',
        color: 'text-white',
        buttonStyle: 'bg-gray-800 hover:bg-gray-700 text-white border-gray-700'
      },
      4: { 
        label: 'Good', 
        description: 'Feeling positive, content, or optimistic',
        bg: 'bg-gray-900',
        color: 'text-white',
        buttonStyle: 'bg-gray-800 hover:bg-gray-700 text-white border-gray-700'
      },
      5: { 
        label: 'Excellent', 
        description: 'Feeling great, energetic, or very happy',
        bg: 'bg-gray-900',
        color: 'text-white',
        buttonStyle: 'bg-gray-800 hover:bg-gray-700 text-white border-gray-700'
      }
    };
    return moodScales[level];
  };

  const currentMood = selectedMood ? getMoodData(selectedMood) : getMoodData(3);

  return (
    <div className="relative w-full max-w-sm mx-auto">
      <Card className={`relative overflow-hidden ${currentMood.bg} border-none shadow-2xl transition-all duration-1000`}>
        {/* Scenic Background */}
        <div className="absolute inset-0">
          {/* Mood Indicator */}
          <div className="absolute top-8 right-8 opacity-60">
            <div className={`w-12 h-12 rounded-full ${currentMood.color} bg-current/20 flex items-center justify-center text-2xl font-bold`}>
              {selectedMood || '?'}
            </div>
          </div>
          
          {/* Mountain Silhouettes */}
          <div className="absolute bottom-0 left-0 right-0 h-32">
            <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-black/20 to-transparent">
              <svg viewBox="0 0 400 80" className="w-full h-full">
                <polygon 
                  points="0,80 80,20 160,60 240,10 320,40 400,30 400,80" 
                  className="fill-current text-black/20 dark:text-white/10"
                />
                <polygon 
                  points="0,80 60,40 140,70 220,25 300,55 400,45 400,80" 
                  className="fill-current text-black/30 dark:text-white/20"
                />
              </svg>
            </div>
          </div>
        </div>

        <CardContent className="relative z-10 p-8 text-center">
          {/* Title */}
          <h2 className="text-2xl font-light text-white mb-8 drop-shadow-lg">
            How are you feeling?
          </h2>

          {/* 5-Point Likert Scale */}
          <div className="mb-8">
            <div className="grid grid-cols-5 gap-2 mb-4">
              {([1, 2, 3, 4, 5] as MoodLevel[]).map((level) => {
                const moodData = getMoodData(level);
                const isSelected = selectedMood === level;
                
                return (
                  <Button
                    key={level}
                    variant="outline"
                    size="sm"
                    onClick={() => onMoodSelect(level)}
                    className={`
                      px-3 py-6 text-sm font-medium transition-all duration-300 flex flex-col items-center space-y-2
                      ${isSelected ? 'ring-2 ring-white/50 scale-105' : ''}
                      ${moodData.buttonStyle}
                    `}
                  >
                    <div className={`w-8 h-8 rounded-full ${moodData.color} bg-current/20 flex items-center justify-center text-lg font-bold`}>
                      {level}
                    </div>
                    <span className="text-xs">{moodData.label}</span>
                  </Button>
                );
              })}
            </div>
            {selectedMood && (
              <div className="text-center">
                <p className="text-white/80 text-sm">{getMoodData(selectedMood).description}</p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowHistory(!showHistory)}
              className="w-full bg-gray-800 hover:bg-gray-700 text-white border-gray-700"
            >
              {showHistory ? 'Hide' : 'View'} history
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              className="w-full bg-gray-800 hover:bg-gray-700 text-white border-gray-700"
            >
              Add entry
            </Button>
          </div>

          {/* Start Therapy Button */}
          <Button
            onClick={onStartTherapy}
            className="w-full mt-6 bg-blue-500 hover:bg-blue-600 text-white font-medium py-3 rounded-lg shadow-lg transition-all duration-300 hover:shadow-xl"
          >
            Start Therapy
          </Button>
        </CardContent>
      </Card>

      {/* History Panel */}
      {showHistory && (
        <Card className="mt-4 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm border-white/20">
          <CardContent className="p-4">
            <h3 className="font-medium mb-3 text-gray-800 dark:text-gray-200">Recent Mood History</h3>
            <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex justify-between">
                <span>Today, 3:30 PM</span>
                <span className="text-green-600">Positive</span>
              </div>
              <div className="flex justify-between">
                <span>Today, 11:15 AM</span>
                <span className="text-yellow-600">Neutral</span>
              </div>
              <div className="flex justify-between">
                <span>Yesterday, 8:45 PM</span>
                <span className="text-green-600">Positive</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}