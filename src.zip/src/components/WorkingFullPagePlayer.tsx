import React from 'react';
import { X, Play, Pause, SkipBack, SkipForward, Volume2 } from 'lucide-react';
import { useAudio } from '../context/AudioContext';

// Working full-page player implementation
export default function WorkingFullPagePlayer() {
  const { 
    current: currentTrack, 
    isPlaying, 
    toggle, 
    next: nextTrack, 
    prev: prevTrack, 
    volume, 
    setVolume 
  } = useAudio();
  const [isOpen, setIsOpen] = React.useState(false);

  console.log('[WORKING PLAYER] Rendered, isOpen:', isOpen, 'currentTrack:', !!currentTrack);

  // Test button to open player
  if (!isOpen) {
    return currentTrack ? (
      <div className="fixed top-4 right-4 z-[9999]">
        <button
          onClick={() => {
            console.log('[WORKING PLAYER] Opening player');
            setIsOpen(true);
          }}
          className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-bold shadow-xl border-2 border-white"
          style={{ fontSize: '16px' }}
        >
          ✅ WORKING PLAYER
        </button>
      </div>
    ) : null;
  }

  // Full-page modal
  return (
    <div className="fixed inset-0 bg-black/95 backdrop-blur-lg z-[9999] flex flex-col">
      {/* Header with close button */}
      <div className="flex justify-between items-center p-6 border-b border-white/10">
        <h1 className="text-xl font-bold text-white">Now Playing</h1>
        <button
          onClick={() => {
            console.log('[WORKING PLAYER] Closing player');
            setIsOpen(false);
          }}
          className="p-2 rounded-full hover:bg-white/10 transition-colors"
        >
          <X size={24} className="text-white" />
        </button>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        {currentTrack && (
          <>
            {/* Album art placeholder */}
            <div className="w-80 h-80 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl mb-8 flex items-center justify-center">
              <div className="text-6xl">🎵</div>
            </div>

            {/* Track info */}
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-white mb-2">{currentTrack.title}</h2>
              <p className="text-xl text-blue-200">{currentTrack.artist}</p>
              {(currentTrack as any).genre && (
                <p className="text-sm text-gray-400 mt-2">{(currentTrack as any).genre}</p>
              )}
            </div>

            {/* Controls */}
            <div className="flex items-center gap-6 mb-8">
              <button
                onClick={() => prevTrack?.()}
                className="p-3 rounded-full hover:bg-white/10 transition-colors"
              >
                <SkipBack size={24} className="text-white" />
              </button>

              <button
                onClick={toggle}
                className="p-4 rounded-full bg-blue-600 hover:bg-blue-700 transition-colors"
              >
                {isPlaying ? (
                  <Pause size={28} className="text-white" />
                ) : (
                  <Play size={28} className="text-white ml-1" />
                )}
              </button>

              <button
                onClick={() => nextTrack?.()}
                className="p-3 rounded-full hover:bg-white/10 transition-colors"
              >
                <SkipForward size={24} className="text-white" />
              </button>
            </div>

            {/* Volume control */}
            <div className="flex items-center gap-3 w-64">
              <Volume2 size={20} className="text-white" />
              <input
                type="range"
                min="0"
                max="100"
                value={(volume || 0.8) * 100}
                onChange={(e) => setVolume?.(Number(e.target.value) / 100)}
                className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-white text-sm w-8">{Math.round((volume || 0.8) * 100)}</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}