import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar } from "@/components/ui/calendar";
import { Brain, Heart, Headphones, Activity, TrendingUp, Music, Sparkles } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { UserStats, MoodAnalysis } from "@shared/schema";

interface WellnessDashboardProps {
  userStats?: UserStats;
}

interface VADScores {
  valence: number;
  arousal: number;
  dominance: number;
}

interface TherapeuticSession {
  id: number;
  useCase: string;
  duration: number;
  startMood: VADScores;
  endMood: VADScores;
  improvement: number;
  date: string;
}

const moodLabels = ['Very Low', 'Low', 'Neutral', 'Good', 'Great'];
const useCaseIcons = {
  relaxation: Heart,
  exercise: Activity,
  sleep: Brain,
  mood_boost: Sparkles
};

export default function WellnessDashboard({ userStats }: WellnessDashboardProps) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentMood, setCurrentMood] = useState<number>(3);
  const [moodText, setMoodText] = useState<string>("");

  const { data: moodHistory } = useQuery<MoodAnalysis[]>({
    queryKey: ['/api/mood/history'],
  });

  const { data: therapeuticSessions } = useQuery<TherapeuticSession[]>({
    queryKey: ['/api/sessions/therapeutic'],
  });

  const { data: vadAnalysis } = useQuery<VADScores>({
    queryKey: ['/api/mood/vad-current'],
  });

  const moodAnalysisMutation = useMutation({
    mutationFn: async (data: { text: string; moodLevel: number }) => {
      return apiRequest('/api/mood/analyze', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/mood/history'] });
      queryClient.invalidateQueries({ queryKey: ['/api/mood/vad-current'] });
      setMoodText("");
    },
  });

  const handleMoodSubmit = () => {
    if (moodText.trim() || currentMood !== 3) {
      moodAnalysisMutation.mutate({
        text: moodText,
        moodLevel: currentMood
      });
    }
  };

  const getWellnessScore = () => {
    if (!moodHistory?.length) return 0;
    const recentMoods = moodHistory.slice(0, 7);
    const avgValence = recentMoods.reduce((sum, mood) => 
      sum + (mood.analysis?.valence || 50), 0) / recentMoods.length;
    return Math.round(avgValence);
  };

  const getStreakDays = () => {
    if (!therapeuticSessions?.length) return 0;
    let streak = 0;
    const today = new Date();
    
    for (let i = 0; i < 30; i++) {
      const checkDate = new Date(today);
      checkDate.setDate(today.getDate() - i);
      const hasSession = therapeuticSessions.some(session => 
        new Date(session.date).toDateString() === checkDate.toDateString()
      );
      if (hasSession) {
        streak++;
      } else if (i > 0) {
        break;
      }
    }
    return streak;
  };

  const getMoodTrend = () => {
    if (!moodHistory?.length) return 0;
    const recent = moodHistory.slice(0, 3);
    const older = moodHistory.slice(3, 6);
    
    if (older.length === 0) return 0;
    
    const recentAvg = recent.reduce((sum, mood) => 
      sum + (mood.analysis?.valence || 50), 0) / recent.length;
    const olderAvg = older.reduce((sum, mood) => 
      sum + (mood.analysis?.valence || 50), 0) / older.length;
    
    return recentAvg - olderAvg;
  };

  return (
    <div className="p-6 space-y-6 bg-gradient-to-br from-slate-100 via-blue-50 to-purple-50 dark:from-slate-900 dark:via-blue-900 dark:to-purple-900 min-h-screen relative">
      {/* Atmospheric Background Elements */}
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-20 right-20 w-32 h-32 bg-blue-300 dark:bg-blue-600 rounded-full blur-3xl"></div>
        <div className="absolute bottom-40 left-20 w-48 h-48 bg-purple-300 dark:bg-purple-600 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-green-300 dark:bg-green-600 rounded-full blur-3xl transform -translate-x-1/2 -translate-y-1/2"></div>
      </div>
      
      <div className="relative z-10">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
          Your Wellness Journey
        </h1>
        <p className="text-gray-600 dark:text-gray-300">
          AI-powered therapeutic music for your emotional well-being
        </p>
      </div>

      {/* Quick Mood Check-in */}
      <Card className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-600" />
            How are you feeling right now?
          </CardTitle>
          <CardDescription>
            Share your current mood to get personalized music recommendations
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-center gap-2">
              {moodLabels.map((label, index) => (
                <Button
                  key={index}
                  variant={currentMood === index + 1 ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentMood(index + 1)}
                  className="text-xs font-medium h-12 px-3"
                >
                  {label}
                </Button>
              ))}
            </div>
            
            <textarea
              value={moodText}
              onChange={(e) => setMoodText(e.target.value)}
              placeholder="Tell me more about how you're feeling... (optional)"
              className="w-full p-3 border rounded-lg resize-none h-20 bg-white dark:bg-gray-700 dark:border-gray-600"
            />
            
            <Button 
              onClick={handleMoodSubmit}
              disabled={moodAnalysisMutation.isPending}
              className="w-full"
            >
              {moodAnalysisMutation.isPending ? "Analyzing..." : "Get Therapeutic Music"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Wellness Stats Grid */}
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="relative overflow-hidden bg-gradient-to-br from-green-50 to-emerald-100 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-800 shadow-lg hover:shadow-xl transition-all duration-300">
          <div className="absolute inset-0 bg-gradient-to-r from-green-400/10 to-emerald-500/10" />
          <CardContent className="relative p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm font-medium text-green-700 dark:text-green-300">
                  Wellness Score
                </p>
                <p className="text-3xl font-bold text-green-900 dark:text-green-100">
                  {getWellnessScore()}%
                </p>
                <p className="text-xs text-green-600 dark:text-green-400">
                  Based on recent moods
                </p>
              </div>
              <div className="p-3 bg-green-100 dark:bg-green-900/50 rounded-full">
                <TrendingUp className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
            </div>
            <Progress value={getWellnessScore()} className="mt-4 h-2" />
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden bg-gradient-to-br from-blue-50 to-sky-100 dark:from-blue-900/20 dark:to-sky-900/20 border-blue-200 dark:border-blue-800 shadow-lg hover:shadow-xl transition-all duration-300">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-sky-500/10" />
          <CardContent className="relative p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm font-medium text-blue-700 dark:text-blue-300">
                  Daily Streak
                </p>
                <p className="text-3xl font-bold text-blue-900 dark:text-blue-100">
                  {getStreakDays()} days
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400">
                  Keep it going!
                </p>
              </div>
              <div className="p-3 bg-blue-100 dark:bg-blue-900/50 rounded-full">
                <Headphones className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="relative overflow-hidden bg-gradient-to-br from-purple-50 to-violet-100 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200 dark:border-purple-800 shadow-lg hover:shadow-xl transition-all duration-300">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-400/10 to-violet-500/10" />
          <CardContent className="relative p-6">
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <p className="text-sm font-medium text-purple-700 dark:text-purple-300">
                  Mood Trend
                </p>
                <p className="text-3xl font-bold text-purple-900 dark:text-purple-100">
                  {getMoodTrend() > 0 ? '+' : ''}{getMoodTrend().toFixed(1)}
                </p>
                <p className="text-xs text-purple-600 dark:text-purple-400">
                  {getMoodTrend() > 0 ? 'Improving' : getMoodTrend() < 0 ? 'Declining' : 'Stable'}
                </p>
              </div>
              <div className="p-3 bg-purple-100 dark:bg-purple-900/50 rounded-full">
                <Activity className="h-8 w-8 text-purple-600 dark:text-purple-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics */}
      <Tabs defaultValue="mood" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="mood">Mood Analysis</TabsTrigger>
          <TabsTrigger value="sessions">Therapeutic Sessions</TabsTrigger>
          <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="mood" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Current Emotional State</CardTitle>
                <CardDescription>VAD Analysis (Valence-Arousal-Dominance)</CardDescription>
              </CardHeader>
              <CardContent>
                {vadAnalysis ? (
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm">
                        <span>Positivity (Valence)</span>
                        <span>{vadAnalysis.valence}%</span>
                      </div>
                      <Progress value={vadAnalysis.valence} className="mt-1" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm">
                        <span>Energy (Arousal)</span>
                        <span>{vadAnalysis.arousal}%</span>
                      </div>
                      <Progress value={vadAnalysis.arousal} className="mt-1" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm">
                        <span>Control (Dominance)</span>
                        <span>{vadAnalysis.dominance}%</span>
                      </div>
                      <Progress value={vadAnalysis.dominance} className="mt-1" />
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-500 dark:text-gray-400">
                    Complete a mood check-in to see your emotional analysis
                  </p>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Mood Calendar</CardTitle>
                <CardDescription>Track your daily emotional patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  className="rounded-md border"
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sessions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Therapeutic Sessions</CardTitle>
              <CardDescription>Your personalized music therapy sessions</CardDescription>
            </CardHeader>
            <CardContent>
              {therapeuticSessions?.length ? (
                <div className="space-y-4">
                  {therapeuticSessions.slice(0, 5).map((session) => {
                    const IconComponent = useCaseIcons[session.useCase as keyof typeof useCaseIcons] || Music;
                    return (
                      <div key={session.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div className="flex items-center gap-3">
                          <IconComponent className="h-5 w-5 text-blue-600" />
                          <div>
                            <p className="font-medium capitalize">{session.useCase.replace('_', ' ')}</p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              {session.duration}min • {new Date(session.date).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-green-600">
                            +{session.improvement}% improvement
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-gray-500 dark:text-gray-400 text-center py-8">
                  No therapeutic sessions yet. Start your first session above!
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Wellness Insights</CardTitle>
              <CardDescription>Your therapeutic music journey progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Total Sessions</p>
                    <p className="text-2xl font-bold">{therapeuticSessions?.length || 0}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm font-medium">Total Listening Time</p>
                    <p className="text-2xl font-bold">
                      {therapeuticSessions?.reduce((sum, s) => sum + s.duration, 0) || 0}min
                    </p>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <p className="text-sm font-medium">Use Case Preferences</p>
                  {Object.entries(useCaseIcons).map(([useCase, IconComponent]) => {
                    const sessions = therapeuticSessions?.filter(s => s.useCase === useCase) || [];
                    const percentage = therapeuticSessions?.length 
                      ? (sessions.length / therapeuticSessions.length) * 100 
                      : 0;
                    
                    return (
                      <div key={useCase} className="flex items-center gap-3">
                        <IconComponent className="h-4 w-4 text-gray-600" />
                        <div className="flex-1">
                          <div className="flex justify-between text-sm">
                            <span className="capitalize">{useCase.replace('_', ' ')}</span>
                            <span>{sessions.length} sessions</span>
                          </div>
                          <Progress value={percentage} className="mt-1" />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      </div>
    </div>
  );
}