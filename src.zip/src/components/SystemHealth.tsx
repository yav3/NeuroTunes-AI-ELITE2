import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  CheckCircle, 
  AlertCircle, 
  Activity, 
  Brain, 
  Database, 
  Wifi,
  RefreshCw,
  TrendingUp,
  Lightbulb
} from 'lucide-react';

interface HealthStatus {
  status: 'healthy' | 'unhealthy' | 'warning';
  timestamp: string;
  services: {
    database: string;
    ai: string;
    nlp: string;
  };
}

interface AIInsight {
  title: string;
  description: string;
  type: 'pattern' | 'recommendation' | 'achievement';
  color: string;
}

export default function SystemHealth() {
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [insights] = useState<AIInsight[]>([
    {
      title: "Mood Pattern",
      description: "You tend to focus best in the morning. Consider scheduling important tasks between 9-11 AM.",
      type: "pattern",
      color: "bg-blue-50 border-blue-200 text-blue-900"
    },
    {
      title: "Recommendation",
      description: "Try 5-minute breathing exercises before focus sessions to improve concentration by 23%.",
      type: "recommendation", 
      color: "bg-green-50 border-green-200 text-green-900"
    }
  ]);

  // Fetch system health status
  const { data: healthStatus, isLoading, error, refetch } = useQuery<HealthStatus>({
    queryKey: ['/api/health'],
    refetchInterval: 30000, // Refetch every 30 seconds
    onSuccess: () => {
      setLastUpdated(new Date());
    }
  });

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case 'healthy':
      case 'connected':
      case 'active':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      case 'unhealthy':
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'healthy':
      case 'connected':
      case 'active':
        return 'text-green-600';
      case 'warning':
        return 'text-yellow-600';
      case 'unhealthy':
      case 'error':
        return 'text-red-600';
      default:
        return 'text-gray-400';
    }
  };

  const handleRefresh = () => {
    refetch();
    setLastUpdated(new Date());
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* System Health Status */}
      <Card className="glass-card border-0 rounded-4xl">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
              {healthStatus?.status === 'healthy' ? (
                <CheckCircle className="w-4 h-4 text-green-600" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600" />
              )}
            </div>
            <CardTitle className="text-lg font-medium text-gray-900">System Health</CardTitle>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleRefresh}
            disabled={isLoading}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {error ? (
            <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-xl">
              <AlertCircle className="w-4 h-4 text-red-500" />
              <span className="text-red-700 text-sm">Failed to fetch system status</span>
            </div>
          ) : (
            <>
              {/* Service Status */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Database className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-600">Database:</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(healthStatus?.services?.database)}
                    <span className={`text-sm font-medium ${getStatusColor(healthStatus?.services?.database)}`}>
                      {healthStatus?.services?.database || 'Checking...'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Brain className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-600">AI Processing:</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(healthStatus?.services?.ai)}
                    <span className={`text-sm font-medium ${getStatusColor(healthStatus?.services?.ai)}`}>
                      {healthStatus?.services?.ai || 'Checking...'}
                    </span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Wifi className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-600">NLP Engine:</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(healthStatus?.services?.nlp)}
                    <span className={`text-sm font-medium ${getStatusColor(healthStatus?.services?.nlp)}`}>
                      {healthStatus?.services?.nlp || 'Checking...'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Overall Status */}
              <div className={`mt-4 p-3 rounded-xl ${
                healthStatus?.status === 'healthy' 
                  ? 'bg-green-50 border border-green-200' 
                  : 'bg-red-50 border border-red-200'
              }`}>
                <div className="flex items-center space-x-2">
                  {healthStatus?.status === 'healthy' ? (
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-600" />
                  )}
                  <span className={`text-sm font-medium ${
                    healthStatus?.status === 'healthy' ? 'text-green-800' : 'text-red-800'
                  }`}>
                    {healthStatus?.status === 'healthy' ? 'All systems healthy' : 'System issues detected'}
                  </span>
                </div>
              </div>

              {/* Last Updated */}
              <div className="text-xs text-gray-500 text-center">
                Last updated: {formatTime(lastUpdated)}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* AI Insights */}
      <Card className="glass-card border-0 rounded-4xl">
        <CardHeader>
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-therapeutic-lavender/20 rounded-full flex items-center justify-center ai-pulse">
              <Lightbulb className="w-4 h-4 text-therapeutic-lavender" />
            </div>
            <CardTitle className="text-lg font-medium text-gray-900">AI Insights</CardTitle>
            <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-200">
              {insights.length} active
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {insights.map((insight, index) => (
            <div key={index} className={`p-4 border rounded-2xl ${insight.color}`}>
              <div className="flex items-start space-x-2">
                {insight.type === 'pattern' && <TrendingUp className="w-4 h-4 mt-0.5" />}
                {insight.type === 'recommendation' && <Lightbulb className="w-4 h-4 mt-0.5" />}
                {insight.type === 'achievement' && <CheckCircle className="w-4 h-4 mt-0.5" />}
                <div>
                  <h4 className="font-medium mb-2">{insight.title}</h4>
                  <p className="text-sm">{insight.description}</p>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Mood Tagger */}
      <Card className="glass-card border-0 rounded-4xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-therapeutic-coral/20 rounded-full flex items-center justify-center">
                <Brain className="w-4 h-4 text-therapeutic-coral" />
              </div>
              <CardTitle className="text-lg font-medium text-gray-900">Track Analysis</CardTitle>
            </div>
            <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-200">
              3 pending
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600">
            AI has analyzed new tracks and suggests mood tags for better recommendations.
          </p>
          
          <Button 
            className="w-full bg-therapeutic-coral/10 hover:bg-therapeutic-coral/20 text-therapeutic-coral font-medium py-3 rounded-2xl transition-colors"
            variant="ghost"
          >
            <Brain className="w-4 h-4 mr-2" />
            Review AI Suggestions
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
