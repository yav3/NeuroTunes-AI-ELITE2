import React from 'react';
import { useAudio } from '../context/AudioContext';

// Direct DOM manipulation approach - bypasses React rendering issues
export default function DirectDOMFullPlayer() {
  const { current, isPlaying, toggle } = useAudio();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    console.log('[DIRECT DOM] Component mounted, injecting DOM elements');
    
    // Remove any existing elements
    const existing = document.getElementById('direct-full-player-test');
    if (existing) existing.remove();
    
    // Create test button directly in DOM
    const testButton = document.createElement('div');
    testButton.id = 'direct-full-player-test';
    testButton.innerHTML = '🔵 DIRECT DOM TEST';
    testButton.style.cssText = `
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 99999;
      background: #2563eb;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      font-weight: bold;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0,0,0,0.3);
      font-family: system-ui, sans-serif;
      font-size: 14px;
    `;
    
    let fullPlayerOpen = false;
    
    testButton.onclick = () => {
      console.log('[DIRECT DOM] Test button clicked');
      
      if (fullPlayerOpen) return;
      
      // Create full page modal
      const modal = document.createElement('div');
      modal.id = 'direct-full-player-modal';
      modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.95);
        z-index: 999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: system-ui, sans-serif;
      `;
      
      modal.innerHTML = `
        <div style="text-align: center; color: white; padding: 40px;">
          <div style="width: 200px; height: 200px; background: linear-gradient(45deg, #3b82f6, #8b5cf6); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 30px; font-size: 60px;">
            🎵
          </div>
          <h1 style="font-size: 32px; margin-bottom: 16px; font-weight: bold;">FULL PAGE PLAYER WORKS!</h1>
          <p style="font-size: 18px; margin-bottom: 30px; opacity: 0.8;">Direct DOM injection bypass successful</p>
          <button id="close-full-player" style="
            padding: 12px 24px;
            background: #ef4444;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
          ">Close Full Player</button>
        </div>
      `;
      
      document.body.appendChild(modal);
      fullPlayerOpen = true;
      
      // Close functionality
      const closeBtn = document.getElementById('close-full-player');
      if (closeBtn) {
        closeBtn.onclick = () => {
          modal.remove();
          fullPlayerOpen = false;
        };
      }
      
      // Close on background click
      modal.onclick = (e) => {
        if (e.target === modal) {
          modal.remove();
          fullPlayerOpen = false;
        }
      };
    };
    
    document.body.appendChild(testButton);
    setMounted(true);
    
    // Cleanup
    return () => {
      const btn = document.getElementById('direct-full-player-test');
      const modal = document.getElementById('direct-full-player-modal');
      if (btn) btn.remove();
      if (modal) modal.remove();
    };
  }, []);

  React.useEffect(() => {
    if (!mounted || !current) return;
    
    console.log('[DIRECT DOM] Track changed:', current);
    
    // Add expand button when music is playing
    let expandButton = document.getElementById('direct-expand-button');
    if (!expandButton) {
      expandButton = document.createElement('div');
      expandButton.id = 'direct-expand-button';
      expandButton.innerHTML = '🟣 EXPAND';
      expandButton.style.cssText = `
        position: fixed;
        bottom: 120px;
        right: 20px;
        z-index: 99999;
        background: #7c3aed;
        color: white;
        padding: 10px 16px;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        font-family: system-ui, sans-serif;
        font-size: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      `;
      
      expandButton.onclick = () => {
        console.log('[DIRECT DOM] Expand button clicked');
        document.getElementById('direct-full-player-test')?.click();
      };
      
      document.body.appendChild(expandButton);
    }
  }, [current, mounted]);

  // This component renders nothing in React - everything is DOM manipulation
  return null;
}