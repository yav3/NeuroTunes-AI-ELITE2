// Developer genre classification error reporting utility

export interface GenreErrorReport {
  trackTitle: string;
  issueType: 'vocal_in_focus' | 'wrong_therapeutic_tag' | 'genre_misclassification';
  currentGenre?: string;
  suggestedGenre?: string;
  notes?: string;
}

export class GenreErrorReporter {
  private static async reportError(report: GenreErrorReport): Promise<void> {
    try {
      const response = await fetch('/api/report-genre-error', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(report),
      });

      if (response.ok) {
        const result = await response.json();
        console.log(`🚨 Developer reported classification error: "${report.trackTitle}"`);
        console.log(`   Issue: ${report.issueType}`);
        console.log(`   Current Genre: ${report.currentGenre || 'unknown'}`);
        console.log(`   Suggested Genre: ${report.suggestedGenre || 'unknown'}`);
      } else {
        console.error('Failed to report genre classification error:', response.statusText);
      }
    } catch (error) {
      console.error('Error reporting genre classification error:', error);
    }
  }

  static reportVocalInFocus(trackTitle: string, currentGenre?: string): void {
    this.reportError({
      trackTitle,
      issueType: 'vocal_in_focus',
      currentGenre,
      suggestedGenre: 'Mood Enhancement',
      notes: 'Track contains vocals and should not be in Focus category'
    });
  }

  static reportWrongTherapeuticTag(trackTitle: string, currentTag: string, suggestedTag: string): void {
    this.reportError({
      trackTitle,
      issueType: 'wrong_therapeutic_tag',
      currentGenre: currentTag,
      suggestedGenre: suggestedTag,
      notes: 'Track is incorrectly categorized for therapeutic purposes'
    });
  }

  static reportGenreMisclassification(trackTitle: string, currentGenre: string, suggestedGenre: string, notes?: string): void {
    this.reportError({
      trackTitle,
      issueType: 'genre_misclassification',
      currentGenre,
      suggestedGenre,
      notes: notes || 'Track is incorrectly classified by genre'
    });
  }
}

// Global function for developer console access
(window as any).reportGenreError = GenreErrorReporter;