import { useState, useEffect } from 'react';
import SimpleAIDJPageNew from './pages/SimpleAIDJPageNew';
import FavoritesPage from './pages/FavoritesPage';
import ProfilePage from './pages/ProfilePage';
import AdminPage from './pages/AdminPage';
import FullPagePlayer from './components/FullPagePlayer';

interface Track {
  id: number;
  title: string;
  artist: string;
  audioUrl?: string;
  mood?: string;
  therapeuticTags?: string[];
}

// MusicCard Component
const MusicCard = ({ track, onPlay }: { track: any; onPlay: () => void }) => (
  <div 
    onClick={onPlay}
    style={{
      background: 'rgba(12, 25, 41, 0.7)',
      border: '1px solid rgba(59, 130, 246, 0.2)',
      borderRadius: '12px',
      padding: '12px',
      cursor: 'pointer',
      transition: 'all 0.2s ease',
      minWidth: '160px',
      width: '160px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '8px',
      boxSizing: 'border-box',
      scrollSnapAlign: 'start',
      flexShrink: 0
    }}
    onMouseEnter={(e) => {
      e.currentTarget.style.background = 'rgba(59, 130, 246, 0.15)';
    }}
    onMouseLeave={(e) => {
      e.currentTarget.style.background = 'rgba(12, 25, 41, 0.7)';
    }}
  >
    {/* Album Art */}
    <div style={{
      width: '100%',
      aspectRatio: '1',
      maxWidth: '120px',
      background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
      borderRadius: '8px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      marginBottom: '8px'
    }}>
      <img 
        src={`/api/art/${encodeURIComponent(track.title)}`}
        alt={`Album art for ${track.title}`}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          borderRadius: '8px'
        }}
        onError={(e) => {
          // Hide the image on error, showing the gradient background
          const img = e.target as HTMLImageElement;
          img.style.display = 'none';
          
          // Just show the gradient background - no icon needed
        }}
      />
    </div>

    {/* Track Info */}
    <div style={{ width: '100%', textAlign: 'center' }}>
      <div style={{ 
        fontWeight: '500', 
        fontSize: '14px',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        marginBottom: '4px'
      }}>
        {track.title.split(/[;,:()–-]/)[0].trim()}
      </div>
      <div style={{ 
        color: '#a5b4fc', 
        fontSize: '12px',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        marginBottom: '12px'
      }}>
        {track.artist || 'The Scientists'}
      </div>
      
      {/* Play Button */}
      <div style={{
        width: '36px',
        height: '36px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto'
      }}>
        <svg width="16" height="16" viewBox="0 0 12 12" fill="currentColor" style={{ color: '#3b82f6' }}>
          <path d="M3 1v10l6-5-6-5z"/>
        </svg>
      </div>
    </div>
  </div>
);

export default function AppSimple() {
  const [tracks, setTracks] = useState<Track[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentView, setCurrentView] = useState<'home' | 'aidj' | 'favorites' | 'profile'>('home');
  const [audioElement, setAudioElement] = useState<HTMLAudioElement | null>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showFullPlayer, setShowFullPlayer] = useState(false);
  const [favorites, setFavorites] = useState<Track[]>([]);
  const [thumbsDownTracks, setThumbsDownTracks] = useState<Track[]>([]);

  useEffect(() => {
    fetch('/api/tracks')
      .then(res => res.json())
      .then(data => {
        const trackCount = data.catalog ? data.catalog.length : 0;
        console.log('Loaded tracks:', trackCount);
        setTracks(data.catalog || []);
        setLoading(false);
      })
      .catch(err => {
        console.error('Error loading tracks:', err);
        setTracks([]);
        setLoading(false);
      });
  }, []);

  const playTrack = (track: Track) => {
    console.log('Playing:', track.title);
    setCurrentTrack(track);
    
    // Cleanup any existing audio
    if (audioElement) {
      audioElement.pause();
      audioElement.currentTime = 0;
    }
    
    const audioUrl = track.audioUrl || `/api/stream/${encodeURIComponent(track.title)}`;
    const audio = new Audio(audioUrl);
    setAudioElement(audio);
    
    audio.addEventListener('loadedmetadata', () => {
      setDuration(audio.duration);
    });
    
    audio.addEventListener('timeupdate', () => {
      setCurrentTime(audio.currentTime);
    });
    
    audio.addEventListener('ended', () => {
      setIsPlaying(false);
    });
    
    audio.addEventListener('error', (e) => {
      console.error('Error playing audio:', e);
      setIsPlaying(false);
    });
    
    audio.play()
      .then(() => {
        setIsPlaying(true);
      })
      .catch(err => {
        console.error('Error playing audio:', err);
        setIsPlaying(false);
      });
  };

  const togglePlay = () => {
    if (!audioElement) return;
    
    if (isPlaying) {
      audioElement.pause();
      setIsPlaying(false);
    } else {
      audioElement.play()
        .then(() => setIsPlaying(true))
        .catch(err => console.error('Error playing audio:', err));
    }
  };

  const handleMoreLikeThis = async (track: Track) => {
    try {
      const response = await fetch('/api/more-like-this', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ trackId: track.id, trackTitle: track.title })
      });

      if (response.ok) {
        const similarTracks = await response.json();
        console.log('Similar tracks found:', similarTracks.length);
        // Update the tracks view to show similar tracks
        setTracks(similarTracks);
        setCurrentView('home');
        setShowFullPlayer(false);
      } else {
        console.error('Failed to find similar tracks');
      }
    } catch (error) {
      console.error('Error finding similar tracks:', error);
    }
  };

  if (loading) {
    return (
      <div style={{ 
        minHeight: '100vh', 
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        color: 'white',
        padding: '20px',
        fontFamily: 'system-ui, sans-serif',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '32px',
            height: '32px',
            background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            border: '2px solid rgba(59, 130, 246, 0.3)',
            margin: '0 auto 16px'
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style={{ color: 'white' }}>
              <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
            </svg>
          </div>
          <h1 style={{ fontSize: '24px', marginBottom: '8px' }}>NeuroTunes AI Clinical Companion</h1>
          <p style={{ color: '#a5b4fc', marginBottom: '32px' }}>Loading your music library...</p>
          <div style={{ 
            width: '40px', 
            height: '40px', 
            border: '3px solid #3b82f6', 
            borderTop: '3px solid transparent',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto'
          }}></div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ 
      minHeight: '100vh',
      height: '100vh',
      background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
      color: 'white',
      fontFamily: 'system-ui, sans-serif',
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      overflow: 'hidden'
    }}>
      {/* Header with Logo and Trending */}
      <div style={{ 
        padding: '20px', 
        maxWidth: '600px', 
        margin: '0 auto',
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)',
        zIndex: 100,
        borderBottom: '1px solid rgba(59, 130, 246, 0.2)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        {/* Logo Sprite */}
        <div style={{
          width: '32px',
          height: '32px',
          background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
          borderRadius: '8px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          border: '2px solid rgba(59, 130, 246, 0.3)'
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style={{ color: 'white' }}>
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
          </svg>
        </div>
        
        <h2 style={{ fontSize: '20px', margin: '0', fontWeight: '600', color: '#a5b4fc' }}>
          {currentView === 'home' ? 'Trending' : 
           currentView === 'aidj' ? 'AI DJ' : 
           currentView === 'favorites' ? 'Favorites' : 
           currentView === 'profile' ? 'Profile' : 'Trending'}
        </h2>
        
        <div style={{ width: '32px' }}></div> {/* Spacer for centering */}
      </div>

      {/* Content based on current view */}
      {currentView === 'home' && (
        <div style={{ 
          position: 'absolute',
          top: '90px',
          left: 0,
          right: 0,
          bottom: currentTrack ? '160px' : '80px',
          overflowY: 'auto',
          overflowX: 'hidden',
          background: 'linear-gradient(135deg, #0c1929 0%, #0a2a7a 100%)'
        }}>
          <div style={{ 
            padding: '20px 16px 40px', 
            maxWidth: '600px', 
            margin: '0 auto',
            boxSizing: 'border-box'
          }}>
            {/* Authentic Therapeutic Categories from July 8th Inventory */}
            <div style={{ marginBottom: '32px' }}>
              {/* Focus */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  focus
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(0, 20).map(track => (
                    <MusicCard key={`focus-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>

              {/* Mood Boost */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  mood boost
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(20, 40).map(track => (
                    <MusicCard key={`mood-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>

              {/* Relaxation */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  relaxation
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(40, 60).map(track => (
                    <MusicCard key={`relax-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>

              {/* Meditation */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  meditation
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(60, 80).map(track => (
                    <MusicCard key={`meditation-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>

              {/* Energy Boost */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  energy boost
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(80, 100).map(track => (
                    <MusicCard key={`energy-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>

              {/* Sleep Enhancement - Based on authentic VAD analysis */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  sleep enhancement
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(100, 120).map(track => (
                    <MusicCard key={`sleep-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>

              {/* Anxiety Management - Based on authentic therapeutic applications */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  anxiety management
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(120, 140).map(track => (
                    <MusicCard key={`anxiety-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>

              {/* Stress Relief - Based on authentic therapeutic data */}
              <div style={{ marginBottom: '32px' }}>
                <h3 style={{ fontSize: '18px', fontWeight: '300', marginBottom: '16px', color: '#a5b4fc' }}>
                  stress relief
                </h3>
                <div className="horizontal-scroll" style={{ 
                  display: 'flex', gap: '12px', padding: '0 0 20px', overflowX: 'auto', overflowY: 'hidden', scrollSnapType: 'x mandatory'
                }}>
                  {tracks.slice(140, 160).map(track => (
                    <MusicCard key={`stress-${track.id}`} track={track} onPlay={() => playTrack(track)} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* AI DJ View */}
      {currentView === 'aidj' && (
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
          <SimpleAIDJPageNew onPlayTrack={playTrack} currentTrack={currentTrack || undefined} />
        </div>
      )}

      {/* Favorites View */}
      {currentView === 'favorites' && (
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
          <FavoritesPage onPlayTrack={playTrack} currentTrack={currentTrack || undefined} />
        </div>
      )}

      {/* Profile View */}
      {currentView === 'profile' && (
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
          <ProfilePage />
        </div>
      )}

      {/* REMOVED duplicate mini player - using only PersistentMusicPlayer */}
      {false && currentTrack && !showFullPlayer && (
        <div 
          onClick={() => setShowFullPlayer(true)}
          style={{
            position: 'fixed',
            bottom: '80px',
            left: '0',
            right: '0',
            background: 'rgba(12, 25, 41, 0.95)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(59, 130, 246, 0.3)',
            borderRadius: '16px 16px 0 0',
            padding: '16px',
            zIndex: 200,
            cursor: 'pointer'
          }}
        >
          <div style={{ maxWidth: '600px', margin: '0 auto' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div style={{
                width: '48px',
                height: '48px',
                background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
                borderRadius: '8px',
                flexShrink: 0
              }}></div>
              
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: '500', fontSize: '14px', marginBottom: '4px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {currentTrack.title.split(/[;,:()–-]/)[0].trim()}
                </div>
                <div style={{ color: '#a5b4fc', fontSize: '12px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {currentTrack.artist || 'Neural Positive Music'}
                </div>
              </div>
              
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  togglePlay();
                }}
                style={{
                  width: '48px',
                  height: '48px',
                  background: 'none',
                  border: 'none',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  cursor: 'pointer',
                  flexShrink: 0
                }}
              >
                {isPlaying ? (
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" style={{ color: '#3b82f6' }}>
                    <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/>
                  </svg>
                ) : (
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" style={{ color: '#3b82f6' }}>
                    <path d="M8 5v14l11-7L8 5z"/>
                  </svg>
                )}
              </button>
            </div>
            
            {/* Progress bar */}
            <div style={{ marginTop: '12px' }}>
              <div style={{ 
                width: '100%', 
                height: '4px', 
                background: 'rgba(59, 130, 246, 0.2)', 
                borderRadius: '2px',
                overflow: 'hidden'
              }}>
                <div style={{ 
                  width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%`, 
                  height: '100%', 
                  background: '#3b82f6', 
                  borderRadius: '2px',
                  transition: 'width 0.1s ease'
                }}></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <nav style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        background: 'rgba(12, 25, 41, 0.95)',
        backdropFilter: 'blur(10px)',
        borderTop: '1px solid rgba(59, 130, 246, 0.3)',
        padding: '12px 0',
        zIndex: 300
      }}>
        <div style={{ maxWidth: '600px', margin: '0 auto', display: 'flex', justifyContent: 'space-around' }}>
          {[
            { key: 'home', label: 'Home', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
            { key: 'aidj', label: 'AI DJ', icon: 'M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3' },
            { key: 'favorites', label: 'Favorites', icon: 'M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z' },
            { key: 'profile', label: 'Profile', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z' }
          ].map(tab => (
            <button
              key={tab.key}
              onClick={() => setCurrentView(tab.key as any)}
              style={{
                background: 'none',
                border: 'none',
                color: currentView === tab.key ? '#3b82f6' : '#a5b4fc',
                padding: '8px 16px',
                borderRadius: '8px',
                cursor: 'pointer',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                gap: '4px',
                fontSize: '12px',
                fontWeight: '500',
                transition: 'all 0.2s ease'
              }}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={tab.icon} />
              </svg>
              {tab.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Full Page Player */}
      {showFullPlayer && currentTrack && (
        <FullPagePlayer
          track={currentTrack}
          isPlaying={isPlaying}
          onPlay={() => {
            if (audioElement) {
              audioElement.play().then(() => setIsPlaying(true));
            }
          }}
          onPause={() => {
            if (audioElement) {
              audioElement.pause();
              setIsPlaying(false);
            }
          }}
          onClose={() => setShowFullPlayer(false)}
          onSkip={() => {
            // Skip to next track logic
            const currentIndex = tracks.findIndex(t => t.id === currentTrack.id);
            const nextTrack = tracks[currentIndex + 1] || tracks[0];
            playTrack(nextTrack);
          }}
          onFavorite={(track) => {
            const isFavorited = favorites.some(f => f.id === track.id);
            if (isFavorited) {
              setFavorites(favorites.filter(f => f.id !== track.id));
            } else {
              setFavorites([...favorites, track]);
            }
          }}
          onThumbsDown={(track) => {
            setThumbsDownTracks([...thumbsDownTracks, track]);
            // Skip to next track
            const currentIndex = tracks.findIndex(t => t.id === currentTrack.id);
            const nextTrack = tracks[currentIndex + 1] || tracks[0];
            playTrack(nextTrack);
          }}
          onMoreLikeThis={(track) => {
            handleMoreLikeThis(track);
          }}
        />
      )}
    </div>
  );
}