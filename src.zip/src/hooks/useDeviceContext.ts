import { useEffect, useMemo, useState } from "react";

export type DeviceClass = "phone" | "tablet" | "desktop" | "tv" | "car" | "unknown";
export type PointerClass = "coarse" | "fine" | "none";
export type Orientation = "portrait" | "landscape" | "unknown";

export interface ClientContext {
  deviceClass: DeviceClass;
  viewportWidth: number;
  viewportHeight: number;
  pixelRatio: number;
  pointer: PointerClass;
  orientation: Orientation;
  network: {
    effectiveType?: string;   // 'slow-2g' | '2g' | '3g' | '4g' (browser dependent)
    saveData?: boolean;
    downlinkMbps?: number;
  };
  performance: {
    hardwareConcurrency?: number;
    deviceMemoryGB?: number;
  };
  userAgent?: string;
}

function classifyDevice(width: number, ua: string): DeviceClass {
  const low = ua.toLowerCase();
  const isTV = /smart[-\s]?tv|appletv|bravia|tizen|webos|crkey|androidtv/.test(low);
  const isCar = /android\s?auto|carplay/.test(low);
  if (isTV) return "tv";
  if (isCar) return "car";
  // crude but reliable enough + allows override later
  if (width <= 640) return "phone";
  if (width <= 1024) return "tablet";
  return "desktop";
}

export function useDeviceContext(): ClientContext {
  const [w, setW] = useState<number>(typeof window !== "undefined" ? window.innerWidth : 1024);
  const [h, setH] = useState<number>(typeof window !== "undefined" ? window.innerHeight : 768);
  const [pixelRatio, setPR] = useState<number>(typeof window !== "undefined" ? window.devicePixelRatio || 1 : 1);

  useEffect(() => {
    const onResize = () => {
      setW(window.innerWidth);
      setH(window.innerHeight);
      setPR(window.devicePixelRatio || 1);
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const pointer: PointerClass = useMemo(() => {
    if (typeof window === "undefined" || !window.matchMedia) return "unknown" as PointerClass;
    if (window.matchMedia("(pointer: coarse)").matches) return "coarse";
    if (window.matchMedia("(pointer: fine)").matches) return "fine";
    if (window.matchMedia("(pointer: none)").matches) return "none";
    return "fine";
  }, [w, h]);

  const orientation: Orientation = useMemo(() => {
    if (w > h) return "landscape";
    if (h > w) return "portrait";
    return "unknown";
  }, [w, h]);

  const navAny = (navigator as any);
  const connection = navAny?.connection || navAny?.mozConnection || navAny?.webkitConnection;

  const network = useMemo(() => ({
    effectiveType: connection?.effectiveType,
    saveData: connection?.saveData,
    downlinkMbps: typeof connection?.downlink === "number" ? connection.downlink : undefined
  }), [connection?.effectiveType, connection?.saveData, connection?.downlink]);

  const performanceInfo = useMemo(() => ({
    hardwareConcurrency: navigator?.hardwareConcurrency,
    deviceMemoryGB: (navigator as any)?.deviceMemory
  }), []);

  const ua = typeof navigator !== "undefined" ? navigator.userAgent : "";

  return {
    deviceClass: classifyDevice(w, ua),
    viewportWidth: w,
    viewportHeight: h,
    pixelRatio: pixelRatio,
    pointer,
    orientation,
    network,
    performance: performanceInfo,
    userAgent: ua
  };
}