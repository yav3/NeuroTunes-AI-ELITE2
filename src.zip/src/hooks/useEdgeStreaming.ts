import { useState, useCallback, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface CachedTrack {
  id: string;
  title: string;
  artist: string;
  albumArt: string;
  streamKey: string;
  file: string;
  therapeuticGoal: string;
  isCached: boolean;
  downloadCount: number;
}

interface EdgeStreamingPreferences {
  maxCacheSize: number;
  preferredQuality: 'standard' | 'high' | 'lossless';
  autoCache: boolean;
  prefetchEnabled: boolean;
}

export function useEdgeStreaming(userId?: string) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [cacheSize, setCacheSize] = useState(0);
  const [isOfflineMode, setIsOfflineMode] = useState(false);

  // Get cached favorites
  const { data: cachedFavorites = [], isLoading: loadingFavorites } = useQuery({
    queryKey: ['/api/edge/favorites', userId],
    enabled: !!userId,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Get popular tracks for pre-caching
  const { data: popularTracks = [] } = useQuery({
    queryKey: ['/api/edge/popular'],
    staleTime: 30 * 60 * 1000, // 30 minutes
  });

  // Add track to favorites with edge caching
  const addToFavoritesMutation = useMutation({
    mutationFn: async (trackData: any) => {
      await apiRequest('/api/edge/favorites', {
        method: 'POST',
        body: JSON.stringify({ userId, trackData }),
        headers: { 'Content-Type': 'application/json' },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/edge/favorites', userId] });
      toast({
        title: "Added to Favorites",
        description: "Track cached for offline listening",
      });
    },
    onError: (error) => {
      console.error('Error adding to favorites:', error);
      toast({
        title: "Error",
        description: "Failed to add track to favorites",
        variant: "destructive",
      });
    },
  });

  // Smart streaming - prefer cached versions
  const getStreamUrl = useCallback((track: any): string => {
    const cachedVersion = cachedFavorites.find(
      (cached: CachedTrack) => cached.streamKey === track.streamKey
    );
    
    if (cachedVersion && cachedVersion.isCached) {
      console.log(`🚀 Using cached version: ${track.title}`);
      return `/api/edge/stream/${cachedVersion.id}`;
    }
    
    console.log(`📡 Using original stream: ${track.title}`);
    return track.file;
  }, [cachedFavorites]);

  // Check if track is cached
  const isTrackCached = useCallback((trackId: string): boolean => {
    return cachedFavorites.some(
      (cached: CachedTrack) => cached.id === trackId
    );
  }, [cachedFavorites]);

  // Get offline available tracks
  const getOfflineTracks = useCallback((): CachedTrack[] => {
    return cachedFavorites.filter((track: CachedTrack) => track.isCached);
  }, [cachedFavorites]);

  // Progressive caching strategy
  const shouldPreCache = useCallback((track: any): boolean => {
    // Pre-cache if it's in popular tracks and user has auto-cache enabled
    const isPopular = popularTracks.some((popular: any) => 
      popular.trackId === track.id?.toString() || popular.trackId === track.streamKey
    );
    
    return isPopular && !isTrackCached(track.id?.toString() || track.streamKey);
  }, [popularTracks, isTrackCached]);

  // Cleanup old cache entries
  const cleanupCache = useMutation({
    mutationFn: async () => {
      await apiRequest('/api/edge/cleanup', { method: 'POST' });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/edge/favorites'] });
      toast({
        title: "Cache Cleaned",
        description: "Old cached tracks removed",
      });
    },
  });

  // Calculate cache statistics
  useEffect(() => {
    const totalSize = cachedFavorites.reduce((sum: number, track: CachedTrack) => 
      sum + (track.downloadCount || 0), 0
    );
    setCacheSize(totalSize);
  }, [cachedFavorites]);

  // Check network status for offline mode
  useEffect(() => {
    const handleOnline = () => setIsOfflineMode(false);
    const handleOffline = () => setIsOfflineMode(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return {
    // Data
    cachedFavorites,
    popularTracks,
    cacheSize,
    isOfflineMode,
    
    // Loading states
    loadingFavorites,
    isAddingToFavorites: addToFavoritesMutation.isPending,
    
    // Actions
    addToFavorites: addToFavoritesMutation.mutate,
    getStreamUrl,
    isTrackCached,
    getOfflineTracks,
    shouldPreCache,
    cleanupCache: cleanupCache.mutate,
    
    // Utils
    getCacheInfo: () => ({
      totalTracks: cachedFavorites.length,
      cacheSize: `${(cacheSize / 1024 / 1024).toFixed(1)} MB`,
      offlineAvailable: cachedFavorites.filter((t: CachedTrack) => t.isCached).length,
    }),
  };
}

// Hook for streaming preferences
export function useStreamingPreferences(userId?: string) {
  const queryClient = useQueryClient();

  const { data: preferences, isLoading } = useQuery({
    queryKey: ['/api/user/streaming-preferences', userId],
    enabled: !!userId,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const updatePreferences = useMutation({
    mutationFn: async (newPreferences: Partial<EdgeStreamingPreferences>) => {
      await apiRequest(`/api/user/streaming-preferences/${userId}`, {
        method: 'PUT',
        body: JSON.stringify(newPreferences),
        headers: { 'Content-Type': 'application/json' },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: ['/api/user/streaming-preferences', userId] 
      });
    },
  });

  return {
    preferences: preferences || {
      maxCacheSize: 100,
      preferredQuality: 'standard' as const,
      autoCache: true,
      prefetchEnabled: true,
    },
    isLoading,
    updatePreferences: updatePreferences.mutate,
    isUpdating: updatePreferences.isPending,
  };
}