import { useCallback, useEffect, useRef } from 'react';

interface HapticOptions {
  intensity?: 'light' | 'medium' | 'heavy';
  duration?: number;
}

interface HapticPatterns {
  tap: HapticOptions;
  playPause: HapticOptions;
  trackChange: HapticOptions;
  volumeChange: HapticOptions;
  bassHit: HapticOptions;
  error: HapticOptions;
  success: HapticOptions;
}

// Predefined haptic patterns for different music interactions
const HAPTIC_PATTERNS: HapticPatterns = {
  tap: { intensity: 'light', duration: 50 },
  playPause: { intensity: 'medium', duration: 100 },
  trackChange: { intensity: 'heavy', duration: 150 },
  volumeChange: { intensity: 'light', duration: 30 },
  bassHit: { intensity: 'heavy', duration: 80 },
  error: { intensity: 'heavy', duration: 200 },
  success: { intensity: 'medium', duration: 120 }
};

export function useHapticFeedback() {
  const isSupported = useRef(false);
  const vibrationRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    // Check if haptic feedback is supported
    isSupported.current = 'vibrate' in navigator || 'hapticFeedback' in navigator;
    
    // Log support status
    console.log('[HAPTIC] Support detected:', {
      vibrate: 'vibrate' in navigator,
      hapticFeedback: 'hapticFeedback' in navigator,
      supported: isSupported.current
    });
  }, []);

  const triggerVibration = useCallback((pattern: number | number[]) => {
    if (!isSupported.current) return;

    try {
      // Clear any existing vibration
      if (vibrationRef.current) {
        clearTimeout(vibrationRef.current);
      }

      // Trigger vibration
      navigator.vibrate(pattern);
      
      // Set timeout to clear vibration reference
      if (typeof pattern === 'number') {
        vibrationRef.current = setTimeout(() => {
          vibrationRef.current = null;
        }, pattern);
      }
    } catch (error) {
      console.warn('[HAPTIC] Vibration failed:', error);
    }
  }, []);

  const haptic = useCallback((type: keyof HapticPatterns, customOptions?: HapticOptions) => {
    if (!isSupported.current) return;

    const pattern = HAPTIC_PATTERNS[type];
    const options = { ...pattern, ...customOptions };
    
    // Convert intensity to vibration duration
    let vibrationDuration = options.duration || 50;
    switch (options.intensity) {
      case 'light':
        vibrationDuration = Math.min(vibrationDuration, 50);
        break;
      case 'medium':
        vibrationDuration = Math.min(vibrationDuration, 100);
        break;
      case 'heavy':
        vibrationDuration = Math.min(vibrationDuration, 200);
        break;
    }

    console.log('[HAPTIC] Triggering:', type, { intensity: options.intensity, duration: vibrationDuration });
    triggerVibration(vibrationDuration);
  }, [triggerVibration]);

  // Pattern-based haptic feedback for music rhythm
  const rhythmHaptic = useCallback((bpm: number, intensity: 'light' | 'medium' | 'heavy' = 'light') => {
    if (!isSupported.current || !bpm) return;

    // Calculate beat interval (60000ms / BPM)
    const beatInterval = 60000 / bpm;
    
    // Create vibration pattern: vibrate on beat, pause between beats
    const vibrateDuration = intensity === 'light' ? 20 : intensity === 'medium' ? 40 : 60;
    const pauseDuration = Math.max(50, beatInterval - vibrateDuration);
    
    const pattern = [vibrateDuration, pauseDuration];
    
    console.log('[HAPTIC] Rhythm pattern:', { bpm, pattern, intensity });
    triggerVibration(pattern);
  }, [triggerVibration]);

  // Audio-synchronized haptic feedback
  const audioSyncHaptic = useCallback((audioElement: HTMLAudioElement | null, enabled: boolean = true) => {
    if (!isSupported.current || !audioElement || !enabled) return;

    let animationFrame: number;
    let lastBassHit = 0;

    const analyzeAudio = () => {
      if (audioElement.paused) return;

      // Simple bass detection based on volume changes
      const currentTime = audioElement.currentTime;
      const volume = audioElement.volume;
      
      // Trigger haptic on volume spikes (simulating bass hits)
      if (volume > 0.7 && currentTime - lastBassHit > 0.5) {
        haptic('bassHit');
        lastBassHit = currentTime;
      }

      animationFrame = requestAnimationFrame(analyzeAudio);
    };

    if (enabled && !audioElement.paused) {
      analyzeAudio();
    }

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [haptic]);

  // Stop all vibrations
  const stopHaptic = useCallback(() => {
    if (!isSupported.current) return;
    
    try {
      navigator.vibrate(0);
      if (vibrationRef.current) {
        clearTimeout(vibrationRef.current);
        vibrationRef.current = null;
      }
    } catch (error) {
      console.warn('[HAPTIC] Stop failed:', error);
    }
  }, []);

  return {
    isSupported: isSupported.current,
    haptic,
    rhythmHaptic,
    audioSyncHaptic,
    stopHaptic,
    patterns: HAPTIC_PATTERNS
  };
}

export default useHapticFeedback;