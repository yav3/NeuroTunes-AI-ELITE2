import { Route } from 'wouter';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { queryClient } from '@/lib/queryClient';
import { ThemeProvider } from "@/components/theme-provider";
import { useAuth } from "@/hooks/useAuth";
import { useAudio, AudioProvider } from './context/AudioContext';
import BottomTabs from '@/components/BottomTabs';
import HomePageRefresh from './pages/HomePageRefresh';
import MoodPage from './pages/MoodPage';
import AIDJPageRefresh from './pages/AIDJPageRefresh';
import Profile from './pages/profile';
import Landing from "@/pages/landing";

function Layout() {
  const { isLoading, isAuthenticated } = useAuth();
  const { current: currentTrack, isPlaying, currentTime, duration, play, pause } = useAudio();

  if (isLoading || !isAuthenticated) {
    return <Landing />;
  }

  return (
    <div className="min-h-[100svh] flex flex-col bg-gradient-to-br from-[#0c1929] to-[#0a2a7a] text-white">
      {/* Main content */}
      <main className="flex-1 overflow-y-auto px-4 pb-32" style={{WebkitOverflowScrolling: 'touch'}}>
        <header className="mb-8 pt-6">
          <h1 className="text-3xl font-semibold text-white tracking-tight">NeuroTunes</h1>
        </header>

        <Route path="/" component={HomePageRefresh} />
        <Route path="/mood" component={MoodPage} />
        <Route path="/ai">
          {() => <AIDJPageRefresh onPlayTrack={(track) => play(track)} />}
        </Route>
        <Route path="/profile" component={Profile} />
      </main>

      {/* Removed duplicate mini player - using PersistentMusicPlayer instead */}

      {/* Bottom navigation */}
      <nav className="fixed inset-x-0 bottom-0 h-20 bg-[#0B223A]/95 backdrop-blur border-t border-white/10" style={{paddingBottom: 'env(safe-area-inset-bottom)'}}>
        <BottomTabs />
      </nav>
    </div>
  );
}

export default function AppFresh() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="music-wellness-theme">
      <QueryClientProvider client={queryClient}>
        <AudioProvider>
          <TooltipProvider>
            <Toaster />
            <Layout />
          </TooltipProvider>
        </AudioProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}