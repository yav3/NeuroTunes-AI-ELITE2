import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { StableAudioProvider } from "./context/StableAudioContext";
import App from "./App";
import "./index.css";

// Clear service worker cache if exists (mobile fix)
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(rs => rs.forEach(r => r.unregister()));
}

const root = ReactDOM.createRoot(document.getElementById("root")!);
root.render(
  <React.StrictMode>
    <BrowserRouter basename={((import.meta as any).env?.BASE_URL || '/').replace(/\/$/, '')}>
      <StableAudioProvider>
        <App />
      </StableAudioProvider>
    </BrowserRouter>
  </React.StrictMode>
);