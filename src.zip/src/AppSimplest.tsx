import { useState, useEffect } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { queryClient } from '@/lib/queryClient';
import { ThemeProvider } from "@/components/theme-provider";
import { useAuth } from "@/hooks/useAuth";
import { AudioProvider, useAudio } from './context/AudioContext';
import HomePageTrending from './pages/HomePageTrending';
import AIDJPageRefresh from './pages/AIDJPageRefresh';
import MoodPage from './pages/MoodPage';
import Profile from './pages/profile';
import Landing from "@/pages/landing";
import ErrorBoundary from './components/ErrorBoundary';

type Page = 'home' | 'ai' | 'profile';

function Layout() {
  const { isLoading, isAuthenticated } = useAuth();
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [showFullPlayer, setShowFullPlayer] = useState(false);
  const { current: currentTrack, isPlaying, currentTime, duration, play, pause, toggle, spatialAudioEnabled, toggleSpatialAudio, playNext, playPrevious } = useAudio();
  
  // Set up global error handlers for unhandled promises
  useEffect(() => {
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error('[APP] Unhandled promise rejection:', event.reason);
      event.preventDefault(); // Prevent the default browser error handling
    };

    const handleError = (event: ErrorEvent) => {
      console.error('[APP] Global error:', event.error);
    };

    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    window.addEventListener('error', handleError);

    return () => {
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
      window.removeEventListener('error', handleError);
    };
  }, []);
  
  // Debug current track state
  useEffect(() => {
    console.log('[APP] Current track:', currentTrack?.title || 'None');
    console.log('[APP] Is playing:', isPlaying);
  }, [currentTrack, isPlaying]);

  if (isLoading || !isAuthenticated) {
    return <Landing />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <HomePageTrending />;
      case 'ai': return <AIDJPageRefresh onPlayTrack={play} />;
      case 'profile': return <Profile />;
      default: return <HomePageTrending />;
    }
  };

  return (
    <div className="min-h-[100svh] flex flex-col bg-gradient-to-br from-[#0c1929] to-[#0a2a7a] text-white">
      {/* Main content */}
      <main className="flex-1 overflow-y-auto px-4 pb-32" style={{WebkitOverflowScrolling: 'touch'}}>
        <header className="mb-8 pt-6">
          <h1 className="text-3xl font-semibold text-white tracking-tight">NeuroTunes</h1>
        </header>

        {renderPage()}
      </main>

      {/* Full-page player */}
      {showFullPlayer && currentTrack && (
        <div className="fixed inset-0 bg-gradient-to-br from-[#0c1929] to-[#0a2a7a] z-50 flex flex-col">
          <div className="flex-1 flex flex-col justify-center items-center p-6 text-center">
            <button 
              onClick={() => setShowFullPlayer(false)}
              className="absolute top-6 right-6 w-10 h-10 flex items-center justify-center text-white/70 hover:text-white"
            >
              <div className="w-6 h-0.5 bg-current transform rotate-45 absolute"></div>
              <div className="w-6 h-0.5 bg-current transform -rotate-45 absolute"></div>
            </button>

            <div className="w-64 h-64 mb-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-3xl flex-shrink-0">
              <img 
                src={currentTrack.coverUrl || `/api/art/${encodeURIComponent(currentTrack.title)}`}
                alt={currentTrack.title}
                className="w-full h-full object-cover rounded-3xl"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                }}
              />
            </div>

            <h2 className="text-2xl font-bold text-white mb-2 leading-tight">{currentTrack.title}</h2>
            <p className="text-lg text-blue-200 mb-8">Neural Positive Music</p>

            <div className="w-full max-w-sm mb-8">
              <div className="flex justify-between text-sm text-blue-200 mb-2">
                <span>{Math.floor(currentTime / 60)}:{(Math.floor(currentTime) % 60).toString().padStart(2, '0')}</span>
                <span>{duration > 0 ? `${Math.floor(duration / 60)}:${(Math.floor(duration) % 60).toString().padStart(2, '0')}` : '--:--'}</span>
              </div>
              <div className="h-2 bg-white/20 rounded-full">
                <div className="h-full bg-blue-400 rounded-full transition-all" style={{width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%`}}></div>
              </div>
            </div>

            <div className="flex items-center gap-6 mb-6">
              <button 
                onClick={playPrevious}
                className="w-12 h-12 flex items-center justify-center text-white/70 hover:text-white"
              >
                <div className="w-0 h-0 border-r-[8px] border-r-current border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent mr-1"></div>
              </button>
              <button 
                onClick={toggle}
                className="w-16 h-16 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center"
              >
                {isPlaying ? (
                  <div className="w-5 h-5 flex space-x-1">
                    <div className="w-1.5 h-full bg-white"></div>
                    <div className="w-1.5 h-full bg-white"></div>
                  </div>
                ) : (
                  <div className="w-0 h-0 border-l-[12px] border-l-white border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent ml-1"></div>
                )}
              </button>
              <button 
                onClick={playNext}
                className="w-12 h-12 flex items-center justify-center text-white/70 hover:text-white"
              >
                <div className="w-0 h-0 border-l-[8px] border-l-current border-t-[6px] border-t-transparent border-b-[6px] border-b-transparent ml-1"></div>
              </button>
            </div>

            {/* Interactive Action Buttons */}
            <div className="flex items-center justify-center gap-8 mb-8">
              <button 
                onClick={() => console.log('Thumbs down clicked for:', currentTrack.title)}
                className="w-12 h-12 flex items-center justify-center text-white/50 hover:text-red-400 transition-colors"
                title="Dislike track"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              
              <button 
                onClick={() => console.log('Favorites clicked for:', currentTrack.title)}
                className="w-14 h-14 flex items-center justify-center text-white/70 hover:text-green-400 transition-colors bg-white/10 hover:bg-green-400/20 rounded-full"
                title="Add to favorites"
              >
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
              
              <button 
                onClick={() => console.log('Lightning (energy boost) clicked for:', currentTrack.title)}
                className="w-12 h-12 flex items-center justify-center text-white/50 hover:text-yellow-400 transition-colors"
                title="Energy boost mode"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                  <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" stroke="currentColor" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>
            </div>

            <div className="w-full max-w-sm">
              <div className="flex items-center justify-between mb-4">
                <span className="text-white text-sm">Spatial Audio</span>
                <button 
                  onClick={toggleSpatialAudio}
                  className={`w-12 h-6 rounded-full transition-colors ${spatialAudioEnabled ? 'bg-blue-600' : 'bg-white/20'}`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${spatialAudioEnabled ? 'translate-x-6' : 'translate-x-0.5'}`}></div>
                </button>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-6 h-6 bg-white/20 rounded"></div>
                <div className="flex-1 h-1 bg-white/20 rounded-full">
                  <div className="h-full bg-white rounded-full w-3/4"></div>
                </div>
                <div className="w-6 h-6 bg-white/20 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Mini player */}
      {currentTrack && !showFullPlayer && (
        <div 
          onClick={() => setShowFullPlayer(true)}
          className="fixed inset-x-0 bottom-20 mx-4 mb-2 bg-[#0B223A]/95 backdrop-blur rounded-2xl border border-white/10 p-3 flex items-center gap-3 cursor-pointer" 
          style={{paddingBottom: 'env(safe-area-inset-bottom)'}}
        >
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-lg flex-shrink-0"></div>
          <div className="flex-1 min-w-0">
            <h4 className="text-white text-sm font-medium truncate">{currentTrack.title}</h4>
            <div className="flex items-center gap-2 text-xs text-blue-200">
              <span>{Math.floor(currentTime)}s</span>
              <div className="flex-1 h-1 bg-white/20 rounded-full">
                <div className="h-full bg-blue-400 rounded-full transition-all" style={{width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%`}}></div>
              </div>
              <span>{Number.isFinite(duration) && duration > 0 ? `${Math.floor(duration)}s` : '—'}</span>
            </div>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); toggle(); }} 
            className="w-10 h-10 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center"
          >
            {isPlaying ? (
              <div className="w-3 h-3 flex space-x-0.5">
                <div className="w-0.5 h-full bg-white"></div>
                <div className="w-0.5 h-full bg-white"></div>
              </div>
            ) : (
              <div className="w-0 h-0 border-l-[6px] border-l-white border-t-[4px] border-t-transparent border-b-[4px] border-b-transparent ml-0.5"></div>
            )}
          </button>
        </div>
      )}

      {/* Bottom navigation */}
      <nav className="fixed inset-x-0 bottom-0 h-20 bg-[#0B223A]/95 backdrop-blur border-t border-white/10" style={{paddingBottom: 'env(safe-area-inset-bottom)'}}>
        <div className="flex h-full">
          <button 
            onClick={() => setCurrentPage('home')}
            className={`flex-1 flex flex-col items-center justify-center ${currentPage === 'home' ? 'text-blue-400' : 'text-gray-400'}`}
          >
            <div className="w-6 h-6 mb-1 bg-current rounded"></div>
            <span className="text-xs">Home</span>
          </button>

          <button 
            onClick={() => setCurrentPage('ai')}
            className={`flex-1 flex flex-col items-center justify-center ${currentPage === 'ai' ? 'text-blue-400' : 'text-gray-400'}`}
          >
            <div className="w-6 h-6 mb-1 bg-current rounded"></div>
            <span className="text-xs">AI DJ</span>
          </button>

          <button 
            onClick={() => setCurrentPage('profile')}
            className={`flex-1 flex flex-col items-center justify-center ${currentPage === 'profile' ? 'text-blue-400' : 'text-gray-400'}`}
          >
            <div className="w-6 h-6 mb-1 bg-current rounded"></div>
            <span className="text-xs">Profile</span>
          </button>
        </div>
      </nav>
    </div>
  );
}

export default function AppSimplest() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark" storageKey="music-wellness-theme">
        <QueryClientProvider client={queryClient}>
          <AudioProvider>
            <TooltipProvider>
              <Toaster />
              <Layout />
            </TooltipProvider>
          </AudioProvider>
        </QueryClientProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}